package online.wtrasie.app;

import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * v1.5.0: panel with every line of the current city, grouped into tabs by
 * transport type (zakładki). Tapping a line triggers the app search for it —
 * the same list of live vehicles as when typing the line number.
 *
 * alpha-1.6.0: the tabs are ICONS on the strip (no text, not wrapped in
 * circles) with a clear highlight of the active tab, and the panel rebuilds
 * whenever the city / stop list changes under it.
 */
public class LinesSheet extends Sheet {

    /** Filter type -> tab. Order = display order. */
    private static final int[] TAB_TYPES = {3, 0, 1, 2, 11, 4, 99};

    /** Icon of each tab — plain icons on the strip, no circles. */
    private static int tabIcon(int type) {
        switch (type) {
            case 0: return R.drawable.ic_type_tram;
            case 1: return R.drawable.ic_metro_m;
            case 2: return R.drawable.ic_type_train;
            case 4: return R.drawable.ic_type_ferry;
            case 11: return R.drawable.ic_type_trolleybus;
            case 99: return R.drawable.ic_type_gondola;
            default: return R.drawable.ic_type_bus;
        }
    }

    private final MainActivity act;
    private final TextView title;
    private final LinearLayout tabsRow;
    private final LinearLayout body;
    private final TextView empty;
    private final Map<Integer, List<Models.Route>> byType = new LinkedHashMap<>();
    private int currentTab = -1;

    public LinesSheet(final MainActivity act) {
        super(act, R.layout.sheet_lines);
        this.act = act;

        tabsRow = findViewById(R.id.linesTabs);
        body = findViewById(R.id.linesBody);
        empty = findViewById(R.id.linesEmpty);
        title = findViewById(R.id.linesTitle);
        ImageButton close = findViewById(R.id.btnCloseLines);
        close.setOnClickListener(v -> hide());
        if (act.currentCity != null) {
            title.setText(act.getString(R.string.lines_title, act.currentCity.name));
        }

        setDragHandle(findViewById(R.id.linesHeader));
        setScrollableContent(findViewById(R.id.linesScroll));
    }

    @Override
    public void show() {
        super.show();
        rebuild();
    }

    /**
     * alpha-1.6.0: the stop list changed (city switch, nationwide viewport
     * move) — refresh the panel live instead of showing the previous city.
     */
    public void onStopsChanged() {
        if (getState() == HIDDEN) return;
        rebuild();
    }

    /** Aggregate all distinct lines of the current city from the stop list. */
    private void rebuild() {
        byType.clear();
        if (act.currentCity != null) {
            title.setText(act.getString(R.string.lines_title, act.currentCity.name));
        }
        boolean filterTechnical = act.prefs.filterTechnical();
        Map<String, Models.Route> distinct = new LinkedHashMap<>();
        for (Models.Stop s : act.map.getStops()) {
            if (s.routes == null) continue;
            for (Models.Route r : s.routes) {
                if (r.name == null || r.name.isEmpty()) continue;
                if (Models.hiddenByTechnicalFilter(r.name, filterTechnical)) continue;
                String key = r.id != null && !r.id.isEmpty() ? r.id : r.name;
                if (!distinct.containsKey(key)) distinct.put(key, r);
            }
        }
        for (Models.Route r : distinct.values()) {
            int ft = tabOf(gtfsToTab(r.type));
            List<Models.Route> list = byType.get(ft);
            if (list == null) {
                list = new ArrayList<>();
                byType.put(ft, list);
            }
            if (!list.contains(r)) list.add(r);
        }
        for (List<Models.Route> list : byType.values()) {
            Collections.sort(list, new Comparator<Models.Route>() {
                @Override
                public int compare(Models.Route a, Models.Route b) {
                    try {
                        return Long.compare(Long.parseLong(a.name.trim()), Long.parseLong(b.name.trim()));
                    } catch (Exception e) {
                        return a.name.compareToIgnoreCase(b.name);
                    }
                }
            });
        }
        buildTabs();
    }

    /** GTFS route_type -> tab type (99 collapses gondola/funicular/monorail…). */
    private static int gtfsToTab(int gtfsType) {
        switch (gtfsType) {
            case 0: return 0;   // tram
            case 1: return 1;   // metro
            case 2: return 2;   // rail
            case 3: return 3;   // bus
            case 4: return 4;   // ferry
            case 11: return 11; // trolleybus
            default: return 99;
        }
    }

    private static int tabOf(int tabType) {
        for (int t : TAB_TYPES) if (t == tabType) return tabType;
        return 99;
    }

    /**
     * The tab strip: only types that actually have lines in this city.
     * alpha-1.6.0: plain ICONS on the strip (not in circles); the active tab
     * is highlighted with the accent color + a light tint background.
     */
    private void buildTabs() {
        tabsRow.removeAllViews();
        boolean any = false;
        for (int i = 0; i < TAB_TYPES.length; i++) {
            final int type = TAB_TYPES[i];
            if (!byType.containsKey(type)) continue;
            any = true;
            ImageView tab = new ImageView(act);
            tab.setImageResource(tabIcon(type));
            tab.setTag(TAB_TYPES[i]);
            int pad = Ui.dp(act, 11);
            tab.setPadding(pad, pad, pad, pad);
            tab.setOnClickListener(v -> safe(() -> {
                currentTab = type;
                styleTabs();
                buildBody();
            }));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    Ui.dp(act, 44), Ui.dp(act, 44));
            tabsRow.addView(tab, lp);
        }
        Ui.setVisible(tabsRow.getParent() instanceof View ? (View) tabsRow.getParent() : tabsRow, any);
        if (!any) {
            body.removeAllViews();
            Ui.setVisible(empty, true);
            return;
        }
        Ui.setVisible(empty, false);
        if (currentTab == -1 || !byType.containsKey(currentTab)) {
            // first tab with content becomes the default
            for (int t : TAB_TYPES) {
                if (byType.containsKey(t)) {
                    currentTab = t;
                    break;
                }
            }
        }
        styleTabs();
        buildBody();
    }

    /** Highlight of the active tab: accent icon + light accent tint. */
    private void styleTabs() {
        for (int i = 0; i < tabsRow.getChildCount(); i++) {
            View c = tabsRow.getChildAt(i);
            boolean sel = c.getTag() instanceof Integer && ((Integer) c.getTag()) == currentTab;
            if (c instanceof ImageView) {
                ((ImageView) c).setColorFilter(sel ? 0xFF0B57D0 : 0xFF5F5F66);
                c.setBackground(sel ? act.getResources().getDrawable(R.drawable.bg_tab_active) : null);
            }
        }
    }

    /** The chips of the active tab. */
    private void buildBody() {
        body.removeAllViews();
        List<Models.Route> lines = byType.get(currentTab);
        if (lines == null || lines.isEmpty()) {
            Ui.setVisible(empty, true);
            return;
        }
        Ui.setVisible(empty, false);
        FlowLayout flow = new FlowLayout(act);
        flow.setPadding(0, Ui.dp(act, 6), 0, Ui.dp(act, 8));
        for (final Models.Route r : lines) {
            TextView chip = new TextView(act);
            int color = act.prefs.keepOriginalColors() ? r.color : Models.typeColor(r.type);
            Ui.setPill(chip, r.name, color);
            chip.setTextSize(14.5f);
            chip.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            chip.setPadding(Ui.dp(act, 12), Ui.dp(act, 5), Ui.dp(act, 12), Ui.dp(act, 5));
            chip.setOnClickListener(v -> safe(() -> {
                hide();
                act.searchSheet.openLineFromPanel(r);
            }));
            flow.addView(chip, new LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(act, 6)));
        }
        body.addView(flow, new LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void safe(Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            android.util.Log.e("LinesSheet", "action", t);
        }
    }
}
