package online.wtrasie.app;

import android.app.Activity;
import android.os.Looper;
import android.view.View;
import android.widget.ListView;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.Shadows;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.LooperMode;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowLooper;

import java.util.Base64;
import java.util.List;
import java.util.Map;

/**
 * Startup and screen-coverage tests. All layouts and lifecycle paths exercised
 * here; any exception fails the test with the full stack trace.
 */
@RunWith(org.robolectric.RobolectricTestRunner.class)
@Config(sdk = 34)
@LooperMode(LooperMode.Mode.PAUSED)
public class StartupTest {

    /** Real vehiclePositions feed (Rzeszów, night buses) captured from the API. */
    private static final String VP_FEED_B64 =
            "Cg0KAzIuMBAAGMOu1NcGEnoKHXZlaGljbGVQb3NpdGlvbi9kZWZhdWx0LzM6MTE4IlkKLgoQYWIwZmFiZDQ5N2MyZDJhMxIIMjU6MzY6MDAaCDIwMjYxMTExIAAqAm4xMAESDw0GBEhCFSY8sEEdAAAIQxgjIAIowq7U1wZCDAoFMzoxMTgSAzExOBJ6Ch12ZWhpY2xlUG9zaXRpb24vZGVmYXVsdC8zOjEyMCJZCi4KEDc1YTRkM2JhMzBhNGIzODQSCDI2OjM2OjAwGggyMDI2MTExMSAAKgJuMjABEg8NfC1IQhXDk69BHQCAg0MYACACKMKu1NcGQgwKBTM6MTIwEgMxMjASegoddmVoaWNsZVBvc2l0aW9uL2RlZmF1bHQvMzoxMTkiWQouChBkNGZlMzBiOTU4MmQ1NTNhEggyNzoyMTowMBoIMjAyNjExMTEgACoCbjMwABIPDTJJSEIV+CuwQR0AAJJCGAAgAijCrtTXBkIMCgUzOjExORIDMTE5";

    /**
     * Robolectric cannot load the MapLibre native library. Setting the
     * (pure-Java) MapLibre.INSTANCE beforehand makes getInstance() skip all
     * native init paths, so MapView inflates and the whole activity is
     * testable. Rendering itself never runs in unit tests.
     */
    @org.junit.Before
    public void initMapLibreInstance() throws Exception {
        Class<?> cls = Class.forName("org.maplibre.android.MapLibre");
        java.lang.reflect.Field f = cls.getDeclaredField("INSTANCE");
        f.setAccessible(true);
        if (f.get(null) == null) {
            java.lang.reflect.Constructor<?> c = cls.getDeclaredConstructor(
                    android.content.Context.class, String.class);
            c.setAccessible(true);
            f.set(null, c.newInstance(
                    org.robolectric.RuntimeEnvironment.getApplication(), null));
        }
    }

    /**
     * MapView inflation needs the MapLibre NATIVE library — under a plain JVM
     * (unit tests without an emulator) MapRenderer.<clinit> throws
     * UnsatisfiedLinkError. The map-based activity tests run only where the
     * natives exist; everywhere else they are skipped via Assume.
     */
    private static boolean mapNativesOk() {
        try {
            System.loadLibrary("maplibre"); // binds MapRenderer.nativeInitialize
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void skipWithoutNatives() {
        org.junit.Assume.assumeTrue(
                "MapLibre natives unavailable in this environment (no emulator/device)",
                mapNativesOk());
    }

    private void idleMain() {
        ShadowLooper shadow = Shadows.shadowOf(Looper.getMainLooper());
        // run what's due now, several rounds so callbacks posted by callbacks also run
        for (int i = 0; i < 6; i++) {
            try {
                shadow.idle();
            } catch (Throwable t) {
                throw t;
            }
            try {
                Thread.sleep(120);
            } catch (InterruptedException ignored) {
            }
        }
    }

    @Test
    public void mainActivityLaunches() {
        skipWithoutNatives();
        ActivityController<MainActivity> ctrl = Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity act = ctrl.get();
        idleMain();
        // first draw pass
        act.getWindow().getDecorView().measure(1080, 2340);
        act.getWindow().getDecorView().layout(0, 0, 1080, 2340);
        act.getWindow().getDecorView().draw(new android.graphics.Canvas());
        idleMain();
        ctrl.pause().stop().destroy();
    }

    @Test
    public void tabsSwitch() {
        skipWithoutNatives();
        ActivityController<MainActivity> ctrl = Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity act = ctrl.get();
        idleMain();
        View mapTab = act.findViewById(R.id.mapTab);
        View routeTab = act.findViewById(R.id.routeTab);
        View settingsTab = act.findViewById(R.id.settingsTab);
        org.junit.Assert.assertEquals(View.VISIBLE, mapTab.getVisibility());
        org.junit.Assert.assertEquals(View.GONE, routeTab.getVisibility());
        act.findViewById(R.id.tabRoute).performClick();
        idleMain();
        org.junit.Assert.assertEquals(View.INVISIBLE, mapTab.getVisibility());
        org.junit.Assert.assertEquals(View.VISIBLE, routeTab.getVisibility());
        act.findViewById(R.id.tabSettings).performClick();
        idleMain();
        org.junit.Assert.assertEquals(View.VISIBLE, settingsTab.getVisibility());
        act.findViewById(R.id.tabMap).performClick();
        idleMain();
        org.junit.Assert.assertEquals(View.VISIBLE, mapTab.getVisibility());
        ctrl.pause().stop().destroy();
    }

    @Test
    public void citySheetOpensAndListIsClean() {
        skipWithoutNatives();
        ActivityController<MainActivity> ctrl = Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity act = ctrl.get();
        idleMain();
        act.citySheet.show();
        idleMain();
        ListView list = act.citySheet.findViewById(R.id.cityList);
        org.junit.Assert.assertEquals(67, list.getAdapter().getCount());
        // every entry unique
        java.util.Set<String> names = new java.util.HashSet<>();
        for (int i = 0; i < list.getAdapter().getCount(); i++) {
            Cities.City c = (Cities.City) list.getAdapter().getItem(i);
            names.add(c.name + "|" + c.slug);
        }
        org.junit.Assert.assertEquals(list.getAdapter().getCount(), names.size());
        ctrl.pause().stop().destroy();
    }

    @Test
    public void searchSheetOpens() {
        skipWithoutNatives();
        ActivityController<MainActivity> ctrl = Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity act = ctrl.get();
        idleMain();
        act.searchSheet.show();
        idleMain();
        ctrl.pause().stop().destroy();
    }

    @Test
    public void stopSheetOpens() {
        skipWithoutNatives();
        ActivityController<MainActivity> ctrl = Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity act = ctrl.get();
        idleMain();
        Models.Stop s = new Models.Stop();
        s.id = "witosa-jedn-wojskowa08-z2wuh";
        s.city = "rzeszow";
        s.name = "Witosa jedn. wojskowa";
        s.code = "08";
        s.lon = 21.9819;
        s.lat = 50.0440;
        s.types = new int[]{3};
        s.bearing = 104;
        s.routes = new Models.Route[]{};
        act.stopSheet.open(Cities.bySlug("rzeszow"), s);
        idleMain();
        ctrl.pause().stop().destroy();
    }

    @Test
    public void vehicleSheetOpens() {
        skipWithoutNatives();
        ActivityController<MainActivity> ctrl = Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity act = ctrl.get();
        idleMain();
        Models.Vehicle v = new Models.Vehicle();
        v.id = "805";
        v.type = "3";
        v.routeName = "3";
        v.routeColor = 0xFF215DA5;
        v.brigade = "3-1";
        v.lon = 22.0;
        v.lat = 50.03;
        v.headsign = "Boguchwała";
        v.delay = -20000L;
        v.bearing = 152;
        v.model = "Mercedes";
        v.agency = "default";
        v.upcoming = new Models.Upcoming[0];
        act.onVehicleTapped(v);
        idleMain();
        org.junit.Assert.assertEquals("3:805", act.map.getHighlight());
        act.vehicleSheet.hide();
        idleMain();
        org.junit.Assert.assertNull(act.map.getHighlight());
        ctrl.pause().stop().destroy();
    }

    @Test
    public void helpActivityLaunches() {
        ActivityController<HelpActivity> ctrl = Robolectric.buildActivity(HelpActivity.class).setup();
        idleMain();
        ctrl.get().getWindow().getDecorView().measure(1080, 2340);
        ctrl.get().getWindow().getDecorView().layout(0, 0, 1080, 2340);
        ctrl.get().getWindow().getDecorView().draw(new android.graphics.Canvas());
        idleMain();
        ctrl.pause().stop().destroy();
    }

    @Test
    public void gtfsRtParserReadsRealFeed() {
        byte[] data = Base64.getDecoder().decode(VP_FEED_B64);
        Map<String, GtfsRt.Vp> parsed = new java.util.HashMap<>();
        GtfsRt.parseFeed(data, parsed);
        org.junit.Assert.assertEquals(3, parsed.size());
        GtfsRt.Vp v118 = parsed.get("3:118");
        org.junit.Assert.assertNotNull(v118);
        org.junit.Assert.assertEquals("ab0fabd497c2d2a3", v118.tripId);
        org.junit.Assert.assertEquals("n1", v118.routeId);
        org.junit.Assert.assertEquals("20261111", v118.startDate);
        org.junit.Assert.assertEquals("25:36:00", v118.startTime);
        org.junit.Assert.assertEquals(50.00393, v118.lat, 1e-4);
        org.junit.Assert.assertEquals(22.02937, v118.lon, 1e-4);
        GtfsRt.Vp v120 = parsed.get("3:120");
        org.junit.Assert.assertNotNull(v120);
        org.junit.Assert.assertEquals("75a4d3ba30a4b384", v120.tripId);
    }

    @Test
    public void gtfsServiceDayEpoch() {
        long ms = Gtfs.serviceDayEpoch("20261111");
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(ms);
        org.junit.Assert.assertEquals(2026, c.get(java.util.Calendar.YEAR));
        org.junit.Assert.assertEquals(10, c.get(java.util.Calendar.MONTH)); // November
        org.junit.Assert.assertEquals(11, c.get(java.util.Calendar.DAY_OF_MONTH));
        org.junit.Assert.assertEquals(0, c.get(java.util.Calendar.HOUR_OF_DAY));
    }

    @Test
    public void countdownFormatting() {
        long now = 1700000000000L;
        org.junit.Assert.assertEquals("<1 min", Ui.fmtCountdown(now + 30_000, now));
        org.junit.Assert.assertEquals("5 min", Ui.fmtCountdown(now + 5 * 60_000, now));
        org.junit.Assert.assertEquals("60 min", Ui.fmtCountdown(now + 60 * 60_000, now));
        // above 60 minutes the clock time is shown instead
        org.junit.Assert.assertEquals(Ui.fmtTime(now + 95 * 60_000), Ui.fmtCountdown(now + 95 * 60_000, now));
        org.junit.Assert.assertTrue(Ui.isBlinkCountdown("<1 min"));
        org.junit.Assert.assertEquals("25:36", Ui.fmtGtfsTime(25 * 3600 + 36 * 60));
        org.junit.Assert.assertEquals("0:05", Ui.fmtGtfsTime(300));
    }

    @Test
    public void typeColorsFollowSpec() {
        org.junit.Assert.assertEquals(0xFFD32F2F, Models.typeColor(3)); // bus red
        org.junit.Assert.assertEquals(0xFF1976D2, Models.typeColor(0)); // tram blue
        org.junit.Assert.assertEquals(0xFFD81B60, Models.typeColor(1)); // metro pink
        org.junit.Assert.assertEquals(0xFF2E7D32, Models.typeColor(2)); // rail green
    }

    @Test
    public void technicalRouteFiltering() {
        org.junit.Assert.assertTrue(Models.isTechnicalRoute("PT"));
        org.junit.Assert.assertTrue(Models.isTechnicalRoute("pt"));
        org.junit.Assert.assertTrue(Models.isTechnicalRoute("..."));
        org.junit.Assert.assertTrue(Models.isTechnicalRoute(""));
        org.junit.Assert.assertTrue(Models.isTechnicalRoute(null));
        org.junit.Assert.assertFalse(Models.isTechnicalRoute("12"));
        org.junit.Assert.assertFalse(Models.isTechnicalRoute("PTAK"));
        org.junit.Assert.assertFalse(Models.isTechnicalRoute("N3"));
        // hiddenByTechnicalFilter
        org.junit.Assert.assertTrue(Models.hiddenByTechnicalFilter("PT", true));
        org.junit.Assert.assertFalse(Models.hiddenByTechnicalFilter("PT", false));
        org.junit.Assert.assertFalse(Models.hiddenByTechnicalFilter("15", true));
    }

    @Test
    public void stopColorsFollowSpec() {
        // alpha-1.6.0: stops use their type's color (the toggle-icon palette);
        // buses stay GREEN as the exception
        org.junit.Assert.assertEquals(0xFF2E9E44, Models.stopColor(3)); // bus - green (exception)
        org.junit.Assert.assertEquals(0xFF2E7D32, Models.stopColor(2)); // rail - green (icon color)
        org.junit.Assert.assertEquals(0xFFD81B60, Models.stopColor(1)); // metro - pink
        org.junit.Assert.assertEquals(0xFF1976D2, Models.stopColor(0)); // tram - blue
        org.junit.Assert.assertEquals(0xFF00695C, Models.stopColor(11)); // trolley - teal
    }

    /**
     * alpha-1.6.0 crash fix: a FRESH install must resolve the default city —
     * "warszawa" never matched any slug ("warsaw"), currentCity was null and
     * the app crashed on the first screen.
     */
    @Test
    public void lastCitySlugResolvesOnFreshInstall() {
        Prefs p = new Prefs(org.robolectric.RuntimeEnvironment.getApplication());
        org.junit.Assert.assertEquals("warsaw", p.lastCity());
        org.junit.Assert.assertNotNull(Cities.bySlug(p.lastCity()));
        // a legacy saved "warszawa" also resolves now
        p.setLastCity("warszawa");
        org.junit.Assert.assertEquals("warsaw", p.lastCity());
        org.junit.Assert.assertNotNull(Cities.bySlug(p.lastCity()));
    }

    /**
     * alpha-1.6.1: the stop timetable carries every service variant with its
     * calendar — day-type classification and exact-date resolution happen
     * client-side (Svc.activeOn / dayType).
     */
    @Test
    public void timetableCarriesServiceCalendar() throws Exception {
        java.io.File dir = java.nio.file.Files.createTempDirectory("gtfs").toFile();
        java.io.File zipF = new java.io.File(dir, "gtfs.zip");
        try (java.util.zip.ZipOutputStream zo = new java.util.zip.ZipOutputStream(
                new java.io.FileOutputStream(zipF))) {
            writeZipEntry(zo, "calendar.txt",
                    "service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date\n"
                            + "WORK,1,1,1,1,1,0,0,20260101,20261231\n"
                            + "SAT,0,0,0,0,0,1,0,20260101,20261231\n"
                            + "SUN,0,0,0,0,0,0,1,20260101,20261231\n"
                            + "SCHOOLFREE,1,1,1,1,1,0,0,20260627,20260831\n");
            writeZipEntry(zo, "calendar_dates.txt",
                    "service_id,date,exception_type\n"
                            + "WORK,20261111,2\n" // 2026-11-11 is a holiday (Wednesday): WORK removed
                            + "SUN,20261111,1\n" // and Sunday service added instead
                            + "WORK,20260701,2\n" // summer school-free Wednesday: WORK removed too
            );
            writeZipEntry(zo, "routes.txt",
                    "route_id,route_short_name,route_long_name,route_color\n"
                            + "R1,5,Osie — Miasto,215DA5\n");
            writeZipEntry(zo, "trips.txt",
                    "route_id,service_id,trip_id,trip_headsign\n"
                            + "R1,WORK,T1,Miasto\n"
                            + "R1,WORK,T2,Miasto\n"
                            + "R1,SAT,T3,Miasto\n"
                            + "R1,SUN,T4,Miasto (świ\u0119te)\n");
            writeZipEntry(zo, "stop_times.txt",
                    "trip_id,arrival_time,departure_time,stop_id,stop_sequence\n"
                            + "T1,08:00:00,08:00:00,stop1,1\n"
                            + "T2,15:02:00,15:02:00,stop1,1\n"
                            + "T3,09:30:00,09:30:00,stop1,1\n"
                            + "T4,10:15:00,10:15:00,stop1,1\n");
        }

        java.util.zip.ZipFile zip = new java.util.zip.ZipFile(zipF);
        java.lang.reflect.Method m = Gtfs.class.getDeclaredMethod("readStopTimetable",
                java.util.zip.ZipFile.class, String.class);
        m.setAccessible(true);

        @SuppressWarnings("unchecked")
        Gtfs.StopTt tt = (Gtfs.StopTt) m.invoke(null, zip, "stop1");
        org.junit.Assert.assertEquals(1, tt.routes.size());
        Gtfs.RouteTt r1 = tt.routes.get("R1");
        org.junit.Assert.assertEquals(4, r1.times.size());
        // sorted by time: 08:00 (T1), 09:30 (T3), 10:15 (T4), 15:02 (T2)
        org.junit.Assert.assertEquals("8:00", Ui.fmtGtfsTime(r1.times.get(0).timeSec));
        org.junit.Assert.assertEquals("9:30", Ui.fmtGtfsTime(r1.times.get(1).timeSec));
        org.junit.Assert.assertEquals("10:15", Ui.fmtGtfsTime(r1.times.get(2).timeSec));
        org.junit.Assert.assertEquals("15:02", Ui.fmtGtfsTime(r1.times.get(3).timeSec));
        org.junit.Assert.assertEquals("Miasto", r1.times.get(0).headsign);
        org.junit.Assert.assertEquals("Miasto (\u015bwi\u0119te)", r1.times.get(2).headsign);

        // day-type classification: WORK = weekday, SAT = saturday, SUN = sunday
        org.junit.Assert.assertEquals(0, tt.services.get("WORK").dayType());
        org.junit.Assert.assertEquals(1, tt.services.get("SAT").dayType());
        org.junit.Assert.assertEquals(2, tt.services.get("SUN").dayType());

        // 2026-11-13 is a FRIDAY: WORK active, SAT/SUN not
        org.junit.Assert.assertTrue(tt.services.get("WORK").activeOn("20261113"));
        org.junit.Assert.assertFalse(tt.services.get("SAT").activeOn("20261113"));
        org.junit.Assert.assertFalse(tt.services.get("SUN").activeOn("20261113"));

        // 2026-11-14 is a SATURDAY
        org.junit.Assert.assertTrue(tt.services.get("SAT").activeOn("20261114"));
        org.junit.Assert.assertFalse(tt.services.get("WORK").activeOn("20261114"));

        // 2026-11-11 (Wednesday) — WORK removed by the exception, SUN added:
        // the holiday runs the Sunday service instead of the weekday one
        org.junit.Assert.assertFalse(tt.services.get("WORK").activeOn("20261111"));
        org.junit.Assert.assertTrue(tt.services.get("SUN").activeOn("20261111"));

        // 2026-07-01 (Wednesday in summer): WORK removed, SCHOOLFREE active
        org.junit.Assert.assertFalse(tt.services.get("WORK").activeOn("20260701"));
        org.junit.Assert.assertTrue(tt.services.get("SCHOOLFREE").activeOn("20260701"));

        zip.close();
    }

    private static void writeZipEntry(java.util.zip.ZipOutputStream zo, String name, String content)
            throws java.io.IOException {
        zo.putNextEntry(new java.util.zip.ZipEntry(name));
        zo.write(content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        zo.closeEntry();
    }

    @Test
    public void stationDetection() {
        Models.Stop s = new Models.Stop();
        s.name = "Dworzec Główny PKP 01";
        org.junit.Assert.assertTrue(s.isStation());
        s.name = "Lwowska szpital pętla";
        org.junit.Assert.assertFalse(s.isStation());
    }
}
