# wtrasie.online

Natywna aplikacja na Androida (10+) do podglądu transportu publicznego w czasie rzeczywistym.
Mapa, pojazdy na żywo, tablice odjazdów i rozkłady z przystanków, wyszukiwanie.

## Funkcje

- Mapa wektorowa MapLibre (styl zbiorkom.live / OpenFreeMap) z natychmiastowym przełączaniem miasta
  (66 miast + sieci ogólnopolskie: PKP, FlixBus, Digitraffic, Islandia, Holandia, Szwajcaria)
- Pozycje pojazdów na żywo (odświeżanie co 5/10/15/30 s), kolorowe plakietki linii;
  przy oddaleniu kolorowe kropki w barwach linii (bug czarnych kropek naprawiony w alpha-1.6.1)
- Przystanki zawsze jako kolorowe ikony typów (bez fazy kropek) — i to wszystkich przewoźników
  oglądanego obszaru: do przystanków wybranego miasta dokładamy stacje kolejowe z zestawu PKP
- Obsługa przycisku/gestu cofania: panel -> zamknięcie, inna zakładka -> mapa
- Tablica odjazdów z przystanku: czas, opóźnienie, realtime, odwołane kursy, filtr linii
- Rozkłady jazdy (alpha-1.6.1): kafelki linii -> menu dnia (typy dnia z fadem + przypięty
  kalendarz) -> lista kursów w stylu najbliższych odjazdów (linia + kierunek, godzina po prawej)
- Szczegóły pojazdu: model, brygada, opóźnienie, najbliższe przystanki, link do strony pojazdu;
  trasa pojazdu ma priorytet nad masowym czytaniem GTFS (osobna kolejka z priorytetami)
- Wyszukiwanie przystanków (z X do czyszczenia pola i X do zamknięcia panelu), także w innych
  miastach — dworce kolejowe otwierają się z właściwego zestawu (nie z pobliskiego przystanku)
- Ulubione przystanki + ostatnio otwierane + najbliższe przystanki (z lokalizacji)
- Filtry typów pojazdów na mapie (ikony na dole ekranu)
- Zakładka „Trasa” zarezerwowana na przyszłość („Na razie nic tu nie ma :)”)
- Ustawienia: częstotliwość odświeżania, rozmiar ikon, podkład mapy (OSM / satelita Esri),
  brygada/tabor na ikonie, automatyczna zmiana miasta, czyszczenie pamięci podręcznej
- Biały, minimalistyczny interfejs oparty na ikonach SVG (Material Design Icons)

## Dane

- Pozycje pojazdów / przystanki / odjazdy: otwarte API `api.zbiorkom.live/api6-open`
- Wyszukiwanie miejsc i planowanie podróży: otwarte API `api.transitous.org`
- Kafle mapy: OpenStreetMap (© OpenStreetMap contributors), satelita: Esri World Imagery

## Budowanie

Wymagania: JDK 17+, Android SDK (platform 34, build-tools 34).

```bash
# local.properties:
# sdk.dir=/path/to/android-sdk

./gradlew assembleRelease   # lub: gradle assembleRelease
```

Podpisany APK: `app/build/outputs/apk/release/app-release.apk`.

Klucz podpisujący `release.keystore` jest dołączony do repozytorium
(hasło: `wtrasie2026`, alias: `wtrasie`), więc kolejne kompilacje mają ten sam podpis
i instalują się jako aktualizacja. Uruchom `./gradlew assembleDebug` lub podmień
klucz, jeśli chcesz własny podpis.

## Struktura

```
app/src/main/java/online/wtrasie/app/
  MainActivity.java      - mapa, paski, przełączanie miast, pętla pozycji
  MapLayers.java         - warstwy MapLibre (przystanki, pojazdy, trasy, lokalizacja)
  Sheet.java             - bazowa klasa wysuwanych paneli (przeciąganie palcem)
  CitySheet.java         - wybór miasta (wyszukiwarka, X, bez stanu MINI)
  SearchSheet.java       - wyszukiwanie przystanków / ulubione / ostatnie / najbliższe
  LinesSheet.java        - lista linii miasta w zakładkach typów
  StopSheet.java         - tablica odjazdów + rozkłady (alpha-1.6.1)
  VehicleSheet.java      - szczegóły pojazdu + oś czasu trasy
  RouteTimelineView.java - rysowanie osi czasu trasy
  Gtfs.java              - GTFS: trasy, rozkłady, kalendarz usług (kolejka z priorytetami)
  GtfsRt.java            - GTFS-Realtime (vehiclePositions, własny parser protobuf)
  Api.java               - warstwa HTTP + cache przystanków na dysku
  Models.java            - modele danych + palety kolorów
  Cities.java            - katalog źródeł danych
  Prefs.java             - SharedPreferences
  HelpActivity.java      - „Jak używać”
```



Licencja ikon: Material Design Icons (Pictogrammers), Apache 2.0.


## 1.5.0

- **Planowanie tras (Transitous / MOTIS v6)**: nowa zakładka „Trasa” w stylu Jakdojade —
  pola Skąd/Dokąd (wyszukiwanie, „Moja lokalizacja”, wskazanie punktu na mapie z
  odwrotnym geokodowaniem), odjazd/przyjazd o wybranej godzinie (także jutro i
  kolejne dni), karty połączeń z plakietkami linii, szczegółami przystanków,
  opóźnieniami na żywo i stronicowaniem „Wcześniejsze/Późniejsze”; przycisk
  „Pokaż na mapie” rysuje całą trasę (pieszo — linia przerywana, przejazdy —
  w kolorach linii). Planowanie korzysta z danych czasu rzeczywistego.
- **Poprawka: odświeżanie po powrocie z tła** — po zminimalizowaniu i powrocie
  aplikacja natychmiast pobiera dane i samonaprawia warstwy mapy (utrata
  natywnego stylu po zniszczeniu powierzchni GL już nie wstrzymuje odświeżania);
  odświeżanie lokalizacji wznawia się automatycznie (GPS co 5 s, sieć co 6 s)
- **Poprawka: mapa świata (0,0) przy starcie** — kamera startowa jest teraz
  ustawiana po załadowaniu stylu mapy (dotychczasowe wywołanie w onCreate było
  ignorowane); zepsuta zapisana kamera wraca do centrum miasta, a z (0,0)
  nigdy nie zapisuje. Start: pierwsze uruchomienie → Warszawa, dalej →
  ostatnie miasto; z daną zgodą na lokalizację → wyśrodkowanie na pozycji
  użytkownika i automatyczne wybór najbliższego miasta
- **Panel linii miasta**: przycisk (czarna ikona na białym tle) nad
  przełącznikami typów pojazdów otwiera listę wszystkich linii w zakładkach
  (Autobusy / Tramwaje / Kolej / Metro / …); kliknięcie linii uruchamia
  wyszukiwanie jej pojazdów na żywo
- Kropki pojazdów po oddaleniu mają kolory swoich linii (z białym obrysem),
  żeby linie odróżniały się nawet z daleka
- **Rozkłady jazdy pogrupowane godzinami**: godzina po lewej, minuty obok w
  jednym wierszu (15 | 02 08 22); warianty tras kursów mają kolory i małą
  literę indeksu przy minucie (a, b, c…), a legenda na dole wyjaśnia, co
  litery i kolory oznaczają (kierunek kursu)
- Ustawienia: drobne opcje (Ukryj ikonę pojazdu, oryginalne kolory, suwaki
  progów zoomu) przeniesione do nowej sekcji „Zaawansowane”
- Testy: RoutePlannerTest (parser planu, polyliny, czasy ISO) — zielone;
  testy aktywności mapy pomijane bez natywnej biblioteki MapLibre (Assume)

## 1.4.1

- Płynne odświeżanie inaczej: natychmiast po odebraniu pakietu danych pojazd
  szybkim, płynnym przesuwem (0,6–2,4 s zależnie od dystansu) dojeżdża na nową
  pozycję wzdłuż swojej trasy — animacja nie rozciąga się już na cały okres
  odświeżania i nie trzeba czekać na kolejny pakiet
- Pojazd, który wypadł z odpowiedzi API (znajdował się poza kadrem zapytania),
  zostaje na mapie przez okres karencji (35 s) — zamiast znikać do najbliższej
  aktualizacji; przy zmianie miasta lista jest czyszczona na twardo
- Przycisk ręcznego odświeżania natychmiast pobiera dane na nowo (również PKP)
  i przesuwa wszystkie pojazdy w płynnym ruchu
- Klepsydra przy ładowaniu danych miasta: mała ikona przewracająca się o 180 stopni
  co ~2 s (nie kręcąca się w kółko), widoczna dopóki przystanki i pojazdy się
  wczytują — także przy starcie aplikacji i po powrocie do niej
- Domyślnie włączona automatyczna zmiana miasta oraz oryginalne (nadawcy) kolory
  plakietek pojazdów

## 1.4.0

- Krytyczna poprawka: klik w konkretny odjazd (np. 15:03) otwiera TEN kurs — dopasowanie
  wyłącznie po linii + brygadzie; jeśli pojazd jeszcze nie wyjechał, otwiera się planowany
  przebieg z GTFS zamiast "najszybszego" pojazdu linii
- Kurs planowy (pojazd niewyjechał): podgląd trasy z rozkładu, godzina odjazdu zamiast
  opóźnienia, bez "za X min" i bez "Planowo" na liście przystanków i tablicy odjazdów
- Menu pojazdu: czwarty stan MINI (sam tytuł + przyciski), treść panelu dopasowuje wysokość
  do stanu — lista daje się zescrollować do samego dołu także bez rozwijania na całość
- Pogrubiona linia trasy (podgląd i mapa); marker pojazdu na podglądzie i jego trasie
  nigdy nie zamienia się w kropkę
- Zanikanie krawędzi paska z liniami, gdy jest więcej kafelków do scrollowania
- Miasto zmienia się automatycznie po 3 s spokoju kamery (także z feedów ogólnopolskich);
  przycisk ręcznego odświeżania z 5-sekundowym licznikiem cooldownu
- Pojazdy i przystanki włączone przy każdym starcie; filtry typów resetują się po zmianie miasta
- Poprawka focuseowania ulubionych/w trasie (brak lotów "w świat" przy braku współrzędnych)

## 1.3.0

- Mapa wektorowa MapLibre — ten sam styl co zbiorkom.live (OpenFreeMap / OpenMapTiles);
  3 podkłady lokalnie: Podstawowa (wektor), Standard (OSM), Satelita (Esri)
- Przystanki jako kolorowe kropki: zielone autobusowe (tylko po mocnym zoomie),
  pomarańczowe stacje kolejowe, różowe metro, niebieskie tramwaje
- Pojazdy jako obiekty na trasie z numerem linii nad symbolem, snapowane do przebiegów
  GTFS i płynnie jadące po trasie między odświeżeniami
- Pociągi PKP zawsze widoczne na mapie, niezależnie od miasta
- Progi zoomu konfigurowalne w profilu "Nakładka debugu" (3 suwaki z odczytem liczbowym)
- Wyszukiwanie: bez lagów (indeks + debounce), stacje kolejowe z ikonami, wyniki
  z innych miast automatycznie przełączają miasto
- Filtr "przejazdy techniczne" (PT, "...") — domyślnie włączony
- Rozkłady bez ramki przycisku, przebudowana czytelna tabela godzin
- Poprawki: przycisk miasta, przewijanie listy w pojeździe, znikanie pojazdu przy przesuwaniu
