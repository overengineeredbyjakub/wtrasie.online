package online.wtrasie.app;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Static GTFS access: downloads (and caches for 24 h) the agency GTFS zip and
 * extracts, on demand:
 *  - the full stop list + times of one trip (vehicle route preview),
 *  - the shape polyline of a trip,
 *  - the full timetable of a stop: per-route times tagged with service ids +
 *    the calendar of every service (alpha-1.6.1 — the day-type / date filtering
 *    happens client-side in StopSheet).
 * All parsing streams the zip entries; only the requested rows are kept.
 *
 * alpha-1.6.1: GTFS zip work runs on a DEDICATED priority queue — a tapped
 * vehicle's trip never waits behind a bulk timetable parse, and the long zip
 * downloads never starve the live positions fetches on Api.EXE.
 */
public class Gtfs {

    private static final long TTL = 24L * 3600 * 1000;
    private static final int TRIP_CACHE_MAX = 24;
    private static final int TT_CACHE_MAX = 12;

    public static class StopTime {
        public String stopId = "";
        public int seq;
        public int arrSec, depSec; // seconds after midnight of the service day
        public String name = "";
        public double lat, lon;
    }

    public static class Trip {
        public String tripId = "", routeId = "", serviceId = "", shapeId = "", headsign = "", brigade = "";
        public List<StopTime> stops = new ArrayList<>();
        public List<double[]> shape = new ArrayList<>(); // {lat, lon}
    }

    public static class Tt {
        public int timeSec;
        public String headsign = "";
        public String serviceId = ""; // alpha-1.6.1: the day/date filter happens client-side
    }

    /** Timetable of one route at one stop (every service variant included). */
    public static class RouteTt {
        public String routeId = "", routeName = "";
        public int routeColor;
        public List<Tt> times = new ArrayList<>(); // sorted by time
    }

    /** alpha-1.6.1: calendar of one GTFS service — the client-side date resolver. */
    public static class Svc {
        public boolean[] days = new boolean[8]; // index 1..7 = Mon..Sun
        public String start = "", end = "";      // "YYYYMMDD" (may be empty)
        public final Map<String, Boolean> exceptions = new HashMap<>(); // ymd -> added/removed

        /** True when this service runs on the given date (exceptions win). */
        public boolean activeOn(String ymd) {
            if (ymd == null || ymd.length() != 8) return false;
            Boolean ex = exceptions.get(ymd);
            if (ex != null) return ex;
            int dow = dayOfWeek(ymd);
            if (dow < 1 || dow > 7 || !days[dow]) return false;
            return (start.length() == 0 || start.compareTo(ymd) <= 0)
                    && (end.length() == 0 || end.compareTo(ymd) >= 0);
        }

        /** 0 = dni robocze, 1 = soboty, 2 = niedziele/święta, 3 = codziennie,
         *  4 = pon–sob, 5 = inny wariant, -1 = brak dni. */
        public int dayType() {
            boolean wd = days[1] && days[2] && days[3] && days[4] && days[5];
            boolean noWd = !days[1] && !days[2] && !days[3] && !days[4] && !days[5];
            boolean sat = days[6], sun = days[7];
            boolean any = false;
            for (int d = 1; d <= 7; d++) { if (days[d]) { any = true; break; } }
            if (!any) return -1;
            if (wd && sat && sun) return 3;
            if (wd && !sat && !sun) return 0;
            if (noWd && sat && !sun) return 1;
            if (noWd && !sat && sun) return 2;
            if (wd && sat && !sun) return 4;
            return 5;
        }
    }

    /** Everything needed to render a stop's timetable in the UI. */
    public static class StopTt {
        public final Map<String, RouteTt> routes = new LinkedHashMap<>(); // routeId -> route
        public final Map<String, Svc> services = new HashMap<>();         // serviceId -> calendar
    }

    public interface TripCb {
        void on(Trip trip, String error);
    }

    public interface StopTtCb {
        void on(StopTt data, String error);
    }

    /** Result of a scheduled-trip lookup: GTFS trip_id + service day midnight. */
    public interface FoundTripCb {
        void on(String tripId, long serviceDayMs, String error);
    }

    // ---------------------------------------------------------------- caches

    /** trip cache: city/agency/tripId -> Trip */
    private static final LinkedHashMap<String, Trip> TRIP_CACHE = new LinkedHashMap<String, Trip>() {
        @Override
        protected boolean removeEldestEntry(Entry<String, Trip> eldest) {
            return size() > TRIP_CACHE_MAX;
        }
    };

    /** timetable cache: city/agency/stopId -> StopTt */
    private static final LinkedHashMap<String, StopTt> TT_CACHE = new LinkedHashMap<String, StopTt>() {
        @Override
        protected boolean removeEldestEntry(Entry<String, StopTt> eldest) {
            return size() > TT_CACHE_MAX;
        }
    };

    private static final Set<String> IN_FLIGHT_ZIPS = new HashSet<>();

    // ---------------------------------------------------------------- background queue

    /**
     * alpha-1.6.1: GTFS zip work runs on its own two-thread PRIORITY queue.
     * Priority 0 = an interactively tapped vehicle's trip (user is waiting,
     * eyes on the screen); priority 2 = a timetable opened in the stop sheet.
     * Api.EXE keeps serving positions/stops/geocode — a long zip download can
     * never again starve the live data (the "route loads forever" bug).
     */
    private static final java.util.concurrent.ThreadPoolExecutor ZIP_EXE =
            new java.util.concurrent.ThreadPoolExecutor(3, 3, 15L,
                    java.util.concurrent.TimeUnit.SECONDS,
                    new java.util.concurrent.PriorityBlockingQueue<Runnable>()) {
                {
                    allowCoreThreadTimeOut(true);
                }
            };

    private static class PrioTask implements Runnable, Comparable<PrioTask> {
        private final int prio;
        private final Runnable run;

        PrioTask(int prio, Runnable run) {
            this.prio = prio;
            this.run = run;
        }

        @Override
        public void run() {
            try {
                run.run();
            } catch (Throwable t) {
                android.util.Log.w("Gtfs", "zip task", t);
            }
        }

        @Override
        public int compareTo(PrioTask o) {
            return Integer.compare(prio, o.prio);
        }
    }

    /** 0 = interactive trip, 2 = timetable bulk read. */
    private static void zipTask(int prio, Runnable r) {
        ZIP_EXE.execute(new PrioTask(prio, r));
    }

    public static void clearCaches() {
        synchronized (TRIP_CACHE) {
            TRIP_CACHE.clear();
        }
        synchronized (TT_CACHE) {
            TT_CACHE.clear();
        }
    }

    // ---------------------------------------------------------------- public API

    /**
     * alpha-1.6.2: background PREFETCH of a city's GTFS zips. A tapped
     * vehicle's trip used to wait for the WHOLE zip download (20+ MB on
     * mobile = the "over a minute for the Helsinki ferry" bug). Now the zips
     * warm up in the background (lowest priority, one agency at a time, 24 h
     * disk cache) the moment a city becomes active — by the time the user
     * taps a vehicle, its trip reads from the warm cache.
     */
    public static void prefetch(final Context ctx, final String city, final java.util.List<String> agencies) {
        if (ctx == null || city == null || city.isEmpty()) return;
        final java.util.List<String> list = new java.util.ArrayList<>();
        if (agencies != null) {
            for (String a : agencies) {
                if (a != null && !a.isEmpty() && !list.contains(a) && list.size() < 4) list.add(a);
            }
        }
        if (!list.contains("default")) list.add(0, "default");
        zipTask(3, () -> {
            for (String agency : list) {
                try {
                    ZipFile z = obtainZip(zipFile(ctx, city, agency), city, agency);
                    if (z != null) {
                        try {
                            z.close();
                        } catch (IOException ignored) {
                        }
                    }
                } catch (Throwable t) {
                    android.util.Log.w("Gtfs", "prefetch " + city + "/" + agency + " " + t);
                }
            }
        });
    }

    /**
     * alpha-1.6.2: silent auto-retry of a failed trip load. A flaky mobile
     * network used to leave "the route never loads" until the user hit
     * refresh manually; now the load retries twice (1.5 s, 4 s) before it
     * reports an error. "notfound" is NOT retried (it is a real answer).
     */
    public static void loadTrip(final Context ctx, final String city, final String agency,
                                final String tripId, final TripCb cb) {
        loadTripAttempt(ctx, city, agency, tripId, cb, 0);
    }

    private static void loadTripAttempt(final Context ctx, final String city, final String agency,
                                       final String tripId, final TripCb cb, final int attempt) {
        final String key = city + "/" + agency + "/" + tripId;
        synchronized (TRIP_CACHE) {
            Trip t = TRIP_CACHE.get(key);
            if (t != null) {
                cb.on(t, null);
                return;
            }
        }
        withZip(ctx, city, agency, 0, (zip, err) -> {
            Trip trip = null;
            String e = err;
            if (zip != null) {
                try {
                    trip = readTrip(zip, tripId);
                    if (trip == null) e = "notfound";
                } catch (Throwable t) {
                    e = "parse";
                    android.util.Log.w("Gtfs", "readTrip", t);
                }
            }
            if (trip != null) {
                synchronized (TRIP_CACHE) {
                    TRIP_CACHE.put(key, trip);
                }
            }
            final Trip tr = trip;
            final String er = e;
            Api.MAIN.post(() -> {
                try {
                    if (tr == null && "network".equals(er) && attempt < 2) {
                        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                        h.postDelayed(() -> {
                            try {
                                loadTripAttempt(ctx, city, agency, tripId, cb, attempt + 1);
                            } catch (Throwable ignored) {
                            }
                        }, attempt == 0 ? 1500L : 4000L);
                        return;
                    }
                    cb.on(tr, er);
                } catch (Throwable ignored) {
                }
            });
        });
    }

    /**
     * alpha-1.6.1: the WHOLE timetable of a stop — every route, every service
     * variant, times tagged with service ids + the full calendar. Day-type and
     * concrete-date filtering happens in the UI (fast, no re-download when
     * the user switches days). Bulk priority 2.
     * alpha-1.6.2: a network failure retries once after 2.5 s — the
     * "route list stays blank until a manual refresh" bug.
     */
    public static void loadStopTimetable(final Context ctx, final String city, final String agency,
                                         final String stopId, final StopTtCb cb) {
        loadStopTimetableAttempt(ctx, city, agency, stopId, cb, 0);
    }

    private static void loadStopTimetableAttempt(final Context ctx, final String city, final String agency,
                                                 final String stopId, final StopTtCb cb, final int attempt) {
        final String key = city + "/" + agency + "/" + stopId;
        synchronized (TT_CACHE) {
            StopTt cached = TT_CACHE.get(key);
            if (cached != null) {
                cb.on(cached, null);
                return;
            }
        }
        withZip(ctx, city, agency, 2, (zip, err) -> {
            StopTt data = null;
            String e = err;
            if (zip != null) {
                try {
                    data = readStopTimetable(zip, stopId);
                    if (data != null && data.routes.isEmpty()) e = "notfound";
                } catch (Throwable t) {
                    e = "parse";
                    android.util.Log.w("Gtfs", "readStopTimetable", t);
                }
            }
            if (data != null && e == null) {
                synchronized (TT_CACHE) {
                    TT_CACHE.put(key, data);
                }
            }
            final StopTt res = data;
            final String er = e;
            Api.MAIN.post(() -> {
                try {
                    if (res == null && "network".equals(er) && attempt < 1) {
                        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                        h.postDelayed(() -> {
                            try {
                                loadStopTimetableAttempt(ctx, city, agency, stopId, cb, attempt + 1);
                            } catch (Throwable ignored) {
                            }
                        }, 2500L);
                        return;
                    }
                    cb.on(res, er);
                } catch (Throwable ignored) {
                }
            });
        });
    }

    private interface ZipCb {
        void on(ZipFile zip, String error);
    }

    /**
     * Gives the caller an open ZipFile (valid until the callback returns — it
     * is closed afterwards).
     *
     * alpha-1.6.1 fix of the "empty route list until manual refresh" bug: the
     * old waiter gave up after one 30 s wait and then re-downloaded the SAME
     * file in parallel — two writers on one .tmp path left a broken zip that
     * failed to open (hence "network" errors that needed a manual retry).
     * Now waiters loop properly until the owner's download finishes and reuse
     * the result.
     */
    private static void withZip(Context ctx, String city, String agency, int prio, ZipCb cb) {
        final File f = zipFile(ctx, city, agency);
        zipTask(prio, () -> {
            ZipFile z = obtainZip(f, city, agency);
            runZipCb(cb, z);
        });
    }

    /** Fresh cached zip, or a single owner download (others wait and reuse). */
    private static ZipFile obtainZip(File f, String city, String agency) {
        for (int attempt = 0; attempt < 3; attempt++) {
            boolean fresh = f.isFile() && System.currentTimeMillis() - f.lastModified() < TTL;
            if (fresh) {
                ZipFile z = openZip(f);
                if (z != null) return z;
                f.delete(); // corrupted
                fresh = false;
            }
            // nobody downloading right now? become the owner and fetch it
            if (tryOwnDownload(f)) {
                try {
                    if (!f.isFile() || System.currentTimeMillis() - f.lastModified() >= TTL) {
                        try {
                            download(Api.gtfsUrl(city, agency), f);
                        } catch (Throwable t) {
                            android.util.Log.w("Gtfs", "download " + city + "/" + agency + " " + t);
                        }
                    }
                } finally {
                    releaseOwnDownload(f);
                }
                continue; // loop re-checks the (hopefully fresh) file
            }
            waitForDownload(f, 60_000L); // somebody else owns it — reuse their result
        }
        // last resort: even a stale file beats nothing
        return f.isFile() ? openZip(f) : null;
    }

    private static boolean tryOwnDownload(File f) {
        synchronized (IN_FLIGHT_ZIPS) {
            if (IN_FLIGHT_ZIPS.contains(f.getAbsolutePath())) return false;
            IN_FLIGHT_ZIPS.add(f.getAbsolutePath());
            return true;
        }
    }

    private static void releaseOwnDownload(File f) {
        synchronized (IN_FLIGHT_ZIPS) {
            IN_FLIGHT_ZIPS.remove(f.getAbsolutePath());
            IN_FLIGHT_ZIPS.notifyAll();
        }
    }

    private static void waitForDownload(File f, long maxMs) {
        synchronized (IN_FLIGHT_ZIPS) {
            long deadline = System.currentTimeMillis() + maxMs;
            while (IN_FLIGHT_ZIPS.contains(f.getAbsolutePath())
                    && System.currentTimeMillis() < deadline) {
                try {
                    IN_FLIGHT_ZIPS.wait(1000);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    private static void runZipCb(ZipCb cb, ZipFile z) {
        String err = z == null ? "network" : null;
        try {
            cb.on(z, err);
        } catch (Throwable t) {
            android.util.Log.w("Gtfs", "zipcb", t);
        } finally {
            if (z != null) {
                try {
                    z.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static ZipFile openZip(File f) {
        try {
            return new ZipFile(f);
        } catch (Throwable t) {
            return null;
        }
    }

    private static File zipFile(Context ctx, String city, String agency) {
        return new File(ctx.getCacheDir(), "gtfs-" + city + "-" + (agency == null || agency.isEmpty() ? "default" : agency) + ".zip");
    }

    private static void download(String urlStr, File target) throws IOException {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(urlStr).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(90000);
            c.setRequestProperty("User-Agent", "wtrasie.online/1.2 (Android)");
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            File tmp = new File(target.getAbsolutePath() + ".tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            try {
                in.close();
            } catch (IOException ignored) {
            }
            if (!tmp.renameTo(target)) {
                target.delete();
                tmp.renameTo(target);
            }
        } finally {
            try {
                c.disconnect();
            } catch (Throwable ignored) {
            }
        }
    }

    // ---------------------------------------------------------------- CSV helpers

    /** Returns a fast field extractor for a CSV line, given the header column order. */
    private static int[] colIdx(String header, String... names) {
        int[] idx = new int[names.length];
        List<String> cols = splitCsv(header);
        for (int i = 0; i < names.length; i++) {
            idx[i] = cols.indexOf(names[i]);
        }
        return idx;
    }

    private static List<String> splitCsv(String line) {
        List<String> out = new ArrayList<>();
        int start = 0;
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') quoted = !quoted;
            else if (ch == ',' && !quoted) {
                out.add(line.substring(start, i));
                start = i + 1;
            }
        }
        out.add(line.substring(start));
        return out;
    }

    private static BufferedReader reader(ZipFile zip, String entry) throws IOException {
        ZipEntry e = zip.getEntry(entry);
        if (e == null) return null;
        InputStream in = zip.getInputStream(e);
        return new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8), 1 << 16);
    }

    /**
     * alpha-1.6.2 FIX of the '"Dworzec' broken-name bug: the field extractor is
     * now QUOTE-AWARE. GTFS files quote any field containing a comma
     * (Helsinki: "Lansiterm. 2, tulo 0240", "Suomenlinna, paalait") — the old
     * splitter cut them at the inner comma, leaving a stray '"' and shifting
     * every later column (names truncated, coordinates lost). Quoted fields
     * are returned unquoted (doubled "" -> ").
     */
    private static String fieldAt(String line, int idx) {
        if (idx < 0) return "";
        int cur = -1, start = 0;
        boolean quoted = false;
        for (int i = 0; i <= line.length(); i++) {
            char ch = i < line.length() ? line.charAt(i) : ',';
            if (ch == '"') {
                quoted = !quoted;
            } else if (ch == ',' && !quoted) {
                cur++;
                if (cur == idx) return unquote(line.substring(start, i));
                start = i + 1;
                if (cur > idx) break;
            }
        }
        return "";
    }

    /** "Dworzec Glowny, zachod" (quoted CSV field) -> the plain text inside. */
    private static String unquote(String raw) {
        String s = raw;
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length() - 1).replace("\"\"", "\"");
        }
        return s;
    }

    /** "25:36:00" -> seconds after midnight. */
    private static int hms(String s) {
        if (s == null || s.length() < 4) return 0;
        try {
            String[] p = s.split(":");
            int h = Integer.parseInt(p[0].trim());
            int m = p.length > 1 ? Integer.parseInt(p[1].trim()) : 0;
            int sec = p.length > 2 ? Integer.parseInt(p[2].trim()) : 0;
            return h * 3600 + m * 60 + sec;
        } catch (Exception e) {
            return 0;
        }
    }

    // ---------------------------------------------------------------- trip reading

    private static Trip readTrip(ZipFile zip, String tripId) throws IOException {
        // 1. trip row
        Trip trip = null;
        BufferedReader r = reader(zip, "trips.txt");
        if (r == null) return null;
        try {
            String header = r.readLine();
            if (header == null) return null;
            int[] ix = colIdx(header, "trip_id", "route_id", "service_id", "shape_id", "trip_headsign", "brigade");
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isEmpty()) continue;
                if (line.startsWith(tripId) && fieldAt(line, ix[0]).equals(tripId)) {
                    trip = new Trip();
                    trip.tripId = tripId;
                    trip.routeId = fieldAt(line, ix[1]);
                    trip.serviceId = fieldAt(line, ix[2]);
                    trip.shapeId = fieldAt(line, ix[3]);
                    trip.headsign = fieldAt(line, ix[4]);
                    trip.brigade = fieldAt(line, ix[5]);
                    break;
                }
            }
        } finally {
            r.close();
        }
        if (trip == null) return null;

        // 2. stop_times of the trip
        r = reader(zip, "stop_times.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "trip_id", "arrival_time", "departure_time", "stop_id", "stop_sequence");
                    String line;
                    List<StopTime> sts = new ArrayList<>();
                    while ((line = r.readLine()) != null) {
                        if (line.isEmpty()) continue;
                        if (line.startsWith(tripId) && fieldAt(line, ix[0]).equals(tripId)) {
                            StopTime st = new StopTime();
                            st.arrSec = hms(fieldAt(line, ix[1]));
                            st.depSec = hms(fieldAt(line, ix[2]));
                            st.stopId = fieldAt(line, ix[3]);
                            try {
                                st.seq = Integer.parseInt(fieldAt(line, ix[4]).trim());
                            } catch (Exception ignored) {
                            }
                            sts.add(st);
                        }
                    }
                    Collections.sort(sts, (a, b) -> Integer.compare(a.seq, b.seq));
                    trip.stops = sts;
                }
            } finally {
                r.close();
            }
        }

        // 3. stop names + coords for the used ids
        if (!trip.stops.isEmpty()) {
            Set<String> ids = new HashSet<>();
            for (StopTime st : trip.stops) ids.add(st.stopId);
            r = reader(zip, "stops.txt");
            if (r != null) {
                try {
                    String header = r.readLine();
                    if (header != null) {
                        int[] ix = colIdx(header, "stop_id", "stop_name", "stop_lat", "stop_lon");
                        String line;
                        while ((line = r.readLine()) != null) {
                            String id = fieldAt(line, ix[0]);
                            if (!ids.contains(id)) continue;
                            for (StopTime st : trip.stops) {
                                if (st.stopId.equals(id)) {
                                    st.name = fieldAt(line, ix[1]);
                                    try {
                                        st.lat = Double.parseDouble(fieldAt(line, ix[2]));
                                        st.lon = Double.parseDouble(fieldAt(line, ix[3]));
                                    } catch (Exception ignored) {
                                    }
                                }
                            }
                        }
                    }
                } finally {
                    r.close();
                }
            }
        }

        // 4. shape points
        if (trip.shapeId != null && !trip.shapeId.isEmpty()) {
            r = reader(zip, "shapes.txt");
            if (r != null) {
                try {
                    String header = r.readLine();
                    if (header != null) {
                        int[] ix = colIdx(header, "shape_id", "shape_pt_lat", "shape_pt_lon", "shape_pt_sequence");
                        String line;
                        List<double[]> pts = new ArrayList<>();
                        while ((line = r.readLine()) != null) {
                            if (line.startsWith(trip.shapeId) && fieldAt(line, ix[0]).equals(trip.shapeId)) {
                                try {
                                    double lat = Double.parseDouble(fieldAt(line, ix[1]));
                                    double lon = Double.parseDouble(fieldAt(line, ix[2]));
                                    int seq = 0;
                                    try {
                                        seq = Integer.parseInt(fieldAt(line, ix[3]).trim());
                                    } catch (Exception ignored) {
                                    }
                                    pts.add(new double[]{lat, lon, seq});
                                } catch (Exception ignored) {
                                }
                            }
                        }
                        if (!pts.isEmpty()) {
                            pts.sort(Comparator.comparingDouble(a -> a[2]));
                            List<double[]> shape = new ArrayList<>(pts.size());
                            for (double[] p : pts) shape.add(new double[]{p[0], p[1]});
                            trip.shape = shape;
                        }
                    }
                } finally {
                    r.close();
                }
            }
        }
        // fallback shape: straight lines through stops
        if (trip.shape.isEmpty()) {
            for (StopTime st : trip.stops) {
                if (st.lat != 0 || st.lon != 0) trip.shape.add(new double[]{st.lat, st.lon});
            }
        }
        return trip;
    }

    // ---------------------------------------------------------------- timetable reading

    /**
     * alpha-1.6.1: the WHOLE stop timetable — every route, every service
     * variant, each time tagged with its service id, plus the full calendar
     * (weekly pattern + date range + ALL calendar_dates exceptions). The UI
     * then filters by day type or by a concrete date without another download.
     */
    private static StopTt readStopTimetable(ZipFile zip, String stopId) throws IOException {
        StopTt out = new StopTt();

        // 1. weekly services from calendar.txt
        BufferedReader r = reader(zip, "calendar.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "service_id", "monday", "tuesday", "wednesday",
                            "thursday", "friday", "saturday", "sunday", "start_date", "end_date");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String svc = fieldAt(line, ix[0]);
                        if (svc.isEmpty()) continue;
                        Svc s = new Svc();
                        for (int d = 0; d < 7; d++) {
                            s.days[d + 1] = "1".equals(fieldAt(line, ix[d + 1]).trim());
                        }
                        s.start = fieldAt(line, ix[8]).trim();
                        s.end = fieldAt(line, ix[9]).trim();
                        out.services.put(svc, s);
                    }
                }
            } finally {
                r.close();
            }
        }

        // 2. ALL exceptions (1 = added, 2 = removed) — services missing from
        // calendar.txt (calendar_dates-only feeds) get an empty calendar
        r = reader(zip, "calendar_dates.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "service_id", "date", "exception_type");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String svc = fieldAt(line, ix[0]);
                        if (svc.isEmpty()) continue;
                        Svc s = out.services.get(svc);
                        if (s == null) {
                            s = new Svc();
                            out.services.put(svc, s);
                        }
                        s.exceptions.put(fieldAt(line, ix[1]).trim(),
                                "1".equals(fieldAt(line, ix[2]).trim()));
                    }
                }
            } finally {
                r.close();
            }
        }

        // 2b. alpha-1.6.2 — THE timetable correctness fix. zbiorkom feeds are
        // calendar_dates-ONLY: every service carries its run dates as added
        // exceptions and NO weekly pattern. dayType() then answered -1, ALL
        // services collapsed into one giant "Inny wariant" chip and the course
        // list interleaved times from school weekdays, vacation weekdays,
        // Saturdays, Sundays and one-off replacement services — the reported
        // "14:46 14:46 14:48 14:56 though the line runs every 30 min" mess.
        // Now: for a service with NO weekly pattern, INFER the pattern from
        // its added dates (a weekday counts when it has >= 2 dates AND >= 1/4
        // of the busiest weekday — single holiday blips stay out of the
        // pattern; the per-date exceptions still answer exactly for a picked
        // calendar date) and set the date range from the first/last date, so
        // school vs vacation variants land in SEPARATE chips with ranges.
        for (Svc s : out.services.values()) {
            boolean any = false;
            for (int d = 1; d <= 7; d++) {
                if (s.days[d]) {
                    any = true;
                    break;
                }
            }
            if (any || s.exceptions.isEmpty()) continue; // calendar.txt pattern
            int[] dowHits = new int[8];
            int maxHits = 0;
            String minDate = null, maxDate = null;
            for (Map.Entry<String, Boolean> ex : s.exceptions.entrySet()) {
                if (!Boolean.TRUE.equals(ex.getValue())) continue; // removals
                String ymd = ex.getKey();
                int dow = dayOfWeek(ymd);
                if (dow >= 1 && dow <= 7) {
                    dowHits[dow]++;
                    if (dowHits[dow] > maxHits) maxHits = dowHits[dow];
                }
                if (ymd.length() == 8) {
                    if (minDate == null || ymd.compareTo(minDate) < 0) minDate = ymd;
                    if (maxDate == null || ymd.compareTo(maxDate) > 0) maxDate = ymd;
                }
            }
            int threshold = Math.max(2, maxHits / 4);
            for (int d = 1; d <= 7; d++) {
                s.days[d] = dowHits[d] >= threshold;
            }
            if (s.start.isEmpty()) s.start = minDate == null ? "" : minDate;
            if (s.end.isEmpty()) s.end = maxDate == null ? "" : maxDate;
        }

        // 3. all trips (route / service / headsign per trip id)
        Map<String, String> tripRoute = new HashMap<>();     // tripId -> routeId
        Map<String, String> tripService = new HashMap<>();   // tripId -> serviceId
        Map<String, String> tripHeadsign = new HashMap<>();  // tripId -> headsign
        r = reader(zip, "trips.txt");
        if (r == null) return out;
        try {
            String header = r.readLine();
            if (header == null) return out;
            int[] ix = colIdx(header, "trip_id", "route_id", "service_id", "trip_headsign");
            String line;
            while ((line = r.readLine()) != null) {
                String tripId = fieldAt(line, ix[0]);
                if (tripId.isEmpty()) continue;
                tripRoute.put(tripId, fieldAt(line, ix[1]));
                tripService.put(tripId, fieldAt(line, ix[2]));
                tripHeadsign.put(tripId, fieldAt(line, ix[3]));
            }
        } finally {
            r.close();
        }

        // 4. stop_times rows at our stop — NO date filter (client-side filtering)
        final String wantApi = apiStopId(stopId);
        Map<String, RouteTt> routes = new LinkedHashMap<>();
        r = reader(zip, "stop_times.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "trip_id", "departure_time", "stop_id");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String sid = fieldAt(line, ix[2]);
                        if (!sid.equals(stopId) && !apiStopId(sid).equals(wantApi)) continue;
                        String tripId = fieldAt(line, ix[0]);
                        String routeId = tripRoute.get(tripId);
                        if (routeId == null) continue;
                        Tt tt = new Tt();
                        tt.timeSec = hms(fieldAt(line, ix[1]));
                        tt.headsign = tripHeadsign.get(tripId);
                        tt.serviceId = tripService.get(tripId) == null ? "" : tripService.get(tripId);
                        RouteTt rt = routes.get(routeId);
                        if (rt == null) {
                            rt = new RouteTt();
                            rt.routeId = routeId;
                            rt.routeName = routeId;
                            routes.put(routeId, rt);
                        }
                        rt.times.add(tt);
                    }
                }
            } finally {
                r.close();
            }
        }

        // 5. route names/colors, drop empty routes, sort by time
        r = reader(zip, "routes.txt");
        Map<String, String[]> routeMeta = new HashMap<>();
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "route_id", "route_short_name", "route_long_name", "route_color");
                    String line;
                    while ((line = r.readLine()) != null) {
                        routeMeta.put(fieldAt(line, ix[0]), new String[]{
                                fieldAt(line, ix[1]), fieldAt(line, ix[2]), fieldAt(line, ix[3])});
                    }
                }
            } finally {
                r.close();
            }
        }
        for (Map.Entry<String, RouteTt> e : routes.entrySet()) {
            RouteTt rt = e.getValue();
            if (rt.times.isEmpty()) continue;
            String[] meta = routeMeta.get(e.getKey());
            if (meta != null) {
                rt.routeName = meta[0] == null || meta[0].isEmpty()
                        ? (meta[1] == null ? e.getKey() : meta[1]) : meta[0];
                rt.routeColor = Ui.parseColor(meta[2] == null || meta[2].isEmpty() ? null : "#" + meta[2], 0xFFD32F2F);
            }
            Collections.sort(rt.times, (a, b) -> Integer.compare(a.timeSec, b.timeSec));
            out.routes.put(e.getKey(), rt);
        }
        return out;
    }

    /** "YYYYMMDD" -> ISO day of week (1=Mon..7=Sun); 0 when unparsable. */
    static int dayOfWeek(String yyyymmdd) {
        try {
            GregorianCalendar c = new GregorianCalendar();
            c.setTimeZone(TimeZone.getTimeZone("UTC"));
            c.clear();
            c.set(Integer.parseInt(yyyymmdd.substring(0, 4)),
                    Integer.parseInt(yyyymmdd.substring(4, 6)) - 1,
                    Integer.parseInt(yyyymmdd.substring(6, 8)), 12, 0, 0);
            int dow = c.get(Calendar.DAY_OF_WEEK); // Sun=1..Sat=7
            return dow == 1 ? 7 : dow - 1;
        } catch (Exception e) {
            return 0;
        }
    }

    /** Midnight (device tz) of the GTFS service date "YYYYMMDD" in epoch ms. */
    public static long serviceDayEpoch(String yyyymmdd) {
        if (yyyymmdd == null || yyyymmdd.length() != 8) return 0;
        try {
            int y = Integer.parseInt(yyyymmdd.substring(0, 4));
            int m = Integer.parseInt(yyyymmdd.substring(4, 6));
            int d = Integer.parseInt(yyyymmdd.substring(6, 8));
            Calendar c = new GregorianCalendar();
            c.setTimeZone(TimeZone.getDefault());
            c.clear();
            c.set(y, m - 1, d, 0, 0, 0);
            return c.getTimeInMillis();
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * GTFS stop_id -> open API stop id. PKP zips use
     * "krakow-glowny-xuxpa----krakow-glowny-xuxpa:2"; the API id is the part
     * before "----" (platform suffix stripped).
     */
    public static String apiStopId(String gtfsStopId) {
        if (gtfsStopId == null) return "";
        String id = gtfsStopId.trim();
        int cut = id.indexOf("----");
        if (cut > 0) id = id.substring(0, cut);
        int p = id.lastIndexOf(':');
        if (p > 0 && id.length() - p <= 3) {
            boolean digits = true;
            for (int i = p + 1; i < id.length(); i++) {
                if (!Character.isDigit(id.charAt(i))) digits = false;
            }
            if (digits) id = id.substring(0, p);
        }
        return id;
    }

    // ---------------------------------------------------------------- scheduled trip lookup

    /**
     * alpha-1.6.0: find the trip a live vehicle is currently serving WITHOUT the
     * realtime feed (the GtfsRt id mapping misses some feeds — ferries etc.):
     * the trip of the route whose headsign matches and whose stop_times window
     * contains "now". Falls back to the route's nearest trip in time.
     */
    public static void findRunningTrip(final Context ctx, final String city, final String agency,
                                      final String routeId, final String routeName,
                                      final String headsign, final FoundTripCb cb) {
        withZip(ctx, city, agency, 0, (zip, err) -> {
            String tripId = null;
            long dayMs = 0;
            String e = err;
            if (zip != null) {
                try {
                    Object[] res = findRunningTripInZip(zip, routeId, routeName, headsign);
                    if (res != null) {
                        tripId = (String) res[0];
                        dayMs = (Long) res[1];
                    }
                    if (tripId == null) e = "notfound";
                } catch (Throwable t) {
                    e = "parse";
                    android.util.Log.w("Gtfs", "findRunningTrip", t);
                }
            }
            final String tid = tripId;
            final long day = dayMs;
            final String er = e;
            Api.MAIN.post(() -> {
                try {
                    cb.on(tid, day, er);
                } catch (Throwable ignored) {
                }
            });
        });
    }

    /**
     * {tripId, serviceDayMs} of the trip of the given route best matching the
     * headsign (exact when possible) whose time span covers the current moment.
     */
    private static Object[] findRunningTripInZip(ZipFile zip, String routeId, String routeName,
                                                 String headsign) throws IOException {
        final long now = System.currentTimeMillis();
        Calendar cal = new GregorianCalendar();
        cal.setTimeZone(TimeZone.getDefault());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        long midnight = cal.getTimeInMillis();
        int nowSec = (int) ((now - midnight) / 1000L);

        // 1. route_id from routes.txt by id or short name
        Set<String> routeTrips = new HashSet<>();
        Map<String, String> routeShortNames = new HashMap<>();
        BufferedReader r = reader(zip, "routes.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "route_id", "route_short_name");
                    String line;
                    while ((line = r.readLine()) != null) {
                        routeShortNames.put(fieldAt(line, ix[0]), fieldAt(line, ix[1]));
                    }
                }
            } finally {
                r.close();
            }
        }
        String normRouteName = Ui.norm(routeName);
        r = reader(zip, "trips.txt");
        if (r == null) return null;
        Map<String, String> tripHeadsign = new HashMap<>();
        try {
            String header = r.readLine();
            if (header != null) {
                int[] ix = colIdx(header, "trip_id", "route_id", "trip_headsign");
                String line;
                while ((line = r.readLine()) != null) {
                    String rid = fieldAt(line, ix[1]);
                    if (rid.isEmpty()) continue;
                    boolean ridEq = routeId != null && !routeId.isEmpty() && rid.equals(routeId);
                    String sn = routeShortNames.get(rid);
                    boolean nameEq = !normRouteName.isEmpty() && sn != null
                            && Ui.norm(sn).equals(normRouteName);
                    if (ridEq || nameEq) {
                        String tid = fieldAt(line, ix[0]);
                        routeTrips.add(tid);
                        tripHeadsign.put(tid, fieldAt(line, ix[2]));
                    }
                }
            }
        } finally {
            r.close();
        }
        if (routeTrips.isEmpty()) return null;

        // 2. first + last stop_time of each candidate trip (single scan)
        Map<String, int[]> span = new HashMap<>(); // tripId -> {firstSec, lastSec}
        r = reader(zip, "stop_times.txt");
        if (r == null) return null;
        try {
            String header = r.readLine();
            if (header == null) return null;
            int[] ix = colIdx(header, "trip_id", "departure_time", "stop_id");
            String line;
            while ((line = r.readLine()) != null) {
                String tid = fieldAt(line, ix[0]);
                if (!routeTrips.contains(tid)) continue;
                int depSec = hms(fieldAt(line, ix[1]));
                int[] sp = span.get(tid);
                if (sp == null) {
                    sp = new int[]{depSec, depSec};
                    span.put(tid, sp);
                } else {
                    if (depSec < sp[0]) sp[0] = depSec;
                    if (depSec > sp[1]) sp[1] = depSec;
                }
            }
        } finally {
            r.close();
        }

        // 3. best trip: headsign match wins, then one whose span contains now
        String best = null;
        int bestScore = -1;
        int bestMid = 0;
        String normHs = Ui.norm(headsign);
        for (Map.Entry<String, int[]> e : span.entrySet()) {
            int[] sp = e.getValue();
            int mid = (sp[0] + sp[1]) / 2;
            int diff = Math.abs(mid - nowSec);
            if (diff > 12 * 3600 && Math.abs(sp[0] - nowSec) > 6 * 3600) continue; // far in time
            boolean hsMatch = !normHs.isEmpty() && normHs.equals(Ui.norm(tripHeadsign.get(e.getKey())));
            // score: 2 = headsign match + covers now, 1 = covers now, 0 = closest anyway
            boolean coversNow = nowSec >= sp[0] - 1800 && nowSec <= sp[1] + 1800;
            int score = (hsMatch ? 2 : 0) + (coversNow ? 1 : 0);
            if (score > bestScore || (score == bestScore && diff < bestMid)) {
                bestScore = score;
                best = e.getKey();
                bestMid = diff;
            }
        }
        return best == null ? null : new Object[]{best, midnight};
    }

    /**
     * Find the GTFS trip of a scheduled departure: the trip of the given route
     * that serves the given stop at the given epoch time (±2 min). The service
     * day (which may start on the previous calendar day for night runs) is
     * returned too. Used when the user taps a departure whose vehicle has not
     * left yet — the opened preview must be THAT trip, not any running one.
     */
    public static void findScheduledTrip(final Context ctx, final String city, final String agency,
                                          final String routeId, final String routeName,
                                          final String stopId, final long depTimeMs, final FoundTripCb cb) {
        if (stopId == null || stopId.isEmpty() || depTimeMs <= 0) {
            cb.on(null, 0, "noinput");
            return;
        }
        withZip(ctx, city, agency, 0, (zip, err) -> {
            String tripId = null;
            long dayMs = 0;
            String e = err;
            if (zip != null) {
                try {
                    Object[] res = findScheduledTripInZip(zip, routeId, routeName, stopId, depTimeMs);
                    if (res != null) {
                        tripId = (String) res[0];
                        dayMs = (Long) res[1];
                    }
                    if (tripId == null) e = "notfound";
                } catch (Throwable t) {
                    e = "parse";
                    android.util.Log.w("Gtfs", "findScheduledTrip", t);
                }
            }
            final String tid = tripId;
            final long day = dayMs;
            final String er = e;
            Api.MAIN.post(() -> {
                try {
                    cb.on(tid, day, er);
                } catch (Throwable ignored) {
                }
            });
        });
    }

    /** {tripId (String), serviceDayMs (Long)} of the best matching stop_time row. */
    private static Object[] findScheduledTripInZip(ZipFile zip, String routeId, String routeName,
                                                   String stopId, long depTimeMs) throws IOException {
        final String wantApi = apiStopId(stopId);
        // service-day candidates: midnight of the local date and the day before
        Calendar cal = new GregorianCalendar();
        cal.setTimeZone(TimeZone.getDefault());
        cal.setTimeInMillis(depTimeMs);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        long todayMidnight = cal.getTimeInMillis();
        long[] dayCands = {todayMidnight, todayMidnight - 86400_000L};
        long[] expSec = new long[dayCands.length];
        for (int i = 0; i < dayCands.length; i++) {
            expSec[i] = Math.round((depTimeMs - dayCands[i]) / 1000.0);
        }

        // 1. trips of the route (by route_id, or via routes.txt short name)
        Set<String> routeTrips = new HashSet<>();
        Map<String, String> routeShortNames = new HashMap<>();
        BufferedReader r = reader(zip, "routes.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "route_id", "route_short_name", "route_long_name");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String rid = fieldAt(line, ix[0]);
                        String sn = fieldAt(line, ix[1]);
                        if (sn == null) sn = "";
                        routeShortNames.put(rid, sn);
                    }
                }
            } finally {
                r.close();
            }
        }
        String normRouteName = Ui.norm(routeName);
        r = reader(zip, "trips.txt");
        if (r != null) {
            try {
                String header = r.readLine();
                if (header != null) {
                    int[] ix = colIdx(header, "trip_id", "route_id");
                    String line;
                    while ((line = r.readLine()) != null) {
                        String rid = fieldAt(line, ix[1]);
                        if (rid.isEmpty()) continue;
                        boolean ridEq = routeId != null && !routeId.isEmpty() && rid.equals(routeId);
                        String sn = routeShortNames.get(rid);
                        boolean nameEq = !normRouteName.isEmpty() && sn != null
                                && Ui.norm(sn).equals(normRouteName);
                        if (ridEq || nameEq) routeTrips.add(fieldAt(line, ix[0]));
                    }
                }
            } finally {
                r.close();
            }
        }
        if (routeTrips.isEmpty()) return null;

        // 2. scan stop_times at our stop; match the departure second
        String bestTrip = null;
        long bestDay = 0;
        long bestDiff = Long.MAX_VALUE;
        r = reader(zip, "stop_times.txt");
        if (r == null) return null;
        try {
            String header = r.readLine();
            if (header == null) return null;
            int[] ix = colIdx(header, "trip_id", "departure_time", "stop_id");
            String line;
            while ((line = r.readLine()) != null) {
                String sid = fieldAt(line, ix[2]);
                if (!sid.equals(stopId) && !apiStopId(sid).equals(wantApi)) continue;
                String tid = fieldAt(line, ix[0]);
                if (!routeTrips.contains(tid)) continue;
                int depSec = hms(fieldAt(line, ix[1]));
                for (int i = 0; i < dayCands.length; i++) {
                    long diff = Math.abs(depSec - expSec[i]);
                    if (diff <= 120 && diff < bestDiff) {
                        bestDiff = diff;
                        bestTrip = tid;
                        bestDay = dayCands[i];
                    }
                }
            }
        } finally {
            r.close();
        }
        return bestTrip == null ? null : new Object[]{bestTrip, bestDay};
    }
}
