package online.wtrasie.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

/**
 * Live vehicle preview: the whole trip (already-served stops included) drawn as
 * a timeline — scheduled times struck through with estimates below, the vehicle
 * marker moving between stops by traveled percentage, per-stop delay text and
 * a countdown on the right. Details live behind the "i" button.
 *
 * v1.4.0 adds the planned-trip mode: a departure whose vehicle has not left yet
 * opens the scheduled trip straight from GTFS (no live vehicle). No countdown
 * and no "Planowo" are shown until the run actually starts, the marker waits
 * at the first stop and never collapses into a dot.
 */
public class VehicleSheet extends Sheet {

    private final MainActivity act;
    private final TextView route, headsign, delay, status;
    private final android.widget.ProgressBar progress;
    private final View statusWrap;
    private final ImageButton btnLink, btnInfo, btnClose;
    private final ScrollView routeScroll;
    private final RouteTimelineView timeline;

    private Models.Vehicle vehicle;
    private Cities.City city;
    private Gtfs.Trip trip;
    private long serviceDayMs; // midnight of the GTFS service day
    private String currentId;
    private boolean tripRequested = false;
    private int tripRetries = 0; // alpha-1.6.2: up to 3 silent retries
    private boolean tripJustLoaded = false; // auto-scroll once, when the trip loads
    private boolean userScrolled = false;   // after that, never fight the user
    private boolean planned = false;        // scheduled trip, vehicle not running yet
    private Models.Stop plannedStop;        // stop the planned departure was tapped on
    private String plannedRouteId = "";     // route_id of the planned departure
    private long plannedDepMs;              // scheduled departure time of the tapped row
    private int loadGen = 0;
    /** alpha-1.6.3: last positions poll did NOT see this run live. */
    private boolean liveMissing = false;
    private final View noLocationWrap; // "Brak danych o lokalizacji pojazdu"
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable rebuildTick = new Runnable() {
        @Override
        public void run() {
            if (getState() == HIDDEN) return;
            if (planned) {
                // alpha-1.6.3: in planned mode the notice follows the clock —
                // once the departure time passes with no live data it appears
                updateNoLocationNotice();
            } else {
                rebuildRows();
            }
            ui.postDelayed(this, 8000);
        }
    };

    public VehicleSheet(MainActivity act) {
        super(act, R.layout.sheet_vehicle);
        this.act = act;

        route = findViewById(R.id.vehicleRoute);
        headsign = findViewById(R.id.vehicleHeadsign);
        delay = findViewById(R.id.vehicleDelay);
        status = findViewById(R.id.routeStatus);
        progress = findViewById(R.id.routeProgress);
        statusWrap = findViewById(R.id.routeStatusWrap);
        noLocationWrap = findViewById(R.id.noLocationWrap);
        btnLink = findViewById(R.id.btnVehicleLink);
        btnInfo = findViewById(R.id.btnVehicleInfo);
        btnClose = findViewById(R.id.btnCloseVehicle);
        routeScroll = findViewById(R.id.routeScroll);
        timeline = findViewById(R.id.routeTimeline);
        timeline.setListener(row -> act.openStopFromRoute(row.stopId, row.name, row.lat, row.lon));
        // v1.3.0: the list never scrolls itself back — only a manual scroll or
        // the single initial positioning after the trip loads
        routeScroll.setOnTouchListener((v, ev) -> {
            userScrolled = true;
            return false;
        });

        setDragHandle(findViewById(R.id.vehicleHeader));
        // the timeline must reach the visible bottom in every sheet state
        setScrollableContent(routeScroll);
        // alpha-1.6.3: A- / A / A+ / A++ applies to the static texts of this
        // sheet too (status, notice) — not only the rows filled dynamically
        Ui.scaleTextTree(this);

        btnClose.setOnClickListener(v -> hide());
        btnInfo.setOnClickListener(v -> showDetails());
        btnLink.setOnClickListener(v -> {
            try {
                if (vehicle != null && vehicle.url != null && !vehicle.url.isEmpty()) {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(vehicle.url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                }
            } catch (Throwable ignored) {
            }
        });
    }

    public String getCurrentVehicleId() {
        return currentId;
    }

    public Models.Vehicle getVehicle() {
        return vehicle;
    }

    public Cities.City getCity() {
        return city;
    }

    /** True when this sheet currently shows a trip that has not started yet. */
    public boolean isPlanned() {
        return planned;
    }

    // alpha-1.6.4: session restore needs the full planned-run context
    public Models.Stop getPlannedStop() {
        return plannedStop;
    }

    public String getPlannedRouteId() {
        return plannedRouteId;
    }

    public long getPlannedDepMs() {
        return plannedDepMs;
    }

    /**
     * alpha-1.6.4: reopen a saved planned run after the process was killed in
     * the background — same state as the original openScheduled tap, but built
     * from the persisted snapshot instead of a fresh Departure.
     */
    public void reopenPlanned(Cities.City city, Models.Vehicle snapshot,
                              Models.Stop stop, String routeId, long depMs) {
        openInternal(city, snapshot, true, stop,
                routeId == null ? "" : routeId, depMs);
    }

    public void open(Cities.City city, Models.Vehicle v) {
        openInternal(city, v, false, null, null, 0);
    }

    /**
     * Open a scheduled departure (the vehicle has not left yet): the trip is
     * resolved from GTFS by stop + time, no live marker, no countdowns.
     */
    public void openScheduled(Cities.City city, Models.Departure d, Models.Stop stop) {
        Models.Vehicle v = new Models.Vehicle();
        v.id = "plan:" + (stop == null ? "" : stop.id) + ":" + d.scheduledDeparture;
        v.type = String.valueOf(d.route.type);
        v.routeName = d.route.name;
        v.routeColor = d.route.color;
        v.brigade = d.brigade == null ? "" : d.brigade;
        v.headsign = d.headsign == null ? "" : d.headsign;
        v.agency = d.route.agency;
        v.delay = null;
        v.lat = 0;
        v.lon = 0;
        Models.Upcoming up = new Models.Upcoming();
        up.name = stop != null ? stop.name : "";
        up.scheduledDeparture = d.scheduledDeparture;
        v.upcoming = new Models.Upcoming[]{up};
        openInternal(city, v, true, stop, d.route.id, d.scheduledDeparture);
    }

    private void openInternal(Cities.City city, Models.Vehicle v, boolean planned,
                              Models.Stop stop, String routeId, long depMs) {
        this.city = city;
        this.vehicle = v;
        this.currentId = v.id;
        this.planned = planned;
        this.plannedStop = stop;
        this.plannedRouteId = routeId == null ? "" : routeId;
        this.plannedDepMs = depMs;
        this.trip = null;
        this.tripRequested = false;
        this.tripRetries = 0;
        this.tripJustLoaded = false;
        this.userScrolled = false;
        this.liveMissing = false; // alpha-1.6.3: fresh open — notice hidden
        updateNoLocationNotice();
        fill(v);
        show();
        setStatus(R.string.loading_route);
        requestTrip();
        ui.removeCallbacks(rebuildTick);
        ui.postDelayed(rebuildTick, 8000);
    }

    @Override
    public void hide() {
        super.hide();
        ui.removeCallbacks(rebuildTick);
        try {
            act.onVehiclePreviewClosed();
        } catch (Throwable ignored) {
        }
    }

    /** Called from the positions poll with fresh data. */
    public void update(Models.Vehicle v) {
        if (planned || v == null || !v.id.equals(currentId)) return;
        this.vehicle = v;
        liveMissing = false; // alpha-1.6.3: live data is back — notice gone
        updateNoLocationNotice();
        if (getState() != HIDDEN) {
            fill(v);
            rebuildRows();
        }
    }

    /**
     * alpha-1.6.3: called from the positions poll when THIS run is not in the
     * live feed — while its schedule says it should be on the road, the sheet
     * shows "Brak danych o lokalizacji pojazdu".
     */
    public void onLiveMissing() {
        if (getState() == HIDDEN) return;
        liveMissing = true;
        updateNoLocationNotice();
    }

    /**
     * alpha-1.6.3: a PLANNED run whose vehicle just showed up in the live feed —
     * the sheet switches to the live run (marker, delay, countdowns).
     * Returns the live vehicle, or null when the run is still not on the road.
     */
    public Models.Vehicle tryGoLive(List<Models.Vehicle> live) {
        if (getState() == HIDDEN || !planned || vehicle == null) return null;
        long now = System.currentTimeMillis();
        long dep = plannedDepartureMs();
        if (dep == 0 && trip != null && !trip.stops.isEmpty()) {
            dep = serviceDayMs + trip.stops.get(0).depSec * 1000L;
        }
        // a couple of minutes before the planned start the vehicle may already
        // be tracked — earlier than that nothing live can be this run
        if (dep > 0 && now < dep - 120_000L) return null;
        String route = vehicle.routeName == null ? "" : vehicle.routeName.trim();
        String brigade = vehicle.brigade == null ? "" : vehicle.brigade.trim();
        Models.Vehicle found = null;
        int sameLine = 0;
        if (live != null && !route.isEmpty()) {
            for (Models.Vehicle v : live) {
                if (v == null || v.routeName == null) continue;
                if (!v.routeName.trim().equalsIgnoreCase(route)) continue;
                sameLine++;
                String vb = v.brigade == null ? "" : v.brigade.trim();
                if (!brigade.isEmpty() && brigade.equalsIgnoreCase(vb)) {
                    found = v;
                    break;
                }
            }
            // no brigade on the planned run: the only vehicle of the line is it
            if (found == null && brigade.isEmpty() && sameLine == 1) {
                for (Models.Vehicle v : live) {
                    if (v != null && v.routeName != null
                            && v.routeName.trim().equalsIgnoreCase(route)) {
                        found = v;
                        break;
                    }
                }
            }
        }
        if (found == null) return null;
        planned = false;
        vehicle = found;
        currentId = found.id;
        liveMissing = false;
        updateNoLocationNotice();
        fill(found);
        if (trip != null && !trip.stops.isEmpty()) rebuildRows();
        ui.removeCallbacks(rebuildTick);
        ui.postDelayed(rebuildTick, 8000);
        return found;
    }

    /** alpha-1.6.3: "Brak danych o lokalizacji pojazdu" — only while the plan
     *  says the run is (or should already be) underway. */
    private void updateNoLocationNotice() {
        boolean show = liveMissing && shouldShowNoLocation() && getState() != HIDDEN;
        Ui.setVisible(noLocationWrap, show);
    }

    private boolean shouldShowNoLocation() {
        long now = System.currentTimeMillis();
        long start = 0;
        if (trip != null && !trip.stops.isEmpty()) {
            start = serviceDayMs + trip.stops.get(0).depSec * 1000L;
        }
        if (start == 0) start = plannedDepartureMs();
        // no schedule at all: trust the missing-live report itself
        return start == 0 || now >= start - 60_000L;
    }

    // ---------------------------------------------------------------- data

    private void requestTrip() {
        if (tripRequested || vehicle == null || city == null) return;
        tripRequested = true;
        if (planned) {
            requestPlannedTrip();
            return;
        }
        final int gen = ++loadGen;
        final String agency = vehicle.agency == null || vehicle.agency.isEmpty() ? "default" : vehicle.agency;
        GtfsRt.vehicleTrips(city.slug, agency, (map, err) -> {
            if (gen != loadGen || getState() == HIDDEN) return;
            GtfsRt.Vp vp = GtfsRt.find(map, vehicle.rtKey());
            if (vp != null && vp.tripId != null && !vp.tripId.isEmpty()) {
                final long base = Gtfs.serviceDayEpoch(vp.startDate);
                Gtfs.loadTrip(act, city.slug, agency, vp.tripId, (t, e) -> {
                    if (gen != loadGen || getState() == HIDDEN) return;
                    if (t != null && !t.stops.isEmpty()) {
                        trip = t;
                        serviceDayMs = base > 0 ? base : guessServiceDay(t);
                        setStatus(-1);
                        timeline.setRoute(act.vehicleColor(vehicle), vehicle.typeInt());
                        tripJustLoaded = true;
                        rebuildRows();
                        act.onVehicleTripLoaded(t);
                    } else if (e != null && "network".equals(e)) {
                        retryTripOnce();
                    } else {
                        fallbackRows();
                    }
                });
            } else if (err != null) {
                retryTripOnce();
            } else {
                // alpha-1.6.0: no realtime trip match (ferries and other feeds
                // whose vehicle ids never match the RT mapping) — find the trip
                // from the static GTFS by route + headsign + current time
                requestTripByRouteHeadsign(gen);
            }
        });
    }

    /** Fallback: resolve the running trip from static GTFS (route + headsign + now). */
    private void requestTripByRouteHeadsign(final int gen) {
        if (vehicle == null || city == null) {
            fallbackRows();
            return;
        }
        final String agency = vehicle.agency == null || vehicle.agency.isEmpty() ? "default" : vehicle.agency;
        final Models.Vehicle veh = vehicle;
        Gtfs.findRunningTrip(act, city.slug, agency, "", veh.routeName, veh.headsign,
                new Gtfs.FoundTripCb() {
                    @Override
                    public void on(String tripId, long dayMs, String error) {
                        if (gen != loadGen || getState() == HIDDEN) return;
                        if (tripId != null && !tripId.isEmpty()) {
                            Gtfs.loadTrip(act, city.slug, agency, tripId, (t, e) -> {
                                if (gen != loadGen || getState() == HIDDEN) return;
                                if (t != null && !t.stops.isEmpty()) {
                                    trip = t;
                                    serviceDayMs = dayMs > 0 ? dayMs : guessServiceDay(t);
                                    setStatus(-1);
                                    timeline.setRoute(act.vehicleColor(veh), veh.typeInt());
                                    tripJustLoaded = true;
                                    rebuildRows();
                                    act.onVehicleTripLoaded(t);
                                } else {
                                    fallbackRows();
                                }
                            });
                        } else {
                            fallbackRows();
                        }
                    }
                });
    }

    /** Planned mode: find the GTFS trip by route + stop + departure time. */
    private void requestPlannedTrip() {
        final int gen = ++loadGen;
        final Models.Stop stop = plannedStop;
        final Models.Vehicle veh = vehicle;
        if (stop == null || veh == null) {
            fallbackRows();
            return;
        }
        final String agency = veh.agency == null || veh.agency.isEmpty() ? "default" : veh.agency;
        final long depMs = plannedDepMs > 0 ? plannedDepMs : plannedDepartureMs();
        Gtfs.findScheduledTrip(act, city.slug, agency, plannedRouteId, veh.routeName,
                stop.id, depMs, new Gtfs.FoundTripCb() {
                    @Override
                    public void on(String tripId, long dayMs, String error) {
                        if (gen != loadGen || getState() == HIDDEN) return;
                        if (tripId != null && !tripId.isEmpty()) {
                            Gtfs.loadTrip(act, city.slug, agency, tripId, (t, e) -> {
                                if (gen != loadGen || getState() == HIDDEN) return;
                                if (t != null && !t.stops.isEmpty()) {
                                    trip = t;
                                    serviceDayMs = dayMs;
                                    setStatus(-1);
                                    timeline.setRoute(act.vehicleColor(veh), veh.typeInt());
                                    tripJustLoaded = true;
                                    rebuildRows();
                                    act.onVehicleTripLoaded(t);
                                } else {
                                    fallbackRows();
                                }
                            });
                        } else if (error != null && "network".equals(error)) {
                            retryTripOnce();
                        } else {
                            fallbackRows();
                        }
                    }
                });
    }

    /**
     * Silent retries after a network hiccup. alpha-1.6.2: up to 3 attempts
     * (2.5 s, 5 s, 10 s backoff) — the "route never loads until a manual
     * refresh" report. The zip layer retries on its own too, so together the
     * load survives a mobile network that drops for a moment.
     */
    private void retryTripOnce() {
        if (getState() == HIDDEN || tripRetries >= 3) {
            if (getState() != HIDDEN) fallbackRows();
            return;
        }
        long backoff = tripRetries == 0 ? 2500L : tripRetries == 1 ? 5000L : 10000L;
        tripRetries++;
        setStatus(R.string.loading_route);
        ui.postDelayed(() -> {
            if (getState() == HIDDEN) return;
            tripRequested = false;
            requestTrip();
        }, backoff);
    }

    /** When the RT feed has no trip, estimate the service day from the timetable itself. */
    private long guessServiceDay(Gtfs.Trip t) {
        long now = System.currentTimeMillis();
        Calendar c = new GregorianCalendar();
        c.setTimeZone(TimeZone.getDefault());
        for (int add = 0; add >= -1; add--) {
            Calendar d = (GregorianCalendar) c.clone();
            d.add(Calendar.DAY_OF_YEAR, add);
            d.set(Calendar.HOUR_OF_DAY, 0);
            d.set(Calendar.MINUTE, 0);
            d.set(Calendar.SECOND, 0);
            d.set(Calendar.MILLISECOND, 0);
            long base = d.getTimeInMillis();
            if (!t.stops.isEmpty()) {
                long first = base + t.stops.get(0).depSec * 1000L;
                long last = base + t.stops.get(t.stops.size() - 1).arrSec * 1000L;
                if (now >= first - 3600_000L && now <= last + 3600_000L) return base;
            }
        }
        Calendar d = (GregorianCalendar) c.clone();
        d.set(Calendar.HOUR_OF_DAY, 0);
        d.set(Calendar.MINUTE, 0);
        d.set(Calendar.SECOND, 0);
        d.set(Calendar.MILLISECOND, 0);
        return d.getTimeInMillis();
    }

    private void fallbackRows() {
        if (vehicle == null) return;
        if (vehicle.upcoming == null || vehicle.upcoming.length == 0) {
            setStatus(R.string.no_trip_data);
            return;
        }
        List<RouteTimelineView.Row> rows = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Models.Upcoming u : vehicle.upcoming) {
            RouteTimelineView.Row r = new RouteTimelineView.Row();
            r.name = u.name;
            long eta = u.scheduledArrival > 0 ? u.scheduledArrival : u.scheduledDeparture;
            r.schedMs = eta;
            r.estMs = vehicle.delay == null ? 0 : eta + vehicle.delay;
            r.passed = !planned && r.estMs > 0 && r.estMs < now;
            fillDelay(r);
            fillCount(r);
            rows.add(r);
        }
        setStatus(-1);
        timeline.setRoute(act.vehicleColor(vehicle), vehicle.typeInt());
        timeline.setRows(rows, rows.size(), 1f, false);
    }

    // ---------------------------------------------------------------- rendering

    private void fill(Models.Vehicle v) {
        Ui.setPill(route, vehicleLabel(v), act.vehicleColor(v));
        Ui.scaleText(route); // alpha-1.6.2: A- / A / A+ / A++ text size
        Ui.scaleText(headsign);
        Ui.scaleText(delay);
        headsign.setText(v.headsign == null || v.headsign.isEmpty() ? "?" : v.headsign);

        if (planned) {
            // scheduled run: show the departure time, no delay, no realtime icon
            long dep = plannedDepartureMs();
            delay.setText(dep > 0
                    ? act.getString(R.string.planned_at, Ui.fmtTime(dep))
                    : act.getString(R.string.planned));
            delay.setTextColor(0xFF5F5F66);
            Ui.setVisible(findViewById(R.id.realtimeIcon), false);
            Ui.setVisible(btnLink, false);
            return;
        }
        Ui.setVisible(btnLink, true);
        // delay: "Planowo" when on time, "—" only when there is no data at all
        if (v.delay == null) {
            delay.setText("—");
            delay.setTextColor(0xFF9AA0A6);
        } else {
            String dt = Ui.fmtDelay(v.delay);
            if (dt.isEmpty()) {
                delay.setText(R.string.planowo);
                delay.setTextColor(0xFF146C2E);
            } else {
                delay.setText(dt);
                delay.setTextColor(Ui.delayColor(v.delay));
            }
        }
        Ui.setVisible(findViewById(R.id.realtimeIcon), true);
    }

    /** Departure time of the planned run (the tapped row), in epoch ms. */
    private long plannedDepartureMs() {
        if (vehicle == null) return 0;
        if (vehicle.upcoming != null && vehicle.upcoming.length > 0) {
            return vehicle.upcoming[0].scheduledDeparture > 0
                    ? vehicle.upcoming[0].scheduledDeparture : vehicle.upcoming[0].scheduledArrival;
        }
        return 0;
    }

    private void setStatus(int stringRes) {
        if (stringRes < 0) {
            statusWrap.setVisibility(GONE);
            routeScroll.setVisibility(VISIBLE);
        } else {
            status.setText(stringRes);
            statusWrap.setVisibility(VISIBLE);
            routeScroll.setVisibility(GONE);
        }
    }

    /**
     * Chip text of a vehicle. PKP trains: carrier + brigade number ("IC 5423").
     */
    static String vehicleLabel(Models.Vehicle v) {
        String name = v.routeName == null ? "" : v.routeName.trim();
        if (name.isEmpty()) name = "?";
        if (v.pkp) {
            String b = v.brigade == null ? "" : v.brigade.trim();
            if (!b.isEmpty() && !name.endsWith(b)) return name + " " + b;
        }
        return name;
    }

    /** Index of the next stop the vehicle heads to (trip-based). */
    private int nextStopIndex() {
        if (trip == null || trip.stops.isEmpty() || vehicle == null) return 0;
        // prefer the feed's own sequence
        if (vehicle.upcoming != null && vehicle.upcoming.length > 0) {
            int seq = vehicle.upcoming[0].sequence;
            if (seq >= 0) {
                for (int i = 0; i < trip.stops.size(); i++) {
                    if (trip.stops.get(i).seq == seq) return i;
                }
            }
            for (int i = 0; i < trip.stops.size(); i++) {
                if (trip.stops.get(i).name.equals(vehicle.upcoming[0].name)) {
                    return i;
                }
            }
        }
        // nearest stop ahead by geometry: the next stop is the closest one the vehicle approaches
        double bestD = Double.MAX_VALUE;
        int best = 0;
        for (int i = 0; i < trip.stops.size(); i++) {
            Gtfs.StopTime st = trip.stops.get(i);
            if (st.lat == 0 && st.lon == 0) continue;
            double d = Ui.distM(vehicle.lat, vehicle.lon, st.lat, st.lon);
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        // if we are past midway between best and the previous, the next stop is best+1
        if (best > 0) {
            Gtfs.StopTime prev = trip.stops.get(best - 1);
            double dPrev = Ui.distM(vehicle.lat, vehicle.lon, prev.lat, prev.lon);
            if (dPrev < bestD) return best + 1 < trip.stops.size() ? best + 1 : best;
        }
        return best;
    }

    /** % traveled between stop idx-1 and idx. */
    private float segmentProgress(int nextIdx) {
        if (trip == null || nextIdx <= 0 || nextIdx >= trip.stops.size() || vehicle == null) return 0;
        Gtfs.StopTime a = trip.stops.get(nextIdx - 1);
        Gtfs.StopTime b = trip.stops.get(nextIdx);
        double ab = Ui.distM(a.lat, a.lon, b.lat, b.lon);
        if (ab < 1) return 1;
        double av = Ui.distM(a.lat, a.lon, vehicle.lat, vehicle.lon);
        return (float) Math.max(0, Math.min(1, av / ab));
    }

    private void rebuildRows() {
        if (trip == null || trip.stops.isEmpty() || vehicle == null) return;
        long now = System.currentTimeMillis();
        long d = vehicle.delay == null ? 0 : vehicle.delay;
        int next = nextStopIndex();
        float prog = segmentProgress(next);
        boolean hasMarker = !planned && (vehicle.lat != 0 || vehicle.lon != 0);

        List<RouteTimelineView.Row> rows = new ArrayList<>(trip.stops.size());
        for (int i = 0; i < trip.stops.size(); i++) {
            Gtfs.StopTime st = trip.stops.get(i);
            RouteTimelineView.Row r = new RouteTimelineView.Row();
            r.stopId = st.stopId;
            r.name = st.name;
            r.lat = st.lat;
            r.lon = st.lon;
            r.schedMs = serviceDayMs + (st.arrSec > 0 ? st.arrSec : st.depSec) * 1000L;
            r.estMs = vehicle.delay == null ? 0 : r.schedMs + d;
            r.passed = !planned && (i < next || (r.estMs > 0 && r.estMs < now));
            fillDelay(r);
            fillCount(r);
            rows.add(r);
        }
        timeline.setRows(rows, next, prog, hasMarker || planned);
        scrollToMarker();
    }

    private void fillDelay(RouteTimelineView.Row r) {
        if (planned || vehicle == null || vehicle.delay == null) {
            r.delayText = "";
            return;
        }
        String dt = Ui.fmtDelay(vehicle.delay);
        if (dt.isEmpty()) {
            r.delayText = act.getString(R.string.planowo);
            r.delayColor = 0xFF146C2E;
        } else {
            r.delayText = dt;
            r.delayColor = Ui.delayColor(vehicle.delay);
        }
    }

    private void fillCount(RouteTimelineView.Row r) {
        if (planned) {
            // the run has not started: neither minutes nor "Planowo"
            r.countText = "";
            r.blink = false;
            return;
        }
        if (r.passed) {
            r.countText = "";
            r.blink = false;
            return;
        }
        long now = System.currentTimeMillis();
        long est = r.estMs > 0 ? r.estMs : r.schedMs;
        String ct = Ui.fmtCountdown(est, now);
        if (ct == null) {
            r.countText = "";
        } else {
            r.countText = ct;
            r.blink = Ui.isBlinkCountdown(ct);
        }
    }

    private void scrollToMarker() {
        // v1.3.0: only the initial positioning; a list the user has scrolled
        // stays exactly where the user left it
        if (userScrolled || !tripJustLoaded) return;
        tripJustLoaded = false;
        if (planned) {
            routeScroll.post(() -> {
                try {
                    routeScroll.smoothScrollTo(0, 0);
                } catch (Throwable ignored) {
                }
            });
            return;
        }
        final float y = timeline.markerY() - routeScroll.getHeight() / 2f + timeline.getTop();
        routeScroll.post(() -> {
            try {
                routeScroll.smoothScrollTo(0, Math.max(0, (int) y));
            } catch (Throwable ignored) {
            }
        });
    }

    // ---------------------------------------------------------------- details popup

    private void showDetails() {
        if (vehicle == null) return;
        StringBuilder sb = new StringBuilder();
        if (planned) sb.append(act.getString(R.string.planned_run_note)).append("\n");
        if (vehicle.model != null && !vehicle.model.isEmpty()) sb.append(vehicle.model).append("\n");
        if (!vehicle.id.isEmpty() && !vehicle.id.startsWith("_") && !vehicle.id.startsWith("plan:"))
            sb.append("#").append(vehicle.id).append("\n");
        if (vehicle.brigade != null && !vehicle.brigade.isEmpty()) sb.append("Brygada: ").append(vehicle.brigade).append("\n");
        if (vehicle.agency != null && !vehicle.agency.isEmpty()) sb.append("Przewoźnik: ").append(vehicle.agency);
        if (sb.length() == 0) sb.append("—");
        new AlertDialog.Builder(act)
                .setTitle(act.getString(R.string.app_name))
                .setMessage(sb.toString().trim())
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}
