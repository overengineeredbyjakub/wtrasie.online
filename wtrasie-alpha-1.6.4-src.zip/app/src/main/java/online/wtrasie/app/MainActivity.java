package online.wtrasie.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.maplibre.android.geometry.LatLng;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity implements MapLayers.Listener {

    private static final String TAG = "Main";

    private static final int[] FILTER_ORDER = {3, 0, 1, 2, 11, 4, 99}; // bus, tram, metro, rail, trolley, ferry, other

    MapLayers map;
    Prefs prefs;
    Favorites favorites;
    Cities.City currentCity;
    CitySheet citySheet;
    SearchSheet searchSheet;
    StopSheet stopSheet;
    VehicleSheet vehicleSheet;
    LinesSheet linesSheet;
    int curTab = 0; // alpha-1.6.0: tracked for the back button/gesture

    // v1.5.0: camera wanted at startup — applied when the map style is READY
    // (moveCamera in onCreate was a no-op: the map is not loaded yet, which
    // is why the world map at 0,0 sometimes appeared on cold start)
    private boolean startupPending = true;
    private double startupLat = 52.2297, startupLon = 21.0122, startupZoom = 11.5;

    private TextView cityName;
    private TextView attribution;
    private View topBar;
    private ViewGroup sheetContainer;
    private LinearLayout filterRow;
    private final Set<Integer> availableTypes = new LinkedHashSet<>();

    // tabs
    private View mapTab, routeTabView, settingsTab;
    private View tabMapBtn, tabRouteBtn, tabSettingsBtn;
    private ImageView tabMapIcon, tabRouteIcon, tabSettingsIcon;
    private TextView tabMapLabel, tabRouteLabel, tabSettingsLabel;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable viewportSettled = this::viewportWork;
    private final Runnable positionsTick = new Runnable() {
        @Override
        public void run() {
            try {
                doFetchPositions(false);
            } catch (Throwable ignored) {
            }
            if (resumed) {
                handler.postDelayed(this, Math.max(3, prefs.refreshInterval()) * 1000L);
            }
        }
    };
    // v1.4.1: the first fetch after (re)start is counted — the hourglass shows
    // while the map is still filling up
    private final Runnable positionsTickInitial = new Runnable() {
        @Override
        public void run() {
            try {
                doFetchPositions(false, true);
            } catch (Throwable ignored) {
            }
            if (resumed) {
                handler.postDelayed(positionsTick, Math.max(3, prefs.refreshInterval()) * 1000L);
            }
        }
    };
    private Location lastLocation;
    private int tileStyle = -1;
    private long lastPositionsFetch;
    private long lastPkpFetch;
    private int switchGen = 0;
    private boolean resumed = false;
    private boolean mapReady = false;

    // v1.4.1: small flipping hourglass while the current city's data is loading
    private View loadingIndicator;
    private int pendingLoads = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // these must exist before any lifecycle callback can run
        prefs = new Prefs(this);
        favorites = new Favorites(this);
        // alpha-1.6.2: the A- / A / A+ / A++ text size factor (persisted
        // with commit() — see Prefs — so it survives the process death)
        Ui.textFactor = TEXT_FACTORS[Math.max(0, Math.min(3, prefs.textScale()))];
        // alpha-1.6.0: the user's saved visibility choice is respected — the
        // forced ON reset at every start is gone (defaults are ON for a fresh
        // install anyway)
        try {
            // MapLibre native init must happen before the MapView is inflated
            try {
                org.maplibre.android.MapLibre.getInstance(this);
            } catch (Throwable ignored) {
            }
            setContentView(R.layout.activity_main);
        } catch (Throwable t) {
            android.util.Log.e(TAG, "setContentView failed", t);
            try {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {
            }
            finish();
            return;
        }

        sheetContainer = findViewById(R.id.sheetContainer);
        cityName = findViewById(R.id.cityName);
        attribution = findViewById(R.id.attribution);
        topBar = findViewById(R.id.topBar);
        loadingIndicator = findViewById(R.id.loadingIndicator);
        filterRow = findViewById(R.id.filterRow);
        mapTab = findViewById(R.id.mapTab);
        routeTabView = findViewById(R.id.routeTab);
        settingsTab = findViewById(R.id.settingsTab);

        map = new MapLayers(this, prefs, this);
        map.attach((org.maplibre.android.maps.MapView) findViewById(R.id.map));

        initTopBar();
        initFabs();
        initTabs();
        buildSettings();
        rebuildFilterRow();
        initSheets();

        // restore last session; first start defaults to Warsaw — and never the
        // world map at (0,0): a broken saved camera falls back to the city center.
        // alpha-1.6.0 CRASH FIX: the saved/default slug must resolve to a real
        // city — "warszawa" never matched any slug ("warsaw"), currentCity was
        // null and a FRESH INSTALL crashed at startup with an NPE.
        Cities.City last = Cities.bySlug(prefs.lastCity());
        if (last == null) last = Cities.bySlug("warsaw");
        if (last == null) {
            java.util.List<Cities.City> all = Cities.all();
            last = all.isEmpty() ? null : all.get(0);
        }
        currentCity = last;
        if (currentCity != null) cityName.setText(currentCity.name);

        double lat = prefs.lastLat(), lon = prefs.lastLon(), zoom = prefs.lastZoom();
        boolean validCam = validCoords(lat, lon) && zoom >= 5 && zoom <= 19;
        if (!validCam) {
            lat = currentCity.lat;
            lon = currentCity.lon;
            zoom = currentCity.zoom;
        }

        // v1.5.0: with location permission granted the app starts centered on
        // the user, and the city follows the user's position.
        // alpha-1.6.3: only when "Używaj mojej lokalizacji" is ON — the new
        // settings switch is the master gate for everything location-related.
        if (prefs.useMyLocation()
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            Location loc = getLastLocation();
            if (loc != null && validCoords(loc.getLatitude(), loc.getLongitude())) {
                lat = loc.getLatitude();
                lon = loc.getLongitude();
                zoom = zoom >= 14 ? zoom : 15.0;
                // alpha-1.6.3: setLocation is buffered until the style is ready,
                // so the blue dot REALLY appears together with the centering
                map.setLocation(lat, lon);
                Cities.City near = Cities.nearest(lat, lon, 60);
                if (near != null && !near.slug.equals(currentCity.slug)) {
                    currentCity = near;
                    cityName.setText(near.name);
                    prefs.setLastCity(near.slug);
                }
            }
        }
        startupLat = lat;
        startupLon = lon;
        startupZoom = zoom;
        // the actual moveCamera happens in onMapReady — see there

        // alpha-1.6.4: the process may have been killed while the app was in
        // the background (screen off / another app in front) — rebuild what
        // the user saw: the open vehicle preview, the stop panel or the
        // active tab. Runs LAST because it needs currentCity + sheets ready.
        restoreSession();
    }

    private static boolean validCoords(double lat, double lon) {
        return !(lat == 0 && lon == 0) && Math.abs(lat) < 85 && Math.abs(lon) <= 180;
    }

    // ------------------------------------------------------------------ MapLayers.Listener

    @Override
    public void onMapReady() {
        mapReady = true;
        applyTileSource();
        if (startupPending) {
            startupPending = false;
            map.moveCamera(startupLat, startupLon, startupZoom);
        }
        loadCityData(true);
    }

    @Override
    public void onViewportSettled() {
        handler.removeCallbacks(viewportSettled);
        // alpha-1.6.0: the auto city switch happens IMMEDIATELY when the camera
        // settles over a city — no 3 s dwell anymore
        viewportSettled.run();
    }

    @Override
    public void onRouteStopTapped(String stopId, String name, double lat, double lon) {
        openStopFromRoute(stopId, name, lat, lon);
    }

    // ------------------------------------------------------------------ tabs

    private void initTabs() {
        tabMapBtn = findViewById(R.id.tabMap);
        tabRouteBtn = findViewById(R.id.tabRoute);
        tabSettingsBtn = findViewById(R.id.tabSettings);
        tabMapIcon = findViewById(R.id.tabMapIcon);
        tabRouteIcon = findViewById(R.id.tabRouteIcon);
        tabSettingsIcon = findViewById(R.id.tabSettingsIcon);
        tabMapLabel = findViewById(R.id.tabMapLabel);
        tabRouteLabel = findViewById(R.id.tabRouteLabel);
        tabSettingsLabel = findViewById(R.id.tabSettingsLabel);

        tabMapBtn.setOnClickListener(v -> safe(() -> setTab(0)));
        tabRouteBtn.setOnClickListener(v -> safe(() -> setTab(1)));
        tabSettingsBtn.setOnClickListener(v -> safe(() -> setTab(2)));
        findViewById(R.id.helpCard).setOnClickListener(v -> safe(() ->
                startActivity(new Intent(this, HelpActivity.class))));
        setTab(0);
    }

    private void setTab(int idx) {
        curTab = idx;
        mapTab.setVisibility(idx == 0 ? View.VISIBLE : View.INVISIBLE);
        routeTabView.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        settingsTab.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        boolean m = idx == 0, r = idx == 1, s = idx == 2;
        if (idx != 0) {
            // leaving the map: close whatever sheet is open — WITHOUT switching
            // tabs again (no recursion)
            openSheetAlone(null, null);
        }
        if (idx == 0 && resumed && mapReady) {
            // alpha-1.6.0: returning to the map re-pushes the current data onto
            // the map and refreshes right away — no more tapping the refresh
            // button several times after switching tabs
            map.rebuildPublic();
            doFetchPositions(true, true);
            schedulePositions();
        }
        if (idx == 2) {
            // alpha-1.6.0: the settings list is rebuilt from the prefs every
            // time the tab opens — the switches can never show a stale state
            // after the process was killed in the background
            buildSettings();
        }
        tabMapIcon.setColorFilter(m ? 0xFF0B57D0 : 0xFF5F5F66);
        tabRouteIcon.setColorFilter(r ? 0xFF0B57D0 : 0xFF5F5F66);
        tabSettingsIcon.setColorFilter(s ? 0xFF0B57D0 : 0xFF5F5F66);
        tabMapLabel.setTextColor(m ? 0xFF0B57D0 : 0xFF5F5F66);
        tabRouteLabel.setTextColor(r ? 0xFF0B57D0 : 0xFF5F5F66);
        tabSettingsLabel.setTextColor(s ? 0xFF0B57D0 : 0xFF5F5F66);
        tabMapLabel.setTypeface(null, m ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabRouteLabel.setTypeface(null, r ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabSettingsLabel.setTypeface(null, s ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
    }

    // ------------------------------------------------------------------ ui

    private void initTopBar() {
        ImageButton btnChevron = findViewById(R.id.btnCityChevron);
        View searchField = findViewById(R.id.searchField);

        // alpha-1.6.3: the A- / A / A+ / A++ text size applies to the top bar
        // too (city name + the search placeholder), not only to list rows
        applyTextFactor();

        // FIX v1.3.0: the city sheet was never shown after openSheetAlone()
        View.OnClickListener cityClick = v -> safe(() -> {
            openSheetAlone(citySheet, citySheet);
            citySheet.show();
        });
        btnChevron.setOnClickListener(cityClick);
        cityName.setOnClickListener(cityClick);

        searchField.setOnClickListener(v -> safe(() -> {
            openSheetAlone(searchSheet, searchSheet);
            searchSheet.openWithKeyboard();
        }));
    }

    /**
     * alpha-1.6.3: re-applies the global text factor to the always-visible
     * texts (top bar, search input) after the "Rozmiar tekstu" setting
     * changes — the lists rescale themselves on their next rebuild.
     */
    private void applyTextFactor() {
        try {
            Ui.scaleText(cityName);
            Ui.scaleText(findViewById(R.id.searchField));
            Ui.scaleTextTree(settingsTab); // "Ustawienia" title, help card, headers
            if (searchSheet != null) searchSheet.rescaleText();
        } catch (Throwable ignored) {
        }
    }

    private void initFabs() {
        findViewById(R.id.fabLocate).setOnClickListener(v -> safe(this::onLocateClicked));
        findViewById(R.id.fabFavorites).setOnClickListener(v -> safe(() -> {
            openSheetAlone(searchSheet, searchSheet);
            searchSheet.show();
        }));
        // v1.5.0: lines of the current city (above the type-filter row)
        findViewById(R.id.fabLines).setOnClickListener(v -> safe(() -> {
            openSheetAlone(linesSheet, linesSheet);
            linesSheet.show();
        }));
        initRefreshButton();
    }

    /**
     * Small manual refresh button (map positions) with a 5 s cooldown: after a
     * refresh it goes gray with a live countdown, then re-enables.
     */
    private void initRefreshButton() {
        btnRefresh = findViewById(R.id.fabRefresh);
        refreshCount = findViewById(R.id.fabRefreshCount);
        refreshIcon = findViewById(R.id.fabRefreshIcon);
        if (btnRefresh == null) return;
        btnRefresh.setOnClickListener(v -> safe(() -> {
            if (refreshCooldown > 0) return;
            doFetchPositions(true, true); // v1.4.1: immediate re-fetch, hourglass follows
            refreshCooldown = 5;
            setRefreshEnabled(false);
            if (refreshCount != null) refreshCount.setText(String.valueOf(refreshCooldown));
            handler.removeCallbacks(refreshCooldownTick);
            handler.postDelayed(refreshCooldownTick, 1000);
        }));
        setRefreshEnabled(true);
    }

    private void setRefreshEnabled(boolean enabled) {
        if (btnRefresh == null) return;
        btnRefresh.setAlpha(enabled ? 1f : 0.55f);
        if (refreshIcon != null) refreshIcon.setColorFilter(enabled ? 0xFF0B57D0 : 0xFF9AA0A6);
        if (refreshCount != null) refreshCount.setVisibility(enabled ? View.INVISIBLE : View.VISIBLE);
    }

    /** Hide every sheet except `keep` (which will be opened by the caller). */
    private void openSheetAlone(Sheet keep, Sheet toOpen) {
        Sheet[] all = {citySheet, searchSheet, stopSheet, vehicleSheet, linesSheet};
        for (Sheet x : all) {
            if (x != null && x != keep && x.getState() != Sheet.HIDDEN) x.hide();
        }
        if (toOpen != null && toOpen != keep && toOpen.getState() != Sheet.HIDDEN) toOpen.hide();
    }

    private void safe(Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            android.util.Log.e(TAG, "ui action failed", t);
        }
    }

    // ------------------------------------------------------------------ type filters

    private void noteStopTypes(List<Models.Stop> stops) {
        boolean added = false;
        if (stops != null) {
            for (Models.Stop s : stops) {
                for (int t : s.types) {
                    if (availableTypes.add(t)) added = true;
                }
            }
        }
        if (added) rebuildFilterRow();
    }

    private void noteVehicleTypes(List<Models.Vehicle> vehicles) {
        boolean added = false;
        if (vehicles != null) {
            for (Models.Vehicle v : vehicles) {
                if (availableTypes.add(v.typeInt())) added = true;
            }
        }
        if (added) rebuildFilterRow();
    }

    private void rebuildFilterRow() {
        if (filterRow == null) return;
        filterRow.removeAllViews();
        Set<Integer> show = availableTypes.isEmpty()
                ? new LinkedHashSet<>(java.util.Arrays.asList(3, 0, 1, 2, 11, 4, 99))
                : new LinkedHashSet<>();
        if (availableTypes.isEmpty()) {
            // nothing loaded yet: show the standard set
        } else {
            for (int t : FILTER_ORDER) {
                for (int at : availableTypes) {
                    if (gtfsOf(t) == gtfsOf(at)) {
                        show.add(t);
                        break;
                    }
                }
            }
        }
        for (int filterType : show) {
            final int ft = filterType;
            FrameLayout btn = new FrameLayout(this);
            int size = Ui.dp(this, 36);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.rightMargin = Ui.dp(this, 8);
            btn.setLayoutParams(lp);
            btn.setElevation(Ui.dp(this, 4));

            View iv;
            if (ft == 1) {
                TextView tv = new TextView(this);
                tv.setText("M");
                tv.setTextSize(15);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                iv = tv;
            } else {
                ImageView im = new ImageView(this);
                FrameLayout.LayoutParams ivp = new FrameLayout.LayoutParams(
                        Ui.dp(this, 18), Ui.dp(this, 18));
                ivp.gravity = android.view.Gravity.CENTER;
                im.setLayoutParams(ivp);
                im.setImageResource(filterIcon(ft));
                iv = im;
            }
            btn.addView(iv);
            btn.setOnClickListener(v -> safe(() -> {
                boolean on = !prefs.typeFilter(gtfsOf(ft));
                prefs.setTypeFilter(gtfsOf(ft), on);
                styleFilterButton(btn, ft, on);
                if (map != null) {
                    map.rebuildPublic();
                }
            }));
            styleFilterButton(btn, ft, prefs.typeFilter(gtfsOf(ft)));
            filterRow.addView(btn);
        }
    }

    private static int gtfsOf(int filterType) {
        return filterType == 99 ? 6 : filterType; // prefs store real gtfs type; 99 collapses into 6
    }

    private int filterIcon(int filterType) {
        switch (filterType) {
            case 0: return R.drawable.ic_type_tram;
            case 1: return R.drawable.ic_metro_m;
            case 2: return R.drawable.ic_type_train;
            case 4: return R.drawable.ic_type_ferry;
            case 11: return R.drawable.ic_type_trolleybus;
            case 99: return R.drawable.ic_type_gondola;
            default: return R.drawable.ic_type_bus;
        }
    }

    private void styleFilterButton(FrameLayout btn, int filterType, boolean on) {
        int color = Models.typeColor(filterType == 99 ? 6 : filterType);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(on ? color : 0xFFE8EAED);
        btn.setBackground(bg);
        View child = btn.getChildAt(0);
        if (child instanceof ImageView) {
            ((ImageView) child).setColorFilter(on ? 0xFFFFFFFF : 0xFF5F5F66);
        } else if (child instanceof TextView) {
            ((TextView) child).setTextColor(on ? 0xFFFFFFFF : 0xFF5F5F66);
        }
    }

    // ------------------------------------------------------------------ sheets

    private void initSheets() {
        sheetContainer.removeAllViews();
        citySheet = new CitySheet(this, city -> switchCity(city, true));
        searchSheet = new SearchSheet(this, new SearchSheet.Listener() {
            @Override
            public void onLocalStopPicked(Models.Stop stop) {
                openStopFromSearch(stop);
            }

            @Override
            public void onPlacePicked(Api.Place place) {
                openPlace(place);
            }

            @Override
            public void onVehiclePicked(Models.Vehicle vehicle) {
                searchSheet.hide();
                onVehicleTapped(vehicle);
            }
        });
        stopSheet = new StopSheet(this);
        vehicleSheet = new VehicleSheet(this);
        linesSheet = new LinesSheet(this);

        addSheet(citySheet);
        addSheet(searchSheet);
        addSheet(stopSheet);
        addSheet(vehicleSheet);
        addSheet(linesSheet);
    }

    private void addSheet(Sheet s) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = android.view.Gravity.BOTTOM;
        sheetContainer.addView(s, lp);
        s.setVisibility(View.GONE);
    }

    // ------------------------------------------------------------------ loading indicator

    /** v1.4.1: tiny hourglass that flips 180 degrees every couple of seconds
     *  while the current city's data is still being fetched. */
    private void beginLoad() {
        pendingLoads++;
        updateLoadingIndicator();
    }

    private void endLoad() {
        pendingLoads = Math.max(0, pendingLoads - 1);
        updateLoadingIndicator();
    }

    private void updateLoadingIndicator() {
        if (loadingIndicator == null) return;
        final boolean show = pendingLoads > 0;
        runOnUiThread(() -> {
            if (show) {
                if (loadingIndicator.getVisibility() != View.VISIBLE) {
                    loadingIndicator.setVisibility(View.VISIBLE);
                    loadingIndicator.setRotation(0);
                }
                handler.removeCallbacks(loadingFlipTick);
                handler.postDelayed(loadingFlipTick, 250);
            } else {
                handler.removeCallbacks(loadingFlipTick);
                loadingIndicator.setVisibility(View.GONE);
            }
        });
    }

    private final Runnable loadingFlipTick = new Runnable() {
        @Override
        public void run() {
            if (loadingIndicator == null || pendingLoads <= 0) return;
            // not a spinning wheel: the hourglass turns over 180 degrees every ~2 s
            float target = loadingIndicator.getRotation() + 180f;
            loadingIndicator.animate()
                    .rotation(target)
                    .setDuration(350)
                    .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                    .start();
            handler.postDelayed(this, 1900);
        }
    };

    // ------------------------------------------------------------------ city & data

    // alpha-1.6.0: a failed positions fetch is retried quickly (5 s, up to 3
    // times) instead of silently waiting for the next refresh cycle — the
    // hourglass keeps flipping so it is visible that data is loading
    private int posRetries = 0;
    private boolean posRetryPending = false;
    private int stopsRetries = 0;
    private final Runnable positionsRetryTick = new Runnable() {
        @Override
        public void run() {
            posRetryPending = false;
            endLoad();
            if (resumed) doFetchPositions(true, true);
        }
    };

    void loadCityData(boolean fetchPositions) {
        if (currentCity == null) return;
        final int gen = ++switchGen;
        availableTypes.clear();
        dropPendingFetches();
        map.setStops(new java.util.ArrayList<>());
        lastOverlayBbox = ""; // alpha-1.6.1: overlay stops refetch for the new feed
        if (currentCity.nationwide) {
            fetchStopsForViewport(true);
            fetchOverlayStops();
        } else {
            beginLoad(); // stops for the city
            Api.getStopsCached(this, currentCity.slug, (stops, err) -> {
                endLoad();
                if (gen != switchGen) return;
                if (stops != null && !stops.isEmpty()) {
                    stopsRetries = 0;
                    map.setStops(stops);
                    noteStopTypes(stops);
                    scheduleGtfsPrefetch(stops, gen); // alpha-1.6.2: warm the trip cache
                    if (searchSheet != null) searchSheet.onStopsChanged();
                    if (linesSheet != null) linesSheet.onStopsChanged();
                } else if (map.getStops().isEmpty()) {
                    // alpha-1.6.0: retry a failed stops load once after 6 s
                    // (the hourglass keeps showing) instead of an empty map
                    if (stopsRetries < 2) {
                        stopsRetries++;
                        beginLoad();
                        handler.postDelayed(() -> {
                            endLoad();
                            if (gen == switchGen && resumed) loadCityData(false);
                        }, 6000);
                    } else {
                        Toast.makeText(this, R.string.error_network, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
        if (fetchPositions) {
            handler.removeCallbacks(positionsTick);
            handler.removeCallbacks(positionsTickInitial);
            doFetchPositions(true, true); // v1.4.1: immediate, counted for the hourglass
            if (resumed) {
                handler.postDelayed(positionsTick, Math.max(3, prefs.refreshInterval()) * 1000L);
            }
        }
    }

    private void dropPendingFetches() {
        handler.removeCallbacks(positionsRetryTick);
        if (posRetryPending) {
            posRetryPending = false;
            endLoad();
        }
        posRetries = 0;
        stopsRetries = 0;
    }

    /**
     * alpha-1.6.2: BACKGROUND GTFS PREFETCH — the "vehicle route takes over a
     * minute" killer. Two seconds after a city's stops arrive, its GTFS zips
     * start warming the 24 h disk cache on the LOWEST priority queue (one
     * agency at a time, max 3 agencies + default). A tapped vehicle then
     * reads its trip from a warm cache instead of downloading 20+ MB while
     * the user stares at a spinner. Explicit request from the user: when a
     * single vehicle is opened ONLY its route is needed — the full data is
     * for when the whole map with lines and stops is being viewed.
     */
    private void scheduleGtfsPrefetch(java.util.List<Models.Stop> stops, int gen) {
        java.util.LinkedHashSet<String> agencies = new java.util.LinkedHashSet<>();
        if (stops != null) {
            for (Models.Stop st : stops) {
                if (st.routes == null) continue;
                for (Models.Route r : st.routes) {
                    if (r.agency != null && !r.agency.isEmpty() && agencies.add(r.agency)
                            && agencies.size() >= 3) break;
                }
                if (agencies.size() >= 3) break;
            }
        }
        final int g = gen;
        final java.util.List<String> list = new java.util.ArrayList<>(agencies);
        handler.postDelayed(() -> {
            if (g != switchGen || currentCity == null) return;
            Gtfs.prefetch(MainActivity.this, currentCity.slug, list);
        }, 2000);
    }

    void switchCity(Cities.City city, boolean moveCamera) {
        if (city == null || city.slug.equals(currentCity == null ? null : currentCity.slug)) {
            if (moveCamera && city != null) {
                map.centerOn(city.lat, city.lon, city.zoom);
            }
            return;
        }
        currentCity = city;
        cityName.setText(city.name);
        prefs.setLastCity(city.slug);
        map.setStops(new java.util.ArrayList<>());
        map.clearOverlayStops(); // alpha-1.6.1: stale overlay of the old area is gone
        map.clearVehicles(); // v1.4.1: hard clear on city switch — no grace period
        availableTypes.clear();
        prefs.resetTypeFilters(); // v1.4.0: every new city starts with all types on
        rebuildFilterRow();
        if (moveCamera) {
            map.centerOn(city.lat, city.lon, city.zoom);
        }
        loadCityData(true);
    }

    void centerOn(double lat, double lon, double zoom) {
        // never fly to Null Island: stops without coordinates fall back to the city
        if ((lat == 0 && lon == 0) || Math.abs(lat) > 85 || Math.abs(lon) > 180) {
            if (currentCity != null) {
                map.centerOn(currentCity.lat, currentCity.lon, currentCity.zoom);
            }
            return;
        }
        map.centerOn(lat, lon, zoom);
    }

    private void viewportWork() {
        if (!resumed || map == null) return;
        try {
            LatLng center = map.center();
            double zoom = map.camZoom();

            // auto city switch: after 3 s of a still camera, whichever city the
            // viewport actually looks at gets selected (also from nationwide feeds)
            if (prefs.autoCity() && currentCity != null
                    && (vehicleSheet == null || vehicleSheet.getState() == Sheet.HIDDEN)) {
                double maxKm = Math.min(60, Math.max(25, map.spanKm() / 2));
                Cities.City near = Cities.nearest(center.getLatitude(), center.getLongitude(), maxKm);
                if (near != null && !near.slug.equals(currentCity.slug)) {
                    switchCity(near, false);
                    fetchOverlayStops(); // switchCity already reloads data
                    return;
                }
            }

            // stops for nationwide feeds (and as fallback for cities without cache)
            if (currentCity != null && currentCity.nationwide && zoom >= 10.5) {
                fetchStopsForViewport();
            }
            // alpha-1.6.1: stops of EVERY carrier in the viewed area — the
            // nationwide pkp feed contributes its stops (train stations) on
            // top of the selected city's, whatever city is active
            if (zoom >= 10.5) {
                fetchOverlayStops();
            }
            fetchPositions();
        } catch (Throwable t) {
            android.util.Log.e(TAG, "viewport", t);
        }
    }

    private void fetchStopsForViewport() {
        fetchStopsForViewport(false);
    }

    private void fetchStopsForViewport(boolean counted) {
        if (currentCity == null) return;
        final int gen = switchGen;
        String bbox = map.bboxString();
        if (counted) beginLoad();
        Api.getJson(Api.stopsUrl(currentCity.slug, bbox), (json, err) -> {
            if (counted) endLoad();
            if (gen != switchGen || json == null) return;
            List<Models.Stop> stops = Models.Stop.parseList(json);
            map.setStops(stops);
            noteStopTypes(stops);
            if (searchSheet != null) searchSheet.onStopsChanged();
            if (linesSheet != null) linesSheet.onStopsChanged();
        });
    }

    // ------------------------------------------------------------------ overlay stops (all carriers)

    private String lastOverlayBbox = "";
    private long lastOverlayFetchMs = 0;

    /**
     * alpha-1.6.1: viewport stop fetch of a NATIONWIDE feed (pkp) — merged on
     * top of the selected city's stops, so the area you look at always shows
     * every carrier (train stations too), not just the city's buses.
     * Throttled: same bbox at most every 30 s, any bbox at most every 6 s.
     */
    private void fetchOverlayStops() {
        if (currentCity == null || !resumed) return;
        if ("pkp".equals(currentCity.slug)) return; // pkp selected: base load covers it
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastOverlayFetchMs < 6000) return;
        String bbox = map.bboxString();
        if (bbox.equals(lastOverlayBbox) && now - lastOverlayFetchMs < 30000) return;
        lastOverlayBbox = bbox;
        lastOverlayFetchMs = now;
        final int gen = switchGen;
        Api.getJson(Api.stopsUrl("pkp", bbox), (json, err) -> {
            if (gen != switchGen || json == null) return;
            map.setOverlayStops(Models.Stop.parseList(json));
            if (searchSheet != null) searchSheet.onStopsChanged();
            if (linesSheet != null) linesSheet.onStopsChanged();
        });
    }

    void fetchPositions() {
        doFetchPositions(true);
    }

    private void doFetchPositions(boolean force) {
        doFetchPositions(force, false);
    }

    private void doFetchPositions(boolean force, boolean counted) {
        if (!resumed || currentCity == null) return;
        long now = android.os.SystemClock.elapsedRealtime();
        if (!force && now - lastPositionsFetch < 2500) return;
        lastPositionsFetch = now;
        final int gen = switchGen;
        if (counted) beginLoad(); // city vehicles for the loading hourglass
        Api.getJson(Api.positionsUrl(currentCity.slug, map.bboxString()), (json, err) -> {
            if (counted) endLoad();
            if (gen != switchGen) return;
            if (json == null) {
                // alpha-1.6.0: failed fetch -> a quick retry in 5 s (up to 3),
                // not a silent wait for the next refresh cycle. The hourglass
                // keeps flipping so the user sees it is still loading.
                if (resumed && !posRetryPending && posRetries < 3) {
                    posRetries++;
                    posRetryPending = true;
                    beginLoad();
                    handler.postDelayed(positionsRetryTick, 5000);
                }
                return;
            }
            posRetries = 0;
            List<Models.Vehicle> vehicles = Models.Vehicle.parseList(json);
            map.setVehicles(vehicles);
            noteVehicleTypes(vehicles);
            afterPositions(vehicles);
        });
        // PKP trains are always shown, whatever city is active (rate-limited separately)
        if (currentCity == null || !currentCity.slug.equals("pkp")) {
            if (force || now - lastPkpFetch > 20000) {
                lastPkpFetch = now;
                final int gen2 = switchGen;
                if (counted) beginLoad();
                Api.getJson(Api.positionsUrl("pkp", map.bboxString()), (json, err) -> {
                    if (counted) endLoad();
                    if (gen2 != switchGen || json == null) return;
                    map.setPkpVehicles(Models.Vehicle.parseList(json));
                });
            }
        }
    }

    /** Live-update an open vehicle sheet (no map tracking — v1.4.0 removed it). */
    private void afterPositions(List<Models.Vehicle> vehicles) {
        try {
            if (vehicleSheet != null && vehicleSheet.getState() != Sheet.HIDDEN) {
                if (vehicleSheet.isPlanned()) {
                    // alpha-1.6.3: a planned run that just went live flips the
                    // sheet into live mode (and highlights it on the map);
                    // otherwise — once the plan says it should be running —
                    // the sheet reports "Brak danych o lokalizacji pojazdu".
                    Models.Vehicle live = vehicleSheet.tryGoLive(map.getVehicles());
                    if (live != null) {
                        map.setHighlight(live.rtKey(), live);
                    } else {
                        vehicleSheet.onLiveMissing();
                    }
                } else {
                    String id = vehicleSheet.getCurrentVehicleId();
                    Models.Vehicle found = null;
                    if (id != null) {
                        for (Models.Vehicle v : map.getVehicles()) {
                            if (v.id.equals(id)) {
                                found = v;
                                break;
                            }
                        }
                    }
                    if (found != null) {
                        vehicleSheet.update(found);
                    } else {
                        // alpha-1.6.3: the feed lost this vehicle — the map keeps
                        // its last known marker (MapLayers preview snapshot),
                        // the sheet explains there is no live data
                        vehicleSheet.onLiveMissing();
                    }
                }
            }
            // alpha-1.6.0: the line-vehicle list inside the search sheet stays
            // live — it no longer shows a stale snapshot after a city change
            if (searchSheet != null) searchSheet.onVehiclesUpdated();
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ vehicle preview

    public void onVehicleTapped(Models.Vehicle vehicle) {
        safe(() -> {
            openSheetAlone(vehicleSheet, vehicleSheet);
            // alpha-1.6.3: the highlight carries the vehicle's own snapshot —
            // the marker survives even when the live fetch does not return
            // this vehicle (opened from a stop through the wide-area search)
            map.setHighlight(vehicle.rtKey(), vehicle);
            // PKP trains live in their own nationwide feed — trips must load from there
            Cities.City vc = vehicle.pkp ? Cities.bySlug("pkp") : currentCity;
            if (vc == null) vc = currentCity;
            vehicleSheet.open(vc, vehicle);
            map.clearTrip();
        });
    }

    /** Unified display color of a vehicle (type palette, or feed color when kept). */
    int vehicleColor(Models.Vehicle v) {
        if (v == null) return 0xFFD32F2F;
        return prefs.keepOriginalColors() ? v.routeColor : Models.typeColor(v.typeInt());
    }

    /** The trip finished loading: draw it on the map and zoom to fit. */
    void onVehicleTripLoaded(Gtfs.Trip trip) {
        safe(() -> {
            Models.Vehicle v = vehicleSheet == null ? null : vehicleSheet.getVehicle();
            int color = v != null ? vehicleColor(v) : 0xFF1976D2;
            map.setTrip(trip, color);
            if (trip.shape != null && trip.shape.size() >= 2) {
                double[][] pts = new double[trip.shape.size()][2];
                for (int i = 0; i < trip.shape.size(); i++) {
                    pts[i][0] = trip.shape.get(i)[0];
                    pts[i][1] = trip.shape.get(i)[1];
                }
                map.fitTrip(pts, 0.62);
            }
        });
    }

    void onVehiclePreviewClosed() {
        try {
            map.setHighlight(null);
            map.clearTrip();
        } catch (Throwable ignored) {
        }
    }

    /**
     * Best live vehicle for a departure among the given list. v1.4.0 STRICT:
     * the brigade must match — a "whatever vehicle of this line is closest"
     * fallback was opening the wrong (earliest) trip when the tapped one had
     * not departed yet.
     */
    private Models.Vehicle matchDepartureVehicle(Models.Departure d, Models.Stop stop, List<Models.Vehicle> vs) {
        if (vs == null || vs.isEmpty() || d == null) return null;
        boolean hasBrigade = d.brigade != null && !d.brigade.trim().isEmpty();
        Models.Vehicle brigadeMatch = null;
        List<Models.Vehicle> sameRoute = new ArrayList<>();
        for (Models.Vehicle v : vs) {
            if (!routeEq(v.routeName, d.route.name)) continue;
            sameRoute.add(v);
            if (hasBrigade && brigadeEq(v.brigade, d.brigade)) {
                brigadeMatch = v;
                break;
            }
        }
        if (brigadeMatch != null) return brigadeMatch;
        // no brigade info on the departure: accept the only vehicle of the line
        if (!hasBrigade && sameRoute.size() == 1) return sameRoute.get(0);
        return null;
    }

    /**
     * Open the vehicle preview for a tapped departure. v1.4.0:
     *  1. a live vehicle matches only by route + brigade (the exact run);
     *  2. when the run has not started, the GTFS trip of THAT departure opens
     *     as a planned preview — never the earliest vehicle of the line.
     */
    void openVehicleForDeparture(Models.Departure d, Models.Stop stop) {
        safe(() -> {
            Cities.City f = stopSheet == null ? currentCity : stopSheet.getFeedCity();
            final Cities.City feed = f != null ? f : currentCity;
            Models.Vehicle best = matchDepartureVehicle(d, stop, map.getVehicles());
            if (best != null) {
                onVehicleTapped(best);
                return;
            }
            if (d.realtime) {
                Toast.makeText(this, R.string.searching_vehicle, Toast.LENGTH_SHORT).show();
            }
            double lat = stop != null && stop.lat != 0 ? stop.lat
                    : (currentCity != null ? currentCity.lat : 52.23);
            double lon = stop != null && stop.lon != 0 ? stop.lon
                    : (currentCity != null ? currentCity.lon : 21.01);
            boolean rail = d.route.type == 2 || d.route.type == 1;
            fetchWideVehicles(lat, lon, rail, vehicles -> safe(() -> {
                Models.Vehicle found = matchDepartureVehicle(d, stop, vehicles);
                if (found != null) {
                    onVehicleTapped(found);
                } else {
                    // the tapped run is not on the road: show its planned trip
                    openSheetAlone(vehicleSheet, vehicleSheet);
                    // alpha-1.6.3: no leftover highlight from a previous
                    // preview — a planned trip shows the whole map
                    map.setHighlight(null);
                    vehicleSheet.openScheduled(feed, d, stop);
                }
            }));
        });
    }

    /**
     * Positions from a wide box around the given point (current city feed +
     * the nationwide PKP feed when asked). One-shot, used by departure taps
     * and the line-vehicle search list.
     */
    void fetchWideVehicles(double lat, double lon, boolean includePkp,
                           java.util.function.Consumer<List<Models.Vehicle>> done) {
        final List<Models.Vehicle> merged = new java.util.ArrayList<>();
        final String citySlug = currentCity == null ? "warsaw" : currentCity.slug;
        final boolean nationwide = currentCity != null && currentCity.nationwide;
        // ~45 km box for a city; wider for nationwide feeds
        double dLat = nationwide ? 2.2 : 0.42;
        double dLon = nationwide ? 3.4 : 0.62;
        String bbox = String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f",
                lon - dLon, lat - dLat, lon + dLon, lat + dLat);
        final boolean wantPkp = includePkp || "pkp".equals(citySlug);
        final int[] pending = {wantPkp ? 2 : 1};
        Runnable finish = () -> {
            if (pending[0] > 0) pending[0]--;
            if (pending[0] == 0) {
                try {
                    done.accept(merged);
                } catch (Throwable t) {
                    android.util.Log.e(TAG, "wide vehicles cb", t);
                }
            }
        };
        Api.getJson(Api.positionsUrl(citySlug, bbox), (json, err) -> {
            if (json != null) merged.addAll(Models.Vehicle.parseList(json));
            finish.run();
        });
        if (wantPkp && !"pkp".equals(citySlug)) {
            Api.getJson(Api.positionsUrl("pkp", bbox), (json, err) -> {
                if (json != null) {
                    List<Models.Vehicle> pkpList = Models.Vehicle.parseList(json);
                    for (Models.Vehicle v : pkpList) v.pkp = true;
                    merged.addAll(pkpList);
                }
                finish.run();
            });
        }
    }

    private static boolean routeEq(String a, String b) {
        return a != null && b != null && a.trim().equalsIgnoreCase(b.trim());
    }

    private static boolean brigadeEq(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        return a.trim().equalsIgnoreCase(b.trim());
    }

    /** A stop was tapped inside the vehicle route view (or on a route dot). */
    void openStopFromRoute(String stopId, String name, double lat, double lon) {
        safe(() -> {
            String apiId = Gtfs.apiStopId(stopId); // PKP "x----x:2" -> "x"
            Models.Stop found = null;
            for (Models.Stop s : map.getStops()) {
                if (s.id != null && (s.id.equals(apiId) || s.id.equals(stopId))) {
                    found = s;
                    break;
                }
            }
            // the trip was loaded from the vehicle's own feed city (e.g. pkp) —
            // departures must be queried there, not in the current city
            Cities.City vCity = vehicleSheet == null ? null : vehicleSheet.getCity();
            if (vCity == null) vCity = currentCity;
            if (found == null) {
                found = new Models.Stop();
                found.id = apiId.isEmpty() ? "" : apiId;
                found.name = name == null ? "" : name;
                found.lat = lat;
                found.lon = lon;
                found.city = vCity == null ? "" : vCity.slug;
                Models.Vehicle v = vehicleSheet == null ? null : vehicleSheet.getVehicle();
                found.types = new int[]{v == null ? 3 : v.typeInt()};
            }
            openSheetAlone(stopSheet, stopSheet);
            stopSheet.open(vCity, found);
        });
    }

    // ------------------------------------------------------------------ taps

    public void onStopTapped(Models.Stop stop) {
        safe(() -> {
            openSheetAlone(stopSheet, stopSheet);
            stopSheet.open(currentCity, stop);
        });
    }

    private void openStopFromSearch(Models.Stop stop) {
        safe(() -> {
            Cities.City t = Cities.bySlug(stop.city);
            if (t == null) t = currentCity;
            if (t == null) return;
            final Cities.City target = t;
            if (stop.lat == 0 && stop.lon == 0) {
                // favorite/recent without saved coordinates: resolve by id
                Api.getStopsCached(this, target.slug, (stops, err) -> {
                    Models.Stop found = null;
                    if (stops != null) {
                        for (Models.Stop s : stops) {
                            if (s.id != null && s.id.equals(stop.id)) {
                                found = s;
                                break;
                            }
                        }
                    }
                    final Models.Stop fs = found;
                    runOnUiThread(() -> safe(() -> {
                        Models.Stop finalStop;
                        if (fs != null) {
                            finalStop = fs;
                        } else {
                            // not in the list: fall back to the city center so the
                            // favorite still opens something sane
                            stop.lat = target.lat;
                            stop.lon = target.lon;
                            finalStop = stop;
                        }
                        reallyOpenStop(target, finalStop);
                    }));
                });
                return;
            }
            reallyOpenStop(target, stop);
        });
    }

    private void reallyOpenStop(Cities.City target, Models.Stop stop) {
        searchSheet.hide();
        if (currentCity != null && !target.slug.equals(currentCity.slug)) {
            if (target.nationwide) {
                // alpha-1.6.1: a nationwide feed stop (a PKP station opened from
                // search / favorites) keeps the CURRENT city on the map — the
                // sheet simply queries departures in that feed. Switching the
                // whole app would wipe the city the user is browsing.
                centerOn(stop.lat, stop.lon, 16.0);
            } else {
                switchCity(target, false);
            }
        }
        if (currentCity == null || target.slug.equals(currentCity.slug) || !target.nationwide) {
            centerOn(stop.lat, stop.lon, 16.0);
        }
        openSheetAlone(stopSheet, stopSheet);
        stopSheet.open(target, stop);
    }

    /**
     * Geocoded place -> resolve the real stop.
     *
     * alpha-1.6.1 fix of the "Rzeszów Główny takes me to a BUS stop" bug: a
     * rail place (the geocode row carried a train icon) is resolved from the
     * nationwide pkp feed FIRST and opened with the pkp feed city — the
     * parallel city-feed query used to win the race with the identically
     * NAMED bus stop next to the station. Only when pkp has nothing does the
     * city feed get a say (still preferring a rail-typed stop). Stops in
     * other cities switch the city automatically.
     */
    private void openPlace(Api.Place place) {
        safe(() -> {
            searchSheet.hide();
            Cities.City target = cityFromPlace(place);
            if (target == null) {
                Toast.makeText(this, R.string.no_results, Toast.LENGTH_SHORT).show();
                return;
            }
            if (currentCity == null || !target.slug.equals(currentCity.slug)) {
                if (!target.nationwide) switchCity(target, false);
            }
            centerOn(place.lat, place.lon, 16.0);
            String bbox = String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f",
                    place.lon - 0.008, place.lat - 0.005, place.lon + 0.008, place.lat + 0.005);
            if (place.rail) {
                // TRAIN STATION: the pkp feed owns rail stops — query it first
                Api.getJson(Api.stopsUrl("pkp", bbox), (json, err) -> {
                    Models.Stop rail = json == null ? null
                            : findRailStop(Models.Stop.parseList(json), place);
                    if (rail != null) {
                        openResolvedStop(rail, Cities.bySlug("pkp"));
                        return;
                    }
                    resolveCityFeedStop(place, target, bbox); // no rail stop found
                });
            } else {
                resolveCityFeedStop(place, target, bbox);
            }
        });
    }

    /** City-feed fallback resolution of a geocoded place. */
    private void resolveCityFeedStop(Api.Place place, Cities.City city, String bbox) {
        Api.getJson(Api.stopsUrl(city.slug, bbox), (json, err) -> {
            if (json == null) return;
            Models.Stop best = findStopFor(Models.Stop.parseList(json), place, place.rail);
            openResolvedStop(best, city);
        });
    }

    private void openResolvedStop(Models.Stop best, Cities.City feedCity) {
        if (best != null) {
            openSheetAlone(stopSheet, stopSheet);
            stopSheet.open(feedCity, best);
        }
    }

    /** A rail-typed stop whose name matches the station (nearest wins ties). */
    private Models.Stop findRailStop(List<Models.Stop> stops, Api.Place place) {
        if (stops == null || stops.isEmpty()) return null;
        String pn = Ui.norm(place.name);
        Models.Stop nameMatch = null, anyRail = null;
        double bestName = Double.MAX_VALUE, bestRail = Double.MAX_VALUE;
        for (Models.Stop s : stops) {
            boolean rail = false;
            for (int t : s.types) {
                if (t == 2 || t == 1) {
                    rail = true;
                    break;
                }
            }
            double d = Ui.distM(place.lat, place.lon, s.lat, s.lon);
            if (rail && d < bestRail) {
                bestRail = d;
                anyRail = s;
            }
            if (nameMatch == null && !pn.isEmpty() && rail
                    && (Ui.norm(s.name).contains(pn) || pn.contains(Ui.norm(s.name)))
                    && d < bestName) {
                bestName = d;
                nameMatch = s;
            }
        }
        if (nameMatch != null) return nameMatch;
        return anyRail != null && bestRail < 600 ? anyRail : null;
    }

    /** Prefer a name-matching stop of the right kind; fall back to the nearest one. */
    private Models.Stop findStopFor(List<Models.Stop> stops, Api.Place place, boolean preferRail) {
        if (stops == null || stops.isEmpty()) return null;
        String pn = Ui.norm(place.name);
        Models.Stop nameMatch = null, nameRailMatch = null, railNear = null, nearest = null;
        double bestRailD = Double.MAX_VALUE, bestD = Double.MAX_VALUE;
        for (Models.Stop s : stops) {
            double d = Ui.distM(place.lat, place.lon, s.lat, s.lon);
            if (d < bestD) {
                bestD = d;
                nearest = s;
            }
            boolean rail = false;
            for (int t : s.types) {
                if (t == 2 || t == 1) {
                    rail = true;
                    break;
                }
            }
            if (rail && d < bestRailD) {
                bestRailD = d;
                railNear = s;
            }
            if (!pn.isEmpty() && (Ui.norm(s.name).contains(pn) || pn.contains(Ui.norm(s.name)))) {
                if (nameMatch == null) nameMatch = s;
                if (nameRailMatch == null && rail) nameRailMatch = s;
            }
        }
        if (nameRailMatch != null) return nameRailMatch; // name AND the right kind
        if (preferRail && railNear != null && bestRailD < 250) return railNear;
        if (nameMatch != null) return nameMatch;
        return bestD < 400 ? nearest : null;
    }

    /** "pl-Rzeszów_628" -> Rzeszów city; falls back to nearest city by coordinates. */
    private Cities.City cityFromPlace(Api.Place place) {
        try {
            String id = place.id;
            if (id != null && id.contains("-") && id.lastIndexOf('_') > id.indexOf('-')) {
                String cityPart = id.substring(id.indexOf('-') + 1, id.lastIndexOf('_'));
                Cities.City c = Cities.byName(cityPart.replace('_', ' '));
                if (c != null) return c;
            }
        } catch (Throwable ignored) {
        }
        return Cities.nearest(place.lat, place.lon, 80);
    }

    // ------------------------------------------------------------------ location

    private void onLocateClicked() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            return;
        }
        // alpha-1.6.3: pressing locate = explicitly using my location; if the
        // settings switch was off, it turns back on right here
        if (!prefs.useMyLocation()) prefs.setUseMyLocation(true);
        enableLocation();
    }

    private void enableLocation() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) {
                try {
                    Location last = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (last == null) last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (last == null) last = lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                    if (last != null) {
                        lastLocation = last;
                        map.setLocation(last.getLatitude(), last.getLongitude());
                        centerOn(last.getLatitude(), last.getLongitude(), 15.0);
                    }
                    // v1.5.0: location refresh cadence raised (GPS 5 s, network 6 s,
                    // any distance) — the blue dot keeps up with a moving user
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 6000, 0, locationListener);
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 0, locationListener);
                } catch (SecurityException | IllegalArgumentException ignored) {
                }
            }
        } catch (Throwable t) {
            android.util.Log.e(TAG, "location", t);
        }
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            lastLocation = l;
            try {
                map.setLocation(l.getLatitude(), l.getLongitude());
            } catch (Throwable ignored) {
            }
        }

        @Override
        public void onStatusChanged(String p, int s, Bundle e) {
        }

        @Override
        public void onProviderEnabled(String p) {
        }

        @Override
        public void onProviderDisabled(String p) {
        }
    };

    Location getLastLocation() {
        // alpha-1.6.3: "Używaj mojej lokalizacji" OFF — the app does not touch
        // the location providers at all (no last-known reads either)
        if (prefs != null && !prefs.useMyLocation()) {
            lastLocation = null;
            return null;
        }
        if (lastLocation != null) return lastLocation;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) {
                Location l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (l == null) l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (l == null) l = lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                if (l != null) lastLocation = l;
            }
        } catch (Throwable ignored) {
        }
        return lastLocation;
    }

    /**
     * alpha-1.6.3: "Używaj mojej lokalizacji" turned OFF — unregister the
     * providers, forget the fix and drop the blue dot from the map.
     */
    private void disableMyLocation() {
        lastLocation = null;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) lm.removeUpdates(locationListener);
        } catch (Throwable ignored) {
        }
        if (map != null) map.clearLocation();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (code == 1 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            // alpha-1.6.3: granting permission from the settings switch keeps
            // the switch ON — this callback fires for both entry points
            if (!prefs.useMyLocation()) prefs.setUseMyLocation(true);
            enableLocation();
        }
    }

    // ------------------------------------------------------------------ settings tab

    private static final int[] REFRESH_VALUES = {5, 10, 15, 30};
    private static final String[] SCALE_NAMES = {"S", "M", "L"};
    /** alpha-1.6.2: text size cycler (A- / A / A+ / A++) and its factors. */
    private static final String[] TEXT_NAMES = {"A-", "A", "A+", "A++"};
    private static final float[] TEXT_FACTORS = {0.87f, 1f, 1.13f, 1.28f};
    /** "Wyświetlanie znaczników" collapsible section (like the FAQ cards). */
    private boolean markersSectionOpen = false;

    // manual map refresh button: 5 s cooldown with a live countdown
    private View btnRefresh;
    private TextView refreshCount;
    private ImageView refreshIcon;
    private int refreshCooldown = 0;
    private final Runnable refreshCooldownTick = new Runnable() {
        @Override
        public void run() {
            refreshCooldown--;
            if (refreshCooldown <= 0) {
                setRefreshEnabled(true);
                return;
            }
            if (refreshCount != null) refreshCount.setText(String.valueOf(refreshCooldown));
            handler.postDelayed(this, 1000);
        }
    };

    private void buildSettings() {
        LinearLayout list = findViewById(R.id.settingsList);
        list.removeAllViews();

        // ---- Widoczność obiektów na mapie ----
        addSectionHeader(list, getString(R.string.settings_section_visibility));
        addSwitchRow(list, R.drawable.bus, getString(R.string.settings_vehicles_on_map),
                prefs.showVehicles(), on -> {
                    prefs.setShowVehicles(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.pin, getString(R.string.settings_stops_on_map),
                prefs.showStops(), on -> {
                    prefs.setShowStops(on);
                    if (map != null) map.rebuildPublic();
                });

        // alpha-1.6.3: "Wyświetlanie znaczników" moved INTO the Zaawansowane
        // section — see addMarkersRow() below

        // ---- Ogólne ----
        addSectionHeader(list, getString(R.string.settings_section_general));
        addValueRow(list, R.drawable.clockoutline, getString(R.string.settings_refresh),
                prefs.refreshInterval() + " s", () -> {
                    int cur = prefs.refreshInterval();
                    int next = REFRESH_VALUES[0];
                    for (int i = 0; i < REFRESH_VALUES.length; i++) {
                        if (REFRESH_VALUES[i] == cur) next = REFRESH_VALUES[(i + 1) % REFRESH_VALUES.length];
                    }
                    prefs.setRefreshInterval(next);
                    return next + " s";
                });
        // alpha-1.6.2: the S/M/L icon size actually resizes the markers now —
        // the layer iconSize factor + scaled stop bitmaps re-register instantly
        addValueRow(list, R.drawable.tune, getString(R.string.settings_marker_size),
                SCALE_NAMES[prefs.vehicleScale()], () -> {
                    int next = (prefs.vehicleScale() + 1) % 3;
                    prefs.setVehicleScale(next);
                    if (map != null) map.refreshThresholds();
                    return SCALE_NAMES[next];
                });
        // alpha-1.6.2: text size A- / A / A+ / A++ everywhere in the app
        addValueRow(list, R.drawable.format_text_size, getString(R.string.settings_text_size),
                TEXT_NAMES[prefs.textScale()], () -> {
                    int next = (prefs.textScale() + 1) % TEXT_NAMES.length;
                    prefs.setTextScale(next);
                    Ui.textFactor = TEXT_FACTORS[next];
                    buildSettings(); // the settings rows themselves rescale
                    applyTextFactor(); // alpha-1.6.3: top bar + search input too
                    return TEXT_NAMES[next];
                });
        addSwitchRow(list, R.drawable.transitconnection, getString(R.string.settings_filter_technical),
                prefs.filterTechnical(), on -> {
                    prefs.setFilterTechnical(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.crosshairsgps, getString(R.string.settings_autocity),
                prefs.autoCity(), on -> prefs.setAutoCity(on));
        // alpha-1.6.3: "Używaj mojej lokalizacji" — master switch for startup
        // centering, the blue dot and background location updates
        addSwitchRow(list, R.drawable.mapmarker, getString(R.string.settings_use_location),
                prefs.useMyLocation(), on -> {
                    prefs.setUseMyLocation(on);
                    if (on) {
                        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                                == PackageManager.PERMISSION_GRANTED) {
                            enableLocation(); // dot + center, like the locate button
                        } else {
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
                        }
                    } else {
                        disableMyLocation();
                    }
                });
        // alpha-1.6.2: Podkład mapy cycles through the basic style VARIANTS too
        addValueRow(list, R.drawable.layers, getString(R.string.settings_tiles),
                tileName(prefs.mapStyle()), () -> {
                    int cur = prefs.mapStyle();
                    int at = 0;
                    for (int i = 0; i < StyleVariants.STYLE_ORDER.length; i++) {
                        if (StyleVariants.STYLE_ORDER[i] == cur) at = i;
                    }
                    int next = StyleVariants.STYLE_ORDER[(at + 1) % StyleVariants.STYLE_ORDER.length];
                    prefs.setMapStyle(next);
                    applyTileSource();
                    return tileName(next);
                });

        // ---- Zaawansowane (v1.5.0: drobne opcje schowane do sekcji zaawansowanej) ----
        addSectionHeader(list, getString(R.string.settings_section_advanced));
        // alpha-1.6.3: "Wyświetlanie znaczników" — the FIRST item of the
        // advanced section, styled EXACTLY like every other option row
        // (icon + label + chevron); expanding reveals the sliders
        addMarkersRow(list);
        addSwitchRow(list, R.drawable.tag, getString(R.string.settings_brigade),
                prefs.showBrigade(), on -> {
                    prefs.setShowBrigade(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.numeric, getString(R.string.settings_fleet),
                prefs.showFleet(), on -> {
                    prefs.setShowFleet(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.bus, getString(R.string.settings_hide_vehicle_icon),
                prefs.hideVehicleIcon(), on -> {
                    prefs.setHideVehicleIcon(on);
                    if (map != null) map.rebuildPublic();
                });
        addSwitchRow(list, R.drawable.layers, getString(R.string.settings_keep_colors),
                prefs.keepOriginalColors(), on -> {
                    prefs.setKeepOriginalColors(on);
                    if (map != null) map.rebuildPublic();
                });

        addActionRow(list, R.drawable.delete, getString(R.string.settings_cache_clear))
                .setOnClickListener(v -> safe(() -> {
                    Api.clearCache(this);
                    Toast.makeText(this, R.string.settings_cache_cleared, Toast.LENGTH_SHORT).show();
                }));
        addActionRow(list, R.drawable.informationoutline, getString(R.string.settings_about))
                .setOnClickListener(v -> safe(this::showAbout));
    }

    /**
     * alpha-1.6.3: "Wyświetlanie znaczników" — a REGULAR settings row (the
     * same icon + label pattern as every other option, with a chevron on the
     * right) INSIDE the Zaawansowane section. Tapping expands it in place,
     * revealing the zoom-threshold sliders with plain names
     * (pojazd / przystanek / pociąg); defaults 13 / 15 / 11.
     */
    private void addMarkersRow(LinearLayout list) {
        View v = buildRow(list, R.drawable.layers, getString(R.string.settings_section_markers));
        Switch sw = v.findViewById(R.id.setSwitch);
        TextView value = v.findViewById(R.id.setValue);
        Ui.setVisible(sw, false);
        Ui.setVisible(value, false);

        final LinearLayout row = (LinearLayout) v;
        final ImageView chev = new ImageView(this);
        chev.setImageResource(R.drawable.chevrondown);
        chev.setColorFilter(0xFF5F5F66);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22));
        row.addView(chev, clp);

        final LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(this, 10), 0, 0, Ui.dp(this, 2));
        body.setVisibility(markersSectionOpen ? View.VISIBLE : View.GONE);
        chev.setRotation(markersSectionOpen ? 180 : 0);

        row.setOnClickListener(x -> {
            markersSectionOpen = !markersSectionOpen;
            chev.animate().rotation(markersSectionOpen ? 180 : 0).setDuration(180).start();
            body.setVisibility(markersSectionOpen ? View.VISIBLE : View.GONE);
        });

        addSliderRow(body, R.drawable.bus, getString(R.string.marker_vehicle),
                prefs.dotZoomVehicles(), 60, 190, v2 -> {
                    prefs.setDotZoomVehicles(v2);
                    if (map != null) map.refreshThresholds();
                });
        addSliderRow(body, R.drawable.pin, getString(R.string.marker_stop),
                prefs.dotZoomStops(), 60, 190, v2 -> {
                    prefs.setDotZoomStops(v2);
                    if (map != null) map.refreshThresholds();
                });
        addSliderRow(body, R.drawable.ic_type_train, getString(R.string.marker_train),
                prefs.dotZoomPkp(), 60, 190, v2 -> {
                    prefs.setDotZoomPkp(v2);
                    if (map != null) map.refreshThresholds();
                });

        list.addView(body);
    }

    /** Gray all-caps section title inside the settings list. */
    private void addSectionHeader(LinearLayout list, String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(0xFF5F5F66);
        tv.setTextSize(12f);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setAllCaps(true);
        tv.setLetterSpacing(0.05f);
        tv.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 6));
        list.addView(tv);
    }

    private String tileName(int style) {
        switch (style) {
            case 1: return getString(R.string.settings_tiles_osm);
            case 2: return getString(R.string.settings_tiles_sat);
            case 3: return getString(R.string.settings_tiles_pastel);
            case 4: return getString(R.string.settings_tiles_contrast);
            case 5: return getString(R.string.settings_tiles_warm);
            case 6: return getString(R.string.settings_tiles_cool);
            default: return getString(R.string.settings_tiles_basic);
        }
    }

    private void applyTileSource() {
        if (prefs == null || map == null) return;
        int style = prefs.mapStyle();
        if (style != tileStyle) {
            tileStyle = style;
            map.applyStyle(style);
            switch (style) {
                case 1:
                    attribution.setText("© OpenStreetMap");
                    break;
                case 2:
                    attribution.setText("Esri, Maxar, Earthstar Geographics");
                    break;
                default:
                    attribution.setText("© OpenStreetMap · © OpenFreeMap");
                    break;
            }
        }
    }

    private interface ValueCycler {
        String cycle();
    }

    private interface BoolSetter {
        void set(boolean v);
    }

    private View buildRow(LinearLayout list, int iconRes, String label) {
        View v = LayoutInflater.from(this).inflate(R.layout.row_setting, list, false);
        list.addView(v);
        ImageView icon = v.findViewById(R.id.setIcon);
        TextView labelTv = v.findViewById(R.id.setLabel);
        icon.setImageResource(iconRes);
        icon.setColorFilter(0xFF1C1B1F);
        labelTv.setText(label);
        Ui.scaleTextTree(v); // alpha-1.6.2: the A- / A / A+ / A++ text size
        return v;
    }

    private View addSwitchRow(LinearLayout list, int iconRes, String label, boolean checked, BoolSetter setter) {
        View v = buildRow(list, iconRes, label);
        Switch sw = v.findViewById(R.id.setSwitch);
        TextView value = v.findViewById(R.id.setValue);
        Ui.setVisible(sw, true);
        Ui.setVisible(value, false);
        // alpha-1.6.0: Android must NOT auto-restore a stale checked state after
        // the activity is recreated — the row always shows the persisted pref
        sw.setSaveEnabled(false);
        sw.setChecked(checked);
        sw.setOnCheckedChangeListener((btn, on) -> setter.set(on));
        v.setOnClickListener(x -> sw.setChecked(!sw.isChecked()));
        return v;
    }

    private View addValueRow(LinearLayout list, int iconRes, String label, String current, ValueCycler cycler) {
        View v = buildRow(list, iconRes, label);
        Switch sw = v.findViewById(R.id.setSwitch);
        TextView value = v.findViewById(R.id.setValue);
        Ui.setVisible(sw, false);
        Ui.setVisible(value, true);
        value.setText(current);
        v.setOnClickListener(x -> value.setText(cycler.cycle()));
        return v;
    }

    /** Debug-overlay slider: zoom threshold in 0.5 steps with a live numeric readout. */
    private View addSliderRow(LinearLayout list, int iconRes, String label,
                              int valueX10, int min, int max, final java.util.function.IntConsumer setter) {
        View v = buildRow(list, iconRes, label);
        Switch sw = v.findViewById(R.id.setSwitch);
        Ui.setVisible(sw, false);
        // turn the value TextView into the live numeric readout
        TextView value = v.findViewById(R.id.setValue);
        Ui.setVisible(value, true);
        value.setText(String.format(Locale.US, "%.1f", valueX10 / 10f));
        SeekBar bar = new SeekBar(this);
        bar.setMax((max - min) / 5);
        bar.setProgress((valueX10 - min) / 5);
        bar.setPadding(Ui.dp(this, 4), Ui.dp(this, 2), Ui.dp(this, 4), Ui.dp(this, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        v.setOnClickListener(null);
        LinearLayout row = (LinearLayout) v;
        row.setOrientation(LinearLayout.VERTICAL);
        // rebuild content vertically: keep the header row, put the slider under it
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageView icon = v.findViewById(R.id.setIcon);
        TextView labelTv = v.findViewById(R.id.setLabel);
        android.view.ViewGroup parent = (android.view.ViewGroup) icon.getParent();
        parent.removeView(icon);
        parent.removeView(labelTv);
        parent.removeView(value);
        parent.removeView(sw);
        header.addView(icon);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        llp.leftMargin = Ui.dp(this, 14);
        header.addView(labelTv, llp);
        header.addView(value);
        row.removeAllViews();
        row.addView(header);
        row.addView(bar, lp);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int vx = min + progress * 5;
                value.setText(String.format(Locale.US, "%.1f", vx / 10f));
                if (fromUser) setter.accept(vx);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        return v;
    }

    private View addActionRow(LinearLayout list, int iconRes, String label) {
        View v = buildRow(list, iconRes, label);
        Ui.setVisible(v.findViewById(R.id.setSwitch), false);
        Ui.setVisible(v.findViewById(R.id.setValue), false);
        v.setClickable(true);
        return v;
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.app_name)
                .setMessage(getString(R.string.about_text, App.appVersion(this)))
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }

    // ------------------------------------------------------------------ session (alpha-1.6.4)

    /**
     * alpha-1.6.4: WHAT IS ON SCREEN is written to filesDir/session_state.json
     * on every pause. When the system kills the process (screen off, the app
     * switched away for a while — even force-stop), the next start opens the
     * same preview again instead of a bare map: the tracked bus/stop/tab
     * simply SURVIVES. Camera and city were already persisted (see onPause);
     * this closes the last gap — the sheet state.
     */
    private void saveSession() {
        try {
            org.json.JSONObject s = new org.json.JSONObject();
            s.put("ts", System.currentTimeMillis());
            s.put("tab", curTab);
            Sheet open = currentOpenSheet();
            if (open == vehicleSheet) {
                Models.Vehicle v = vehicleSheet.getVehicle();
                Cities.City vc = vehicleSheet.getCity();
                if (v != null && vc != null && v.id != null && !v.id.isEmpty()) {
                    org.json.JSONObject vo = vehicleToJson(v);
                    vo.put("city", vc.slug);
                    if (vehicleSheet.isPlanned()) {
                        vo.put("planned", true);
                        vo.put("plannedRouteId", vehicleSheet.getPlannedRouteId());
                        vo.put("plannedDepMs", vehicleSheet.getPlannedDepMs());
                        Models.Stop ps = vehicleSheet.getPlannedStop();
                        if (ps != null) vo.put("plannedStop", stopToJson(ps));
                    }
                    s.put("sheet", "vehicle");
                    s.put("vehicle", vo);
                }
            } else if (open == stopSheet) {
                Models.Stop st = stopSheet.getCurrentStop();
                Cities.City feed = stopSheet.getFeedCity();
                if (st != null && feed != null && st.id != null && !st.id.isEmpty()) {
                    org.json.JSONObject so = stopToJson(st);
                    so.put("feedCity", feed.slug);
                    s.put("sheet", "stop");
                    s.put("stop", so);
                }
            } else if (open == citySheet) {
                s.put("sheet", "city");
            } else if (open == searchSheet) {
                s.put("sheet", "search");
            } else if (open == linesSheet) {
                s.put("sheet", "lines");
            }
            Session.save(this, s);
        } catch (Throwable t) {
            android.util.Log.w(TAG, "saveSession", t);
        }
    }

    private Sheet currentOpenSheet() {
        Sheet[] all = {citySheet, searchSheet, stopSheet, vehicleSheet, linesSheet};
        for (Sheet s : all) {
            if (s != null && s.getState() != Sheet.HIDDEN) return s;
        }
        return null;
    }

    /** alpha-1.6.4: rebuild the paused UI state after a process death. */
    private void restoreSession() {
        try {
            org.json.JSONObject s = Session.load(this);
            if (s == null) return;
            int tab = s.optInt("tab", 0);
            String sheet = s.optString("sheet", "");
            // tabs 1/2 cannot host sheets — restoring the tab is enough there
            if (tab == 1 || tab == 2) {
                if (curTab != tab) setTab(tab);
                return;
            }
            if ("vehicle".equals(sheet)) {
                org.json.JSONObject vo = s.optJSONObject("vehicle");
                if (vo == null) return;
                Models.Vehicle v = vehicleFromJson(vo);
                if (v == null || v.id == null || v.id.isEmpty()) return;
                Cities.City vc = Cities.bySlug(vo.optString("city", ""));
                if (vc == null) vc = currentCity;
                if (vc == null) return;
                if (vo.optBoolean("planned")) {
                    // planned run: whole map + trip polyline, NO highlight
                    // marker (the snapshot has no live position yet)
                    map.setHighlight(null);
                    Models.Stop ps = stopFromJson(vo.optJSONObject("plannedStop"));
                    vehicleSheet.reopenPlanned(vc, v, ps,
                            vo.optString("plannedRouteId", ""), vo.optLong("plannedDepMs", 0L));
                } else {
                    // live run: same path as a tap — highlight keeps the last
                    // known marker on the map, the sheet reloads the trip
                    openSheetAlone(vehicleSheet, vehicleSheet);
                    map.setHighlight(v.rtKey(), v);
                    vehicleSheet.open(vc, v);
                }
            } else if ("stop".equals(sheet)) {
                org.json.JSONObject so = s.optJSONObject("stop");
                if (so == null) return;
                Models.Stop st = stopFromJson(so);
                if (st == null || st.id == null || st.id.isEmpty()) return;
                Cities.City feed = Cities.bySlug(so.optString("feedCity", st.city));
                if (feed == null) feed = currentCity;
                if (feed == null) return;
                openSheetAlone(stopSheet, stopSheet);
                stopSheet.open(feed, st);
            } else if ("city".equals(sheet)) {
                openSheetAlone(citySheet, citySheet);
                citySheet.show();
            } else if ("search".equals(sheet)) {
                openSheetAlone(searchSheet, searchSheet);
                searchSheet.show();
            } else if ("lines".equals(sheet)) {
                openSheetAlone(linesSheet, linesSheet);
                linesSheet.show();
            }
        } catch (Throwable t) {
            android.util.Log.w(TAG, "restoreSession", t);
        }
    }

    // ------------------------------------------------------------ session JSON

    private static org.json.JSONObject vehicleToJson(Models.Vehicle v) {
        org.json.JSONObject o = new org.json.JSONObject();
        try {
            o.put("id", v.id);
            o.put("type", v.type);
            o.put("agency", v.agency);
            if (v.model != null) o.put("model", v.model);
            o.put("routeName", v.routeName);
            o.put("brigade", v.brigade);
            o.put("headsign", v.headsign);
            if (v.url != null) o.put("url", v.url);
            o.put("routeColor", v.routeColor);
            o.put("lat", v.lat);
            o.put("lon", v.lon);
            o.put("timestamp", v.timestamp);
            if (v.delay != null) o.put("delay", v.delay.longValue());
            if (v.bearing != null) o.put("bearing", v.bearing.intValue());
            o.put("pkp", v.pkp);
            org.json.JSONArray up = new org.json.JSONArray();
            if (v.upcoming != null) {
                for (Models.Upcoming u : v.upcoming) {
                    org.json.JSONObject uo = new org.json.JSONObject();
                    uo.put("name", u.name);
                    uo.put("sequence", u.sequence);
                    uo.put("scheduledArrival", u.scheduledArrival);
                    uo.put("scheduledDeparture", u.scheduledDeparture);
                    up.put(uo);
                }
            }
            o.put("upcoming", up);
        } catch (Throwable ignored) {
        }
        return o;
    }

    private static Models.Vehicle vehicleFromJson(org.json.JSONObject o) {
        if (o == null) return null;
        try {
            Models.Vehicle v = new Models.Vehicle();
            v.id = o.optString("id", "");
            v.type = o.optString("type", "3");
            v.agency = o.optString("agency", "default");
            v.model = o.optString("model", "");
            v.routeName = o.optString("routeName", "");
            v.brigade = o.optString("brigade", "");
            v.headsign = o.optString("headsign", "");
            v.url = o.optString("url", "");
            v.routeColor = o.optInt("routeColor", 0xFFD32F2F);
            v.lat = o.optDouble("lat", 0);
            v.lon = o.optDouble("lon", 0);
            v.timestamp = o.optLong("timestamp", 0);
            if (o.has("delay") && !o.isNull("delay")) v.delay = o.optLong("delay", 0);
            if (o.has("bearing") && !o.isNull("bearing")) v.bearing = o.optInt("bearing", 0);
            v.pkp = o.optBoolean("pkp", false);
            org.json.JSONArray up = o.optJSONArray("upcoming");
            if (up != null && up.length() > 0) {
                List<Models.Upcoming> list = new ArrayList<>();
                for (int i = 0; i < up.length(); i++) {
                    org.json.JSONObject uo = up.optJSONObject(i);
                    if (uo == null) continue;
                    Models.Upcoming uu = new Models.Upcoming();
                    uu.name = uo.optString("name", "");
                    uu.sequence = uo.optInt("sequence", -1);
                    uu.scheduledArrival = uo.optLong("scheduledArrival", 0);
                    uu.scheduledDeparture = uo.optLong("scheduledDeparture", 0);
                    list.add(uu);
                }
                v.upcoming = list.toArray(new Models.Upcoming[0]);
            }
            return v;
        } catch (Throwable t) {
            return null;
        }
    }

    private static org.json.JSONObject stopToJson(Models.Stop st) {
        org.json.JSONObject o = new org.json.JSONObject();
        try {
            o.put("id", st.id);
            o.put("city", st.city);
            o.put("name", st.name);
            o.put("code", st.code);
            o.put("direction", st.direction);
            o.put("lat", st.lat);
            o.put("lon", st.lon);
            org.json.JSONArray types = new org.json.JSONArray();
            for (int t : st.types) types.put(t);
            o.put("types", types);
            if (st.bearing != null) o.put("bearing", st.bearing.intValue());
            org.json.JSONArray rs = new org.json.JSONArray();
            if (st.routes != null) {
                for (Models.Route r : st.routes) {
                    org.json.JSONObject ro = new org.json.JSONObject();
                    ro.put("id", r.id);
                    ro.put("name", r.name);
                    ro.put("longName", r.longName);
                    ro.put("agency", r.agency);
                    ro.put("type", r.type);
                    ro.put("color", r.color);
                    rs.put(ro);
                }
            }
            o.put("routes", rs);
        } catch (Throwable ignored) {
        }
        return o;
    }

    private static Models.Stop stopFromJson(org.json.JSONObject o) {
        if (o == null) return null;
        try {
            Models.Stop st = new Models.Stop();
            st.id = o.optString("id", "");
            st.city = o.optString("city", "");
            st.name = o.optString("name", "");
            st.code = o.optString("code", "");
            st.direction = o.optString("direction", "");
            st.lat = o.optDouble("lat", 0);
            st.lon = o.optDouble("lon", 0);
            org.json.JSONArray types = o.optJSONArray("types");
            if (types != null && types.length() > 0) {
                st.types = new int[types.length()];
                for (int i = 0; i < types.length(); i++) st.types[i] = types.optInt(i, 3);
            }
            if (o.has("bearing") && !o.isNull("bearing")) st.bearing = o.optInt("bearing", 0);
            org.json.JSONArray rs = o.optJSONArray("routes");
            if (rs != null && rs.length() > 0) {
                List<Models.Route> list = new ArrayList<>();
                for (int i = 0; i < rs.length(); i++) {
                    org.json.JSONObject ro = rs.optJSONObject(i);
                    if (ro == null) continue;
                    Models.Route r = new Models.Route();
                    r.id = ro.optString("id", "");
                    r.name = ro.optString("name", "");
                    r.longName = ro.optString("longName", "");
                    r.agency = ro.optString("agency", "default");
                    r.type = ro.optInt("type", 3);
                    r.color = ro.optInt("color", 0xFFD32F2F);
                    list.add(r);
                }
                st.routes = list.toArray(new Models.Route[0]);
            }
            return st;
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    /**
     * alpha-1.6.0: the back button/gesture walks back through the UI:
     * open sheet -> close it; another tab -> back to the map; map -> leave
     * the app (kept in recents, data refreshes on return).
     */
    @Override
    public void onBackPressed() {
        try {
            Sheet open = null;
            Sheet[] all = {citySheet, searchSheet, stopSheet, vehicleSheet, linesSheet};
            for (Sheet s : all) {
                if (s != null && s.getState() != Sheet.HIDDEN) {
                    open = s;
                    break;
                }
            }
            if (open != null) {
                open.hide();
                return;
            }
        } catch (Throwable ignored) {
        }
        if (curTab != 0) {
            setTab(0);
            return;
        }
        moveTaskToBack(true);
    }
    @Override
    protected void onStart() {
        super.onStart();
        try {
            if (map != null) map.onStart();
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onStop() {
        try {
            if (map != null) map.onStop();
        } catch (Throwable ignored) {
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sheetContainer == null) return; // layout failed, activity is finishing
        resumed = true;
        map.onResume();
        applyTileSource();
        // alpha-1.6.4: re-assert the persisted settings on return — the tab is
        // rebuilt from Prefs, so a stale/lost switch state can never stick
        if (curTab == 2) buildSettings();
        if (map != null) map.rebuildPublic();
        // v1.5.0: refresh the data right away after returning from the
        // background — no 1.2 s of silence before the first fetch
        doFetchPositions(true, true);
        schedulePositions();
        fetchOverlayStops(); // alpha-1.6.1: carrier overlay fills in again too
        // v1.5.0: location updates restart with the app (they were dropped on
        // pause and never re-registered before).
        // alpha-1.6.3: only while "Używaj mojej lokalizacji" is ON
        if (prefs.useMyLocation()
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            enableLocationQuiet();
        } else if (!prefs.useMyLocation() && map != null) {
            map.clearLocation(); // the dot is not drawn for a fresh start either
        }
    }

    /** Re-register location listeners WITHOUT the camera jump. */
    private void enableLocationQuiet() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 6000, 0, locationListener);
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 0, locationListener);
            }
        } catch (Throwable ignored) {
        }
    }

    private void schedulePositions() {
        handler.removeCallbacks(positionsTick);
        handler.removeCallbacks(positionsTickInitial);
        // v1.4.1: the first fetch after (re)start is counted — the hourglass
        // shows until the map has data
        handler.postDelayed(positionsTickInitial, 1200);
    }
    @Override
    protected void onPause() {
        resumed = false;
        handler.removeCallbacks(viewportSettled);
        handler.removeCallbacks(positionsTick);
        try {
            LatLng c = map.center();
            // v1.5.0: never persist a broken camera (map still loading ->
            // the next start would open on the world map)
            if (validCoords(c.getLatitude(), c.getLongitude())) {
                prefs.setCamera(c.getLatitude(), c.getLongitude(), map.camZoom());
            }
            prefs.setLastCity(currentCity == null ? "warsaw" : currentCity.slug);
        } catch (Throwable ignored) {
        }
        // alpha-1.6.4: snapshot of the open preview/tab — restored on the next
        // start when the system killed the process in the background
        saveSession();
        map.onPause();
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) lm.removeUpdates(locationListener);
        } catch (Throwable ignored) {
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        map.onDestroy();
        super.onDestroy();
    }
}
