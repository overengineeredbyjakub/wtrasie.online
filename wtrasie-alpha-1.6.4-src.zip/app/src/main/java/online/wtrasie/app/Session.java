package online.wtrasie.app;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * alpha-1.6.4: persists the CURRENT UI session — which sheet is open (the
 * previewed vehicle, the opened stop, the search/city/lines panel) and the
 * active tab — into a tiny JSON file (filesDir/session_state.json).
 *
 * The file is rewritten on every onPause() and cleared content is stored when
 * nothing is open, so it ALWAYS mirrors what the user sees at the moment the
 * app leaves the foreground. When the system then kills the process (screen
 * off, another app in the foreground for a while), the next start rebuilds
 * EXACTLY that state: the previewed bus opens again with its highlight, the
 * stop panel reopens with live departures — nothing is "completely switched
 * off" anymore.
 *
 * Written synchronously like commit() — losing it would mean a plain cold
 * start, never a crash.
 */
public final class Session {

    private static final String FILE = "session_state.json";
    /** A session older than 6 h is no longer restored (a stale vehicle from
     *  the morning would be more confusing than helpful). Stops and tabs have
     *  no age problem, but one cap keeps the logic simple. */
    private static final long MAX_AGE_MS = 6L * 60 * 60 * 1000;

    private Session() {
    }

    private static File file(Context c) {
        return new File(c.getFilesDir(), FILE);
    }

    /** Synchronously write the session snapshot (atomic: tmp file + rename). */
    public static void save(Context c, JSONObject o) {
        try {
            File f = file(c);
            File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            out.write(o.toString().getBytes("UTF-8"));
            out.flush();
            out.getFD().sync();
            out.close();
            if (!tmp.renameTo(f)) {
                FileOutputStream direct = new FileOutputStream(f);
                direct.write(o.toString().getBytes("UTF-8"));
                direct.close();
            }
        } catch (Throwable t) {
            android.util.Log.w("Session", "save failed", t);
        }
    }

    /** The last saved snapshot, or null when absent/corrupt/older than 6 h. */
    public static JSONObject load(Context c) {
        try {
            File f = file(c);
            if (!f.exists()) return null;
            FileInputStream in = new FileInputStream(f);
            StringBuilder sb = new StringBuilder();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) sb.append(new String(buf, 0, n, "UTF-8"));
            in.close();
            JSONObject o = new JSONObject(sb.toString());
            long ts = o.optLong("ts", 0);
            if (ts <= 0 || System.currentTimeMillis() - ts > MAX_AGE_MS) return null;
            return o;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Remove the snapshot (used when the app is finishing for good). */
    public static void clear(Context c) {
        try {
            File f = file(c);
            if (f.exists()) f.delete();
            File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
            if (tmp.exists()) tmp.delete();
        } catch (Throwable ignored) {
        }
    }
}
