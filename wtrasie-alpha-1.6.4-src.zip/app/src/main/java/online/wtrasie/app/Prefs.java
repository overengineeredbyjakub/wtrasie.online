package online.wtrasie.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * App settings persisted in SharedPreferences.
 *
 * alpha-1.6.2: every setter uses commit() (a SYNCHRONOUS disk write) instead
 * of apply(). apply() hands the write to a background thread — when the OEM
 * kills the process the pending write could be lost, which is exactly the
 * "all switches off after a few hours unused" bug. A tiny XML commit on the
 * main thread costs microseconds; losing the settings cost user trust.
 *
 * alpha-1.6.4: commit() alone still was not enough on some devices — users
 * reported all switches back to OFF after the screen was off / the app was
 * backgrounded for longer (process killed AND the prefs file lost or rolled
 * back by an aggressive system cleaner). Since 1.6.4 EVERY setting is
 * additionally mirrored to a tiny JSON file in filesDir at the moment it is
 * written (settings_mirror.json). On every app start missing SharedPreferences
 * keys are restored from that mirror, so the settings survive even when the
 * whole shared_prefs XML disappears. The mirror is a second copy of ~20 small
 * values — the cost of keeping it in sync is negligible.
 */
public class Prefs {
    private final SharedPreferences p;
    private final File mirrorFile;
    private final JSONObject mirror = new JSONObject(); // in-memory copy of the mirror file
    private final Object mirrorLock = new Object();

    public Prefs(Context c) {
        p = c.getSharedPreferences("wtrasie", Context.MODE_PRIVATE);
        mirrorFile = new File(c.getFilesDir(), "settings_mirror.json");
        synchronized (mirrorLock) {
            loadMirror();
            rebuildMirrorFromPrefsIfMissing();
            selfHeal();
        }
    }

    private SharedPreferences.Editor edit() {
        return p.edit();
    }

    // ---------------------------------------------------------------- mirror

    /** Known static setting keys (dynamic type-filter keys carry a filter_ prefix). */
    private static final String[] BOOL_KEYS = {
            "showVehicles", "showStops", "showBrigade", "showFleet", "autoCity",
            "useMyLocation", "filterTechnical", "keepOriginalColors",
            "hideVehicleIcon", "debugOverlay"
    };
    private static final String[] INT_KEYS = {
            "refreshInterval", "vehicleScale", "textScale",
            "dotZoomVehicles", "dotZoomStops", "dotZoomPkp", "mapStyle"
    };
    private static final String[] STRING_KEYS = {"lastCity"};

    /** Read settings_mirror.json into the in-memory copy (missing file = empty). */
    private void loadMirror() {
        try {
            if (!mirrorFile.exists()) return;
            FileInputStream in = new FileInputStream(mirrorFile);
            StringBuilder sb = new StringBuilder();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) sb.append(new String(buf, 0, n, "UTF-8"));
            in.close();
            JSONObject parsed = new JSONObject(sb.toString());
            for (String k : BOOL_KEYS) if (parsed.has(k)) mirror.put(k, parsed.getBoolean(k));
            for (String k : INT_KEYS) if (parsed.has(k)) mirror.put(k, parsed.getInt(k));
            for (String k : STRING_KEYS) if (parsed.has(k)) mirror.put(k, parsed.getString(k));
            // dynamic type filters
            java.util.Iterator<String> it = parsed.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (k != null && k.startsWith("filter_") && !parsed.isNull(k)
                        && !mirror.has(k)) mirror.put(k, parsed.getBoolean(k));
            }
        } catch (Throwable t) {
            android.util.Log.w("Prefs", "mirror load failed", t);
        }
    }

    /**
     * First launch after the mirror file was lost (or a fresh mirror
     * mechanism): fill the mirror from whatever SharedPreferences already
     * hold, so the mirror is always complete from now on.
     */
    private void rebuildMirrorFromPrefsIfMissing() {
        try {
            if (mirrorFile.exists()) return;
            boolean changed = false;
            for (String k : BOOL_KEYS) {
                if (p.contains(k) && !mirror.has(k)) {
                    mirror.put(k, p.getBoolean(k, false));
                    changed = true;
                }
            }
            for (String k : INT_KEYS) {
                if (p.contains(k) && !mirror.has(k)) {
                    mirror.put(k, p.getInt(k, 0));
                    changed = true;
                }
            }
            for (String k : STRING_KEYS) {
                if (p.contains(k) && !mirror.has(k)) {
                    mirror.put(k, p.getString(k, ""));
                    changed = true;
                }
            }
            for (String k : p.getAll().keySet()) {
                if (k != null && k.startsWith("filter_") && !mirror.has(k)) {
                    mirror.put(k, p.getBoolean(k, true));
                    changed = true;
                }
            }
            if (changed) writeMirror();
        } catch (Throwable t) {
            android.util.Log.w("Prefs", "mirror rebuild failed", t);
        }
    }

    /**
     * THE FIX for "all switches back to off": every known key that is present
     * in the mirror but MISSING from SharedPreferences gets restored. This
     * runs on every process start, so a wiped/rolled-back prefs file is
     * healed before the first UI is built.
     */
    private void selfHeal() {
        try {
            SharedPreferences.Editor e = null;
            for (String k : BOOL_KEYS) {
                if (mirror.has(k) && !p.contains(k)) {
                    if (e == null) e = edit();
                    e.putBoolean(k, mirror.getBoolean(k));
                }
            }
            for (String k : INT_KEYS) {
                if (mirror.has(k) && !p.contains(k)) {
                    if (e == null) e = edit();
                    e.putInt(k, mirror.getInt(k));
                }
            }
            for (String k : STRING_KEYS) {
                if (mirror.has(k) && !p.contains(k)) {
                    if (e == null) e = edit();
                    e.putString(k, mirror.getString(k));
                }
            }
            java.util.Iterator<String> it = mirror.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (k != null && k.startsWith("filter_") && !p.contains(k)) {
                    if (e == null) e = edit();
                    e.putBoolean(k, mirror.getBoolean(k));
                }
            }
            if (e != null) e.commit();
        } catch (Throwable t) {
            android.util.Log.w("Prefs", "self heal failed", t);
        }
    }

    /** Synchronously upsert one value into the mirror file. Tiny file, microseconds. */
    private void mirrorPut(String key, Object v) {
        synchronized (mirrorLock) {
            try {
                mirror.put(key, v);
                writeMirror();
            } catch (Throwable t) {
                android.util.Log.w("Prefs", "mirror put failed", t);
            }
        }
    }

    private void writeMirror() {
        try {
            File tmp = new File(mirrorFile.getParentFile(), mirrorFile.getName() + ".tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            out.write(mirror.toString().getBytes("UTF-8"));
            out.flush();
            out.getFD().sync();
            out.close();
            if (!tmp.renameTo(mirrorFile)) {
                FileOutputStream direct = new FileOutputStream(mirrorFile);
                direct.write(mirror.toString().getBytes("UTF-8"));
                direct.close();
            }
        } catch (Throwable t) {
            android.util.Log.w("Prefs", "mirror write failed", t);
        }
    }

    // ---------------------------------------------------------------- setters

    private void putBool(String key, boolean v) {
        edit().putBoolean(key, v).commit();
        mirrorPut(key, v);
    }

    private void putInt(String key, int v) {
        edit().putInt(key, v).commit();
        mirrorPut(key, v);
    }

    private void putString(String key, String v) {
        edit().putString(key, v).commit();
        mirrorPut(key, v);
    }

    // ---------------------------------------------------------------- settings API

    public int refreshInterval() {
        return p.getInt("refreshInterval", 10);
    }

    public void setRefreshInterval(int v) {
        putInt("refreshInterval", v);
    }

    public boolean showVehicles() {
        return p.getBoolean("showVehicles", true);
    }

    public void setShowVehicles(boolean v) {
        putBool("showVehicles", v);
    }

    public boolean showStops() {
        return p.getBoolean("showStops", true);
    }

    public void setShowStops(boolean v) {
        putBool("showStops", v);
    }

    /** 0 = small, 1 = medium, 2 = large */
    public int vehicleScale() {
        return p.getInt("vehicleScale", 1);
    }

    public void setVehicleScale(int v) {
        putInt("vehicleScale", v);
    }

    /** alpha-1.6.2: text size 0=A-, 1=A, 2=A+, 3=A++. */
    public int textScale() {
        return p.getInt("textScale", 1);
    }

    public void setTextScale(int v) {
        putInt("textScale", v);
    }

    public boolean showBrigade() {
        return p.getBoolean("showBrigade", false);
    }

    public void setShowBrigade(boolean v) {
        putBool("showBrigade", v);
    }

    public boolean showFleet() {
        return p.getBoolean("showFleet", false);
    }

    public void setShowFleet(boolean v) {
        putBool("showFleet", v);
    }

    public boolean autoCity() {
        return p.getBoolean("autoCity", true);
    }

    public void setAutoCity(boolean v) {
        putBool("autoCity", v);
    }

    /**
     * alpha-1.6.3: "Używaj mojej lokalizacji" — master switch for everything the
     * app does with the user's location: startup centering on the user, the
     * blue dot marker and background location updates. OFF = the app never
     * touches the location providers (the locate button turns it back on).
     * Defaults ON to keep the behavior of previous versions for users who
     * already granted the permission.
     */
    public boolean useMyLocation() {
        return p.getBoolean("useMyLocation", true);
    }

    public void setUseMyLocation(boolean v) {
        putBool("useMyLocation", v);
    }

    /**
     * "Filtruj przejazdy techniczne" — hide vehicles/departures of technical
     * runs (route names like "PT", "..." etc.). On by default.
     */
    public boolean filterTechnical() {
        return p.getBoolean("filterTechnical", true);
    }

    public void setFilterTechnical(boolean v) {
        putBool("filterTechnical", v);
    }

    /** "Pozostaw oryginalne kolory pojazdów" — off = unified type colors everywhere.
     *  v1.4.1: ON by default, like on the zbiorkom.live website. */
    public boolean keepOriginalColors() {
        return p.getBoolean("keepOriginalColors", true);
    }

    public void setKeepOriginalColors(boolean v) {
        putBool("keepOriginalColors", v);
    }

    /** "Ukryj ikonę pojazdu" — on = only the line number chip, no type glyph.
     *  alpha-1.6.2: OFF by default (the default profile keeps only the
     *  switches from the release notes on). */
    public boolean hideVehicleIcon() {
        return p.getBoolean("hideVehicleIcon", false);
    }

    public void setHideVehicleIcon(boolean v) {
        putBool("hideVehicleIcon", v);
    }

    // ---------------------------------------------------------------- debug overlay

    /** "Nakładka debugu" profile: zoom thresholds shown as sliders in settings. */
    public boolean debugOverlay() {
        return p.getBoolean("debugOverlay", false);
    }

    public void setDebugOverlay(boolean v) {
        putBool("debugOverlay", v);
    }

    /** Vehicles become plain dots below this zoom (stored x10). */
    public int dotZoomVehicles() {
        return p.getInt("dotZoomVehicles", 130);
    }

    public void setDotZoomVehicles(int v) {
        putInt("dotZoomVehicles", v);
    }

    /** Stops are hidden below this zoom (stored x10).
     *  alpha-1.6.2: default 15.0 (was 11.5) — the whole map calms down and
     *  individual stops appear only when you actually zoom in. */
    public int dotZoomStops() {
        return p.getInt("dotZoomStops", 150);
    }

    public void setDotZoomStops(int v) {
        putInt("dotZoomStops", v);
    }

    /** PKP trains become plain dots below this zoom (stored x10). */
    public int dotZoomPkp() {
        return p.getInt("dotZoomPkp", 110);
    }

    public void setDotZoomPkp(int v) {
        putInt("dotZoomPkp", v);
    }

    // ---------------------------------------------------------------- map & city

    /** 0 = basic (vector, OpenFreeMap), 1 = OSM standard, 2 = satellite.
     *  alpha-1.6.2: 3..6 = VARIANTS of the basic vector style (Pastelowy,
     *  Kontrastowy, Ciepły, Chłodny) derived from style_basic.json at runtime. */
    public int mapStyle() {
        if (p.contains("satellite")) { // migrate from 1.1.x
            boolean sat = p.getBoolean("satellite", false);
            int val = sat ? 2 : 0;
            edit().remove("satellite").putInt("mapStyle", val).commit();
            mirrorPut("mapStyle", val);
        }
        return p.getInt("mapStyle", 0);
    }

    public void setMapStyle(int v) {
        putInt("mapStyle", v);
    }

    public String lastCity() {
        // alpha-1.6.0: the real slug is "warsaw" — the old "warszawa" default
        // resolved to null and crashed a fresh install on startup
        String saved = p.getString("lastCity", "warsaw");
        return "warszawa".equals(saved) ? "warsaw" : saved;
    }

    public void setLastCity(String slug) {
        putString("lastCity", slug);
    }

    public double lastLat() {
        return Double.longBitsToDouble(p.getLong("lastLat", Double.doubleToRawLongBits(52.2297)));
    }

    public double lastLon() {
        return Double.longBitsToDouble(p.getLong("lastLon", Double.doubleToRawLongBits(21.0122)));
    }

    public double lastZoom() {
        return p.getFloat("lastZoom", 11.5f);
    }

    public void setCamera(double lat, double lon, double zoom) {
        edit().putLong("lastLat", Double.doubleToRawLongBits(lat))
                .putLong("lastLon", Double.doubleToRawLongBits(lon))
                .putFloat("lastZoom", (float) zoom)
                .commit();
    }

    public boolean typeFilter(int gtfsType) {
        return p.getBoolean("filter_" + filterKey(gtfsType), true);
    }

    public void setTypeFilter(int gtfsType, boolean on) {
        putBool("filter_" + filterKey(gtfsType), on);
    }

    public static int filterKey(int gtfsType) {
        switch (gtfsType) {
            case 0: return 0;   // tram
            case 1: return 1;   // subway
            case 2: return 2;   // rail
            case 3: return 3;   // bus
            case 4: return 4;   // ferry
            case 11: return 11; // trolleybus
            default: return 99; // gondola / funicular / monorail / other
        }
    }

    /** v1.4.0: every city starts with all vehicle types visible. */
    public void resetTypeFilters() {
        SharedPreferences.Editor e = edit();
        for (String key : p.getAll().keySet()) {
            if (key != null && key.startsWith("filter_")) e.putBoolean(key, true);
        }
        e.commit();
        for (String key : p.getAll().keySet()) {
            if (key != null && key.startsWith("filter_")) mirrorPut(key, true);
        }
    }
}
