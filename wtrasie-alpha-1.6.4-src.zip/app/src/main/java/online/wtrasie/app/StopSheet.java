package online.wtrasie.app;

import android.app.DatePickerDialog;
import android.text.SpannableString;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Stop board with two modes:
 *  - Odjazdy: live departures — under the headsign the delay / "Planowo" /
 *    planned time, on the right a countdown (">60 min" shows the clock time,
 *    "&lt;1 min" blinks red). Route chips filter lines; tapping a departure
 *    opens the vehicle preview when that bus is running.
 *  - Rozkłady: alpha-1.6.1, rebuilt once more per the spec: LINE TILES first,
 *    then a day menu (day-type chips scrolling with a fade + a PINNED
 *    calendar icon), then a course list that looks exactly like the
 *    departures list — line + direction on the left, the hour on the right.
 */
public class StopSheet extends Sheet {

    private static final int MODE_DEPARTURES = 0, MODE_TIMETABLE = 1;

    private final MainActivity act;
    private final FrameLayout iconWrap;
    private final ImageView iconImg;
    private final TextView name, sub;
    private final ImageButton btnFav, btnClose, btnCenter;
    private final LinearLayout chipsRow;
    private final HorizontalScrollView chipsScroll;
    private final TextView noRoutesNote;
    private final View btnRozklady;
    private final ImageView rozkladyIcon;
    private final TextView rozkladyLabel;
    private final ListView list;
    private final ScrollView timetableScroll;
    private final LinearLayout timetableBox;
    private final DepartureAdapter adapter;

    private Models.Stop stop;
    private Cities.City city;
    private int mode = MODE_DEPARTURES;
    private final List<Models.Departure> departures = new ArrayList<>();
    private final List<Models.Departure> filtered = new ArrayList<>();
    private final Set<String> selectedRoutes = new HashSet<>();
    private boolean loaded = false;
    private boolean triedOwnCity = false;
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());
    private int fetchGen = 0;
    private int ttGen = 0;

    // ---- timetable state (alpha-1.6.1, rebuilt from scratch) ----
    private Gtfs.StopTt ttData = null;    // merged across agencies (cached per stop)
    private String ttLine = null;         // selected route short name (null = tiles view)
    private String ttChipKey = null;      // selected day-type chip bucket
    private String ttDate = null;         // concrete date ("yyyyMMdd") from the calendar
    private List<DayChip> ttChips = new ArrayList<>();

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            if (getState() == HIDDEN) return;
            if (mode == MODE_DEPARTURES) fetchDepartures();
            refreshHandler.postDelayed(this, 15000);
        }
    };

    /** Light tick: recompute countdowns without a network round-trip. */
    private final Runnable countTick = new Runnable() {
        @Override
        public void run() {
            if (getState() == HIDDEN || mode != MODE_DEPARTURES) return;
            adapter.notifyDataSetChanged();
            refreshHandler.postDelayed(this, 8000);
        }
    };

    public StopSheet(MainActivity act) {
        super(act, R.layout.sheet_stop);
        this.act = act;

        iconWrap = findViewById(R.id.stopIcon);
        iconImg = findViewById(R.id.stopIconImg);
        name = findViewById(R.id.stopName);
        sub = findViewById(R.id.stopSub);
        btnFav = findViewById(R.id.btnFav);
        btnClose = findViewById(R.id.btnCloseStop);
        btnCenter = findViewById(R.id.btnCenter);
        chipsRow = findViewById(R.id.routeChipsRow);
        chipsScroll = findViewById(R.id.routeChips);
        noRoutesNote = findViewById(R.id.noRoutesNote);
        btnRozklady = findViewById(R.id.btnRozklady);
        rozkladyIcon = findViewById(R.id.rozkladyIcon);
        rozkladyLabel = findViewById(R.id.rozkladyLabel);
        list = findViewById(R.id.departuresList);
        timetableScroll = findViewById(R.id.timetableScroll);
        timetableBox = findViewById(R.id.timetableBox);
        adapter = new DepartureAdapter();
        list.setAdapter(adapter);

        setDragHandle(findViewById(R.id.stopHeader));
        // lists must end at the visible bottom in every sheet state (v1.4.0)
        setScrollableContent(list, timetableScroll);
        // fading edge on the line-chip bar: a visible hint that more chips
        // are waiting off-screen (v1.4.0)
        chipsScroll.setHorizontalFadingEdgeEnabled(true);
        chipsScroll.setFadingEdgeLength(Ui.dp(act, 26));
        chipsScroll.setHorizontalScrollBarEnabled(false);

        btnClose.setOnClickListener(v -> hide());
        btnCenter.setOnClickListener(v -> {
            try {
                if (stop == null) return;
                double lat = stop.lat, lon = stop.lon;
                if (lat == 0 && lon == 0) { // never focus into Null Island
                    lat = city != null ? city.lat : (act.currentCity != null ? act.currentCity.lat : 52.23);
                    lon = city != null ? city.lon : (act.currentCity != null ? act.currentCity.lon : 21.01);
                }
                act.centerOn(lat, lon, 16.0);
            } catch (Throwable ignored) {
            }
        });
        btnFav.setOnClickListener(v -> {
            try {
                if (stop == null) return;
                act.favorites.toggle(new Favorites.Entry(
                        stop.city, stop.id, stop.name, stop.code, stop.primaryType(),
                        stop.lat, stop.lon));
                updateFavState();
            } catch (Throwable ignored) {
            }
        });
        btnRozklady.setOnClickListener(v -> toggleMode());

        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos < 0 || pos >= filtered.size()) return;
            Models.Departure d = filtered.get(pos);
            act.openVehicleForDeparture(d, stop);
        });
    }

    public Models.Stop getCurrentStop() {
        return stop;
    }

    /** The feed city this stop's departures are actually queried in. */
    public Cities.City getFeedCity() {
        return city;
    }

    public void open(Cities.City city, Models.Stop s) {
        this.city = city;
        this.stop = s;
        selectedRoutes.clear();
        ttGen++;            // invalidate any pending timetable callbacks
        ttLine = null;
        ttChipKey = null;
        ttDate = null;
        ttData = null;
        ttChips = new ArrayList<>();
        setMode(MODE_DEPARTURES);

        int type = s.primaryType();
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Models.stopColor(type));
        iconWrap.setBackground(bg);
        iconImg.setImageResource(s.isStation() ? R.drawable.ic_station : Models.stopIcon(type));
        // v1.4.0: the number is part of the title ("Pl. Wolności 04"), and the
        // sub line stays empty — no adjacent-stop names, no direction stuffing
        name.setText(Ui.stopTitle(s.name, s.code));
        Ui.scaleText(name); // alpha-1.6.2: the A- / A / A+ / A++ text size
        sub.setText("");
        Ui.setVisible(sub, false);
        updateFavState();

        departures.clear();
        filtered.clear();
        loaded = false;
        triedOwnCity = false;
        adapter.notifyDataSetChanged();
        buildChips();

        show();
        fetchDepartures();
        refreshHandler.removeCallbacks(refreshRunnable);
        refreshHandler.removeCallbacks(countTick);
        refreshHandler.postDelayed(refreshRunnable, 15000);
        refreshHandler.postDelayed(countTick, 8000);

        act.favorites.pushRecent(new Favorites.Entry(
                s.city, s.id, s.name, s.code, s.primaryType(), s.lat, s.lon));
    }

    @Override
    public void hide() {
        super.hide();
        refreshHandler.removeCallbacks(refreshRunnable);
        refreshHandler.removeCallbacks(countTick);
    }

    private void updateFavState() {
        boolean fav = stop != null && act.favorites.isFavorite(stop.id);
        btnFav.setImageResource(fav ? R.drawable.star : R.drawable.staroutline);
        btnFav.setColorFilter(fav ? 0xFFF9AB00 : 0xFF1C1B1F);
    }

    // ------------------------------------------------------------ modes

    private void setMode(int m) {
        mode = m;
        if (m == MODE_DEPARTURES) {
            list.setVisibility(VISIBLE);
            timetableScroll.setVisibility(GONE);
            rozkladyLabel.setText(R.string.rozkady);
            rozkladyIcon.setImageResource(R.drawable.ic_calendar);
            rozkladyIcon.setColorFilter(0xFF1C1B1F);
            rozkladyLabel.setTextColor(0xFF1C1B1F);
        } else {
            list.setVisibility(GONE);
            timetableScroll.setVisibility(VISIBLE);
            rozkladyLabel.setText(R.string.odjazdy);
            rozkladyIcon.setImageResource(R.drawable.flash);
            rozkladyIcon.setColorFilter(0xFF0B57D0);
            rozkladyLabel.setTextColor(0xFF0B57D0);
        }
    }

    private void toggleMode() {
        if (mode == MODE_DEPARTURES) {
            setMode(MODE_TIMETABLE);
            loadTimetable();
        } else {
            setMode(MODE_DEPARTURES);
        }
    }

    // ------------------------------------------------------------ chips

    private void buildChips() {
        chipsRow.removeAllViews();
        if (stop == null || stop.routes == null || stop.routes.length == 0) {
            Ui.setVisible(chipsScroll, false);
            Ui.setVisible(noRoutesNote, true);
            return;
        }
        Ui.setVisible(chipsScroll, true);
        Ui.setVisible(noRoutesNote, false);
        boolean filterTechnical = act.prefs.filterTechnical();
        int shown = 0;
        for (final Models.Route r : stop.routes) {
            if (Models.hiddenByTechnicalFilter(r.name, filterTechnical)) continue;
            TextView chip = (TextView) LayoutInflater.from(act)
                    .inflate(R.layout.chip_route, chipsRow, false);
            Ui.setPill(chip, r.name, r.color);
            chip.setTag(r.id);
            chip.setOnClickListener(v -> {
                if (selectedRoutes.contains(r.id)) selectedRoutes.remove(r.id);
                else selectedRoutes.add(r.id);
                applyFilter();
                restyleChips();
            });
            chipsRow.addView(chip);
            shown++;
        }
        if (shown == 0) {
            Ui.setVisible(chipsScroll, false);
            Ui.setVisible(noRoutesNote, true);
            return;
        }
        restyleChips();
    }

    private void restyleChips() {
        for (int i = 0; i < chipsRow.getChildCount(); i++) {
            View c = chipsRow.getChildAt(i);
            Object tag = c.getTag();
            boolean sel = tag != null && selectedRoutes.contains((String) tag);
            c.setAlpha(sel ? 1f : 0.45f);
        }
    }

    private void applyFilter() {
        filtered.clear();
        boolean filterTechnical = act.prefs.filterTechnical();
        for (Models.Departure d : departures) {
            if (Models.hiddenByTechnicalFilter(d.route.name, filterTechnical)) continue;
            if (selectedRoutes.isEmpty() || selectedRoutes.contains(d.route.id)) {
                filtered.add(d);
            }
        }
        adapter.notifyDataSetChanged();
    }

    // ------------------------------------------------------------ live departures

    private void fetchDepartures() {
        if (stop == null || city == null) return;
        final int gen = ++fetchGen;
        Api.getJson(Api.departuresUrl(city.slug, stop.id, 60), (json, err) -> {
            if (gen != fetchGen || getState() == HIDDEN || mode != MODE_DEPARTURES) return;
            if (json == null) {
                // v1.4.0: never spin forever — fall back to the stop's own city
                // once (a pkp stop opened from a city tab), then stop loading
                if (!triedOwnCity && stop.city != null && !stop.city.isEmpty()
                        && !stop.city.equals(city.slug)) {
                    Cities.City own = Cities.bySlug(stop.city);
                    if (own != null) {
                        triedOwnCity = true;
                        this.city = own;
                        fetchDepartures();
                        return;
                    }
                }
                loaded = true;
                applyFilter();
                return;
            }
            List<Models.Departure> fresh = Models.Departure.parseList(json);
            if (fresh.isEmpty() && !triedOwnCity
                    && stop.city != null && !stop.city.isEmpty() && !stop.city.equals(city.slug)) {
                Cities.City own = Cities.bySlug(stop.city);
                if (own != null) {
                    triedOwnCity = true;
                    this.city = own;
                    fetchDepartures();
                    return;
                }
            }
            departures.clear();
            departures.addAll(fresh);
            loaded = true;
            applyFilter();
        });
    }

    private class DepartureAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (filtered.isEmpty()) return 1; // loading / empty state
            return filtered.size();
        }

        @Override
        public Object getItem(int pos) {
            return pos;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public int getItemViewType(int pos) {
            return filtered.isEmpty() ? (loaded ? 1 : 2) : 0;
        }

        @Override
        public int getViewTypeCount() {
            return 3;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup parent) {
            if (filtered.isEmpty()) {
                if (!loaded) {
                    // v1.4.0: animated loading state instead of a static icon
                    View v = cv;
                    if (v == null || v.getId() != R.id.loadingRow) {
                        v = LayoutInflater.from(act).inflate(R.layout.row_loading, parent, false);
                        Ui.scaleTextTree(v); // alpha-1.6.3: A- / A / A+ / A++
                    }
                    return v;
                }
                View v = cv;
                if (v == null || v.getId() != R.id.emptyText) {
                    v = LayoutInflater.from(act).inflate(R.layout.empty_state, parent, false);
                    Ui.scaleTextTree(v); // alpha-1.6.3: A- / A / A+ / A++
                }
                ImageView iv = v.findViewById(R.id.emptyIcon);
                TextView tv = v.findViewById(R.id.emptyText);
                iv.setImageResource(R.drawable.timersand);
                tv.setText(R.string.no_results);
                return v;
            }
            View v = cv;
            if (v == null || v.getId() == R.id.emptyText || v.findViewById(R.id.depRoute) == null) {
                v = LayoutInflater.from(act).inflate(R.layout.row_departure, parent, false);
            }
            Models.Departure d = filtered.get(pos);
            long now = System.currentTimeMillis();
            Ui.scaleTextTree(v); // alpha-1.6.2: the A- / A / A+ / A++ text size

            TextView route = v.findViewById(R.id.depRoute);
            Ui.setPill(route, d.route.name.isEmpty() ? "?" : d.route.name, d.route.color);

            TextView head = v.findViewById(R.id.depHeadsign);
            head.setText(d.headsign != null ? d.headsign : "");
            Ui.strike(head, d.cancelled);

            // sub line: delay / Planowo / planned time
            TextView depSub = v.findViewById(R.id.depSub);
            if (d.cancelled) {
                depSub.setText(R.string.cancelled_short);
                depSub.setTextColor(0xFFB3261E);
            } else if (d.delay != null && d.realtime) {
                String dt = Ui.fmtDelay(d.delay);
                if (dt.isEmpty()) {
                    depSub.setText(R.string.planowo);
                    depSub.setTextColor(0xFF146C2E);
                } else {
                    depSub.setText(dt);
                    depSub.setTextColor(Ui.delayColor(d.delay));
                }
            } else if (d.delay != null) { // not realtime yet but delay predicted
                String dt = Ui.fmtDelay(d.delay);
                depSub.setText(dt.isEmpty() ? Ui.fmtTime(d.scheduledDeparture) : dt);
                depSub.setTextColor(dt.isEmpty() ? 0xFF5F5F66 : Ui.delayColor(d.delay));
            } else {
                depSub.setText(Ui.fmtTime(d.scheduledDeparture));
                depSub.setTextColor(0xFF5F5F66);
            }

            // right column: countdown only
            TextView count = v.findViewById(R.id.depCount);
            stopBlink(count);
            long est = d.scheduledDeparture + (d.delay == null ? 0 : d.delay);
            if (d.cancelled) {
                count.setText("—");
                count.setTextColor(0xFFB3261E);
            } else if (!d.realtime) {
                // v1.4.0: the run has not started — no "in X min", just the clock time
                count.setText(Ui.fmtTime(d.scheduledDeparture));
                count.setTextColor(0xFF5F5F66);
            } else {
                String ct = Ui.fmtCountdown(est, now);
                if (ct == null) {
                    count.setText(Ui.fmtTime(est));
                    count.setTextColor(0xFF1C1B1F);
                } else if (Ui.isBlinkCountdown(ct)) {
                    count.setText(ct);
                    startBlink(count);
                } else {
                    count.setText(ct);
                    count.setTextColor(0xFF1C1B1F);
                }
            }
            return v;
        }
    }

    // ------------------------------------------------------------ blinking

    private static void stopBlink(TextView tv) {
        Object tag = tv.getTag();
        if (tag instanceof ObjectAnimator) {
            ((ObjectAnimator) tag).cancel();
            tv.setTag(null);
            tv.setAlpha(1f);
        }
    }

    private static void startBlink(TextView tv) {
        ObjectAnimator a = ObjectAnimator.ofFloat(tv, "alpha", 1f, 0.25f);
        a.setDuration(420);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.setInterpolator(new LinearInterpolator());
        tv.setTag(a);
        a.start();
    }

    // ------------------------------------------------------------ timetables (alpha-1.6.1 — rebuilt from scratch)

    private static String todayYmd() {
        Calendar c = Calendar.getInstance();
        return String.format(Locale.US, "%04d%02d%02d",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    /** "sobota, 16 listopada" — the shown day, in Polish. */
    private static String prettyDate(String yyyymmdd) {
        try {
            GregorianCalendar c = new GregorianCalendar();
            c.clear();
            c.set(Integer.parseInt(yyyymmdd.substring(0, 4)),
                    Integer.parseInt(yyyymmdd.substring(4, 6)) - 1,
                    Integer.parseInt(yyyymmdd.substring(6, 8)), 12, 0, 0);
            SimpleDateFormat f = new SimpleDateFormat("EEEE, d MMMM", new Locale("pl", "PL"));
            String s = f.format(new Date(c.getTimeInMillis()));
            return s.substring(0, 1).toUpperCase(new Locale("pl", "PL")) + s.substring(1);
        } catch (Exception e) {
            return yyyymmdd;
        }
    }

    /** One day-type chip: a bucket of services running on the same days. */
    private static class DayChip {
        String key;          // bucket key: type|start|end
        int type;            // Gtfs.Svc.dayType()
        String label = "";   // display label (a variant carries its date range)
        boolean coversToday; // any of the services runs today
        final Set<String> services = new HashSet<>();
    }

    /** GTFS day-type number -> Polish label. */
    private String dayTypeLabel(int type) {
        switch (type) {
            case 0:
                return act.getString(R.string.timetable_weekday);
            case 1:
                return act.getString(R.string.timetable_saturday);
            case 2:
                return act.getString(R.string.timetable_sunday);
            case 3:
                return act.getString(R.string.timetable_everyday);
            case 4:
                return act.getString(R.string.timetable_mon_sat);
            default:
                return act.getString(R.string.timetable_variant);
        }
    }

    /**
     * Calendar of a service id. A service missing from calendar.txt AND
     * calendar_dates.txt is treated as running daily — its times must still
     * show up somewhere instead of disappearing.
     */
    private Gtfs.Svc svcOf(String serviceId) {
        if (ttData != null) {
            Gtfs.Svc s = ttData.services.get(serviceId);
            if (s != null) return s;
        }
        if (alwaysOn == null) {
            alwaysOn = new Gtfs.Svc();
            java.util.Arrays.fill(alwaysOn.days, true);
        }
        return alwaysOn;
    }

    private Gtfs.Svc alwaysOn;

    private void loadTimetable() {
        if (stop == null || city == null) return;
        if (ttData != null) { // cached for this stop — switching days is instant
            buildTimetableUi();
            return;
        }
        final int gen = ++ttGen;
        timetableBox.removeAllViews();
        timetableBox.addView(loadingRow());

        // one GTFS per agency serving this stop — fetched in parallel
        Set<String> agencies = new LinkedHashSet<>();
        if (stop.routes != null) {
            for (Models.Route r : stop.routes) {
                if (r.agency != null && !r.agency.isEmpty()) agencies.add(r.agency);
            }
        }
        if (agencies.isEmpty()) agencies.add("default");

        final Gtfs.StopTt merged = new Gtfs.StopTt();
        final int[] pending = {agencies.size()};
        for (final String agency : agencies) {
            Gtfs.loadStopTimetable(act, city.slug, agency, stop.id, (data, err) -> {
                if (gen != ttGen) return;
                if (data != null) {
                    for (Map.Entry<String, Gtfs.RouteTt> e : data.routes.entrySet()) {
                        if (!merged.routes.containsKey(e.getKey())) merged.routes.put(e.getKey(), e.getValue());
                    }
                    merged.services.putAll(data.services);
                }
                pending[0]--;
                if (pending[0] == 0) {
                    ttData = merged.routes.isEmpty() ? null : merged;
                    buildTimetableUi();
                }
            });
        }
    }

    private View loadingRow() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        box.setPadding(Ui.dp(act, 18), Ui.dp(act, 16), Ui.dp(act, 18), Ui.dp(act, 16));
        android.widget.ProgressBar bar = new android.widget.ProgressBar(act);
        bar.setIndeterminate(true);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                Ui.dp(act, 22), Ui.dp(act, 22));
        box.addView(bar, blp);
        TextView tv = new TextView(act);
        tv.setText(R.string.loading);
        tv.setTextColor(0xFF5F5F66);
        tv.setTextSize(14);
        Ui.scaleText(tv);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.leftMargin = Ui.dp(act, 12);
        box.addView(tv, tlp);
        return box;
    }

    /**
     * The timetable, per the alpha-1.6.1 spec:
     *  1. LINE TILES of everything that departs from this stop;
     *  2. tapping a tile opens the day menu — day-type chips that scroll with
     *     a fade (dni robocze / soboty / niedziele / variants) with a PINNED
     *     calendar icon at the end of the row;
     *  3. a picked date highlights the matching day-type chip and the calendar
     *     icon itself;
     *  4. the list looks EXACTLY like the nearest-departures list: line +
     *     direction on the left, the hour on the right — nothing else.
     */
    private void buildTimetableUi() {
        timetableBox.removeAllViews();
        if (stop == null) return;
        if (ttData == null) {
            // the fetch finished and nothing came back (while it runs,
            // loadTimetable itself shows the spinner — no retry loop here)
            timetableBox.addView(plainNote(R.string.no_results, 0xFF5F5F66));
            return;
        }

        boolean filterTechnical = act.prefs.filterTechnical();
        List<Models.Route> tiles = new ArrayList<>();
        if (stop.routes != null) {
            for (Models.Route r : stop.routes) {
                if (r.name == null || r.name.isEmpty()) continue;
                if (Models.hiddenByTechnicalFilter(r.name, filterTechnical)) continue;
                tiles.add(r);
            }
        }
        if (tiles.isEmpty()) {
            // a stop without the API route list: tiles straight from the GTFS
            Map<String, Gtfs.RouteTt> seen = new LinkedHashMap<>();
            for (Gtfs.RouteTt rt : ttData.routes.values()) {
                if (Models.hiddenByTechnicalFilter(rt.routeName, filterTechnical)) continue;
                if (!seen.containsKey(rt.routeName)) seen.put(rt.routeName, rt);
            }
            for (Gtfs.RouteTt rt : seen.values()) {
                Models.Route r = new Models.Route();
                r.id = rt.routeId;
                r.name = rt.routeName;
                r.color = rt.routeColor;
                tiles.add(r);
            }
        }
        tiles.sort((a, b) -> compareRouteNames(a.name, b.name));

        if (tiles.isEmpty()) {
            timetableBox.addView(plainNote(R.string.no_results, 0xFF5F5F66));
            return;
        }

        timetableBox.addView(tilesRow(tiles));

        if (ttLine == null) return; // tiles-only view — the day menu appears after a tap

        List<Gtfs.RouteTt> matched = matchedRoutes(ttLine);
        if (matched.isEmpty()) {
            timetableBox.addView(plainNote(R.string.timetable_no_service, 0xFF9AA0A6));
            return;
        }
        ttChips = buildChips(matched);
        if (ttChipKey == null && ttDate == null) {
            // default: the day type that actually runs today, else the first
            for (DayChip c : ttChips) {
                if (c.coversToday) {
                    ttChipKey = c.key;
                    break;
                }
            }
            if (ttChipKey == null && !ttChips.isEmpty()) ttChipKey = ttChips.get(0).key;
        }
        if (!ttChips.isEmpty()) timetableBox.addView(dayRow());

        List<Object[]> rows = timetableRows(matched);
        timetableBox.addView(infoLine(rows.size()));
        timetableBox.addView(courseRows(rows));
    }

    private View plainNote(int textRes, int color) {
        TextView tv = new TextView(act);
        tv.setText(textRes);
        tv.setTextColor(color);
        tv.setTextSize(14);
        Ui.scaleText(tv);
        tv.setPadding(Ui.dp(act, 18), Ui.dp(act, 18), Ui.dp(act, 18), Ui.dp(act, 18));
        return tv;
    }

    /**
     * The line tiles ("kafelki") — tap selects, tapping the selected tile goes
     * back. alpha-1.6.2: the tiles are inflated from the SAME chip_route
     * layout as the line chips at the top of the sheet and the route pills in
     * the nearest-departures list — identical look everywhere (the old hand
     * made tiles had visibly cut backgrounds), and the row keeps a tight
     * padding so no gap opens between it and the day menu.
     */
    private View tilesRow(List<Models.Route> tiles) {
        FlowLayout flow = new FlowLayout(act);
        flow.setPadding(Ui.dp(act, 12), Ui.dp(act, 6), Ui.dp(act, 12), Ui.dp(act, 2));
        for (final Models.Route r : tiles) {
            TextView tile = (TextView) LayoutInflater.from(act)
                    .inflate(R.layout.chip_route, flow, false);
            Ui.setPill(tile, r.name, r.color);
            Ui.scaleText(tile);
            tile.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            tile.setMinimumHeight(Ui.dp(act, 30));
            tile.setGravity(Gravity.CENTER_VERTICAL);
            boolean sel = r.name != null && r.name.equals(ttLine);
            tile.setAlpha(sel ? 1f : 0.62f);
            tile.setOnClickListener(v -> {
                if (ttLine != null && ttLine.equals(r.name)) {
                    ttLine = null; // back to the tiles view
                } else {
                    ttLine = r.name;
                }
                ttChipKey = null;
                ttDate = null;
                buildTimetableUi();
            });
            flow.addView(tile, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return flow;
    }

    /**
     * The day menu: a scrolling strip of day-type chips with a fading edge
     * (like the line chips bar) + the calendar button PINNED at the end of the
     * row — it never scrolls away. alpha-1.6.2: sits directly under the tiles
     * (2 dp) — the huge blank gap is gone.
     */
    private View dayRow() {
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(act, 14), Ui.dp(act, 2), Ui.dp(act, 10), Ui.dp(act, 2));

        TextView label = new TextView(act);
        label.setText(R.string.timetable_day);
        label.setTextColor(0xFF5F5F66);
        label.setTextSize(12f);
        label.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        label.setAllCaps(true);
        label.setLetterSpacing(0.04f);
        Ui.scaleText(label);
        row.addView(label);

        HorizontalScrollView chipsScroll = new HorizontalScrollView(act);
        chipsScroll.setHorizontalScrollBarEnabled(false);
        chipsScroll.setHorizontalFadingEdgeEnabled(true);
        chipsScroll.setFadingEdgeLength(Ui.dp(act, 26));
        LinearLayout chipsBox = new LinearLayout(act);
        chipsBox.setOrientation(LinearLayout.HORIZONTAL);
        chipsScroll.addView(chipsBox, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        for (final DayChip chip : ttChips) {
            TextView pill = new TextView(act);
            pill.setText(chip.label);
            pill.setTextSize(13f);
            Ui.scaleText(pill);
            // a picked date highlights the chip of the day type that runs then
            boolean selected = chip.key.equals(ttChipKey)
                    || (ttDate != null && chipActiveOn(chip, ttDate));
            styleDayPill(pill, selected);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(act, 32));
            lp.leftMargin = Ui.dp(act, 8);
            pill.setLayoutParams(lp);
            pill.setOnClickListener(v -> {
                ttChipKey = chip.key;
                ttDate = null; // chip mode — the calendar icon dims again
                buildTimetableUi();
            });
            chipsBox.addView(pill);
        }
        LinearLayout.LayoutParams sc = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        sc.leftMargin = Ui.dp(act, 8);
        row.addView(chipsScroll, sc);

        // calendar: ICON ONLY, pinned at the end of the row
        ImageButton cal = new ImageButton(act);
        cal.setImageResource(R.drawable.ic_calendar);
        cal.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        cal.setPadding(Ui.dp(act, 7), Ui.dp(act, 7), Ui.dp(act, 7), Ui.dp(act, 7));
        cal.setBackground(ttDate != null
                ? act.getResources().getDrawable(R.drawable.bg_tab_active) : null);
        cal.setColorFilter(ttDate != null ? 0xFF0B57D0 : 0xFF5F5F66);
        cal.setOnClickListener(v -> pickDate());
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(Ui.dp(act, 38), Ui.dp(act, 38));
        clp.leftMargin = Ui.dp(act, 4);
        row.addView(cal, clp);
        return row;
    }

    /** Pill styling: selected = accent text + light accent background. */
    private void styleDayPill(View pill, boolean selected) {
        pill.setBackground(selected ? act.getResources().getDrawable(R.drawable.bg_tab_active) : null);
        pill.setPadding(Ui.dp(act, 12), 0, Ui.dp(act, 12), 0);
        pill.setMinimumHeight(Ui.dp(act, 32));
        if (pill instanceof TextView) {
            ((TextView) pill).setTextColor(selected ? 0xFF0B57D0 : 0xFF5F5F66);
            ((TextView) pill).setGravity(Gravity.CENTER_VERTICAL);
        } else {
            pill.setMinimumWidth(0);
        }
    }

    /** True when any service of the chip runs on the given date. */
    private boolean chipActiveOn(DayChip chip, String ymd) {
        for (String s : chip.services) {
            if (svcOf(s).activeOn(ymd)) return true;
        }
        return false;
    }

    /**
     * Day-type chips of the selected line: services bucketed by their weekly
     * pattern AND date range — a normal weekday service and a school-free
     * weekday service are two different variants; the variant chip carries
     * its date range as a suffix ("Dni robocze · 27.06–31.08").
     */
    private List<DayChip> buildChips(List<Gtfs.RouteTt> matched) {
        Map<String, DayChip> buckets = new LinkedHashMap<>();
        for (Gtfs.RouteTt rt : matched) {
            for (Gtfs.Tt t : rt.times) {
                Gtfs.Svc svc = svcOf(t.serviceId);
                int type = svc.dayType();
                if (type < 0) type = 5; // no weekday info — an "other" variant
                String key = type + "|" + svc.start + "|" + svc.end;
                DayChip chip = buckets.get(key);
                if (chip == null) {
                    chip = new DayChip();
                    chip.key = key;
                    chip.type = type;
                    buckets.put(key, chip);
                }
                chip.services.add(t.serviceId);
            }
        }
        List<DayChip> chips = new ArrayList<>(buckets.values());
        String today = todayYmd();
        for (DayChip c : chips) c.coversToday = chipActiveOn(c, today);
        // order: chips running today first, then by day type, then by range
        chips.sort((a, b) -> {
            if (a.coversToday != b.coversToday) return a.coversToday ? -1 : 1;
            if (a.type != b.type) return Integer.compare(a.type, b.type);
            return a.key.compareTo(b.key);
        });
        // labels: the first chip of a type stays plain; variants and
        // not-currently-running chips get their date range
        Map<Integer, Integer> typeIndex = new HashMap<>();
        for (DayChip c : chips) {
            int idx = typeIndex.containsKey(c.type) ? typeIndex.get(c.type) : 0;
            typeIndex.put(c.type, idx + 1);
            String label = dayTypeLabel(c.type);
            String range = shortRange(c.key);
            if ((idx > 0 || !c.coversToday) && !range.isEmpty()) label += " · " + range;
            c.label = label;
        }
        return chips;
    }

    /** "27.06–31.08" / "27.06" — the date range of a chip bucket key. */
    private static String shortRange(String bucketKey) {
        try {
            String[] p = bucketKey.split("\\|");
            if (p.length != 3) return "";
            String a = p[1].length() == 8 ? p[1].substring(4, 6) + "." + p[1].substring(6, 8) : "";
            String b = p[2].length() == 8 ? p[2].substring(4, 6) + "." + p[2].substring(6, 8) : "";
            if (a.isEmpty()) return b;
            if (b.isEmpty() || b.equals(a)) return a;
            return a + "–" + b;
        } catch (Exception e) {
            return "";
        }
    }

    /** GTFS routes of the selected line (name first, route id as a fallback). */
    private List<Gtfs.RouteTt> matchedRoutes(String name) {
        List<Gtfs.RouteTt> out = new ArrayList<>();
        if (ttData == null || name == null) return out;
        String n = Ui.norm(name);
        for (Gtfs.RouteTt rt : ttData.routes.values()) {
            if (Ui.norm(rt.routeName).equals(n)) out.add(rt);
        }
        if (out.isEmpty()) {
            for (Gtfs.RouteTt rt : ttData.routes.values()) {
                if (rt.routeId.equals(name)) out.add(rt);
            }
        }
        return out;
    }

    /**
     * Course rows of the current selection: a concrete date resolves services
     * exactly (exceptions included); a day-type chip shows its whole bucket.
     * alpha-1.6.2: exact (time + headsign + line) duplicates are dropped —
     * alternative service variants (school vs vacation) carrying the same
     * clock time used to double-print the run.
     */
    private List<Object[]> timetableRows(List<Gtfs.RouteTt> matched) {
        List<Object[]> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        DayChip selected = null;
        if (ttChipKey != null) {
            for (DayChip c : ttChips) {
                if (c.key.equals(ttChipKey)) {
                    selected = c;
                    break;
                }
            }
        }
        for (Gtfs.RouteTt rt : matched) {
            for (Gtfs.Tt t : rt.times) {
                if (ttDate != null) {
                    if (!svcOf(t.serviceId).activeOn(ttDate)) continue;
                } else if (selected != null) {
                    if (!selected.services.contains(t.serviceId)) continue;
                }
                String hs = t.headsign == null ? "" : t.headsign;
                String dedupeKey = t.timeSec + "|" + hs + "|" + rt.routeName;
                if (!seen.add(dedupeKey)) continue;
                out.add(new Object[]{t.timeSec, hs, rt.routeName, rt.routeColor});
            }
        }
        out.sort((x, y) -> Integer.compare((Integer) x[0], (Integer) y[0]));
        return out;
    }

    /** Thin context line: the chosen day type (or date) + the course count. */
    private View infoLine(int count) {
        TextView info = new TextView(act);
        String when = ttDate != null ? prettyDate(ttDate) : chipLabelOf(ttChipKey);
        info.setText((when == null || when.isEmpty() ? "" : when + "  ·  ")
                + Ui.plPlural(count, "kurs"));
        info.setTextColor(0xFF5F5F66);
        info.setTextSize(12.5f);
        Ui.scaleText(info);
        info.setPadding(Ui.dp(act, 18), Ui.dp(act, 3), Ui.dp(act, 18), Ui.dp(act, 2));
        return info;
    }

    private String chipLabelOf(String key) {
        if (key == null) return "";
        for (DayChip c : ttChips) {
            if (c.key.equals(key)) return c.label;
        }
        return "";
    }

    /**
     * The course list — the same look as the nearest-departures list: the line
     * pill + the direction on the left, the hour on the right. No custom
     * hours, no group headers, nothing else.
     */
    private View courseRows(List<Object[]> rows) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 12));
        if (rows.isEmpty()) {
            TextView none = new TextView(act);
            none.setText(R.string.timetable_no_service);
            none.setTextColor(0xFF9AA0A6);
            none.setTextSize(13.5f);
            none.setPadding(Ui.dp(act, 18), Ui.dp(act, 12), Ui.dp(act, 18), Ui.dp(act, 12));
            box.addView(none);
            return box;
        }
        for (Object[] r : rows) {
            int sec = (Integer) r[0];
            String headsign = (String) r[1];
            String routeName = (String) r[2];
            Integer color = (Integer) r[3];

            LinearLayout row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(act, 14), Ui.dp(act, 7), Ui.dp(act, 14), Ui.dp(act, 7));
            row.setMinimumHeight(Ui.dp(act, 52));

            TextView pill = new TextView(act);
            Ui.setPill(pill, routeName == null || routeName.isEmpty() ? "?" : routeName,
                    color == null ? 0xFFD32F2F : color);
            pill.setTextSize(15f);
            Ui.scaleText(pill);
            pill.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            row.addView(pill, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView dest = new TextView(act);
            String d = headsign == null || headsign.isEmpty()
                    ? act.getString(R.string.timetable_variant_default) : headsign;
            dest.setText(d);
            dest.setTextColor(0xFF3C4043);
            dest.setTextSize(15f);
            Ui.scaleText(dest);
            dest.setSingleLine(true);
            dest.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            dlp.leftMargin = Ui.dp(act, 10);
            dlp.rightMargin = Ui.dp(act, 8);
            row.addView(dest, dlp);

            TextView time = new TextView(act);
            time.setText(Ui.fmtGtfsTime(sec));
            time.setTextColor(0xFF1C1B1F);
            time.setTextSize(15f);
            Ui.scaleText(time);
            time.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            row.addView(time, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            box.addView(row);
        }
        return box;
    }

    /** Custom date via the calendar (DatePicker), defaulting to the shown day. */
    private void pickDate() {
        try {
            int[] ymd = parseYmd(ttDate == null ? todayYmd() : ttDate);
            DatePickerDialog dlg = new DatePickerDialog(act, (picker, y, m, d) -> {
                String chosen = String.format(Locale.US, "%04d%02d%02d", y, m + 1, d);
                if (chosen.equals(ttDate)) return;
                // date mode: the matching day-type chip + the calendar icon
                // highlight themselves; the list resolves services exactly
                ttDate = chosen;
                ttChipKey = null;
                buildTimetableUi();
            }, ymd[0], ymd[1] - 1, ymd[2]);
            dlg.getDatePicker().setMinDate(System.currentTimeMillis() - 1000L * 60 * 60 * 24 * 7); // last week
            dlg.getDatePicker().setMaxDate(System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 60); // +2 months
            dlg.show();
        } catch (Throwable ignored) {
        }
    }

    private static int[] parseYmd(String ymd) {
        try {
            return new int[]{Integer.parseInt(ymd.substring(0, 4)),
                    Integer.parseInt(ymd.substring(4, 6)), Integer.parseInt(ymd.substring(6, 8))};
        } catch (Exception e) {
            Calendar c = Calendar.getInstance();
            return new int[]{c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)};
        }
    }

    private static int compareRouteNames(String a, String b) {
        try {
            return Long.compare(Long.parseLong(a.trim()), Long.parseLong(b.trim()));
        } catch (Exception e) {
            return a.compareToIgnoreCase(b);
        }
    }
}
