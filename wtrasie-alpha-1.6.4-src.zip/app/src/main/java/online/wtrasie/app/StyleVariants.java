package online.wtrasie.app;

import android.content.Context;
import android.graphics.Color;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * alpha-1.6.2: VARIANTS of the basic vector map style. The base
 * style_basic.json (OpenFreeMap "Liberty" derivative) is read from the assets
 * and EVERY color literal in it is pushed through one coherent HSV transform
 * — the variant stays a valid map style (only color values change), works
 * fully offline and needs zero extra downloads.
 *
 * Variants (Prefs.mapStyle() values):
 *   3 = Pastelowy   — desaturated, milky
 *   4 = Kontrastowy — punchier, more contrast between land and lines
 *   5 = Ciepły      — warm hue shift (sepia-ish)
 *   6 = Chłodny     — cool hue shift
 */
public final class StyleVariants {

    private StyleVariants() {
    }

    private static final Pattern HEX6 = Pattern.compile("#([0-9a-fA-F]{6})");
    private static final Pattern HEX3 = Pattern.compile("#([0-9a-fA-F]{3})(?![0-9a-fA-F])");
    private static final Pattern RGB = Pattern.compile("rgb\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*\\)");
    private static final Pattern RGBA = Pattern.compile("rgba\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*([0-9.]+)\\s*\\)");

    /** Variant display names (settings row order). */
    public static final String[] NAMES = {"Podstawowy", "Pastelowy", "Kontrastowy", "Ciepły", "Chłodny"};

    /** MapLibre style indices in the app: 0 basic, 3..6 variants, 1 osm, 2 sat. */
    public static final int[] STYLE_ORDER = {0, 3, 4, 5, 6, 1, 2};

    public static boolean isVariant(int idx) {
        return idx >= 3 && idx <= 6;
    }

    /** The style JSON with every color mapped through the variant, or null. */
    public static String variantJson(Context ctx, int idx) {
        if (!isVariant(idx)) return null;
        try {
            String base = readAsset(ctx, "style_basic.json");
            return remapColors(base, idx);
        } catch (Throwable t) {
            android.util.Log.w("StyleVariants", "variant build failed", t);
            return null;
        }
    }

    private static String readAsset(Context ctx, String name) throws Exception {
        InputStream in = ctx.getAssets().open(name);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        try {
            in.close();
        } catch (Exception ignored) {
        }
        return bo.toString("UTF-8");
    }

    /** One coherent HSV transform of every color literal in the style text. */
    private static String remapColors(String json, int variant) {
        // rgba(...) first (would otherwise be re-matched by the rgb pattern)
        Matcher m = RGBA.matcher(json);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            int c = Color.rgb(Integer.parseInt(m.group(1)),
                    Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3)));
            int out = transform(c, variant);
            float a = Float.parseFloat(m.group(4));
            m.appendReplacement(sb, "rgba(" + Color.red(out) + ", " + Color.green(out)
                    + ", " + Color.blue(out) + ", " + a + ")");
        }
        m.appendTail(sb);
        json = sb.toString();

        m = RGB.matcher(json);
        sb = new StringBuilder();
        while (m.find()) {
            int c = Color.rgb(Integer.parseInt(m.group(1)),
                    Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3)));
            int out = transform(c, variant);
            m.appendReplacement(sb, "rgb(" + Color.red(out) + ", " + Color.green(out)
                    + ", " + Color.blue(out) + ")");
        }
        m.appendTail(sb);
        json = sb.toString();

        m = HEX6.matcher(json);
        sb = new StringBuilder();
        while (m.find()) {
            int out = transform(Color.parseColor("#" + m.group(1)), variant);
            m.appendReplacement(sb, String.format("#%06X", 0xFFFFFF & out));
        }
        m.appendTail(sb);
        json = sb.toString();

        m = HEX3.matcher(json);
        sb = new StringBuilder();
        while (m.find()) {
            String g = m.group(1);
            int c = Color.parseColor("#" + g.charAt(0) + g.charAt(0) + g.charAt(1) + g.charAt(1) + g.charAt(2) + g.charAt(2));
            int out = transform(c, variant);
            m.appendReplacement(sb, String.format("#%06X", 0xFFFFFF & out));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** The variant's coherent color transform (HSV space, hue preserved). */
    private static int transform(int color, int variant) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        float h = hsv[0], s = hsv[1], v = hsv[2];
        switch (variant) {
            case 3: // Pastelowy
                s = s * 0.5f;
                v = v * 0.82f + 0.16f;
                break;
            case 4: // Kontrastowy
                s = Math.min(1f, s * 1.35f + 0.04f);
                if (v < 0.5f) v = v * 0.74f;
                else v = Math.min(1f, 0.5f + (v - 0.5f) * 1.5f);
                break;
            case 5: // Ciepły
                h = (h + 18f) % 360f;
                s = s * 0.85f;
                break;
            case 6: // Chłodny
                h = (h - 18f + 360f) % 360f;
                s = s * 0.9f;
                break;
        }
        hsv[0] = h;
        hsv[1] = Math.max(0f, Math.min(1f, s));
        hsv[2] = Math.max(0f, Math.min(1f, v));
        return Color.HSVToColor(color >>> 24, hsv); // keep the original alpha
    }
}
