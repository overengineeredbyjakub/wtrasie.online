# wtrasie.online

**wtrasie** — natywna aplikacja na Androida do śledzenia transportu publicznego w czasie rzeczywistym.
Pozycje pojazdów, tablice odjazdów, rozkłady jazdy z przystanków, wyszukiwanie i podgląd tras —
wszystko na jednej, lekkiej mapie wektorowej.

Dane pochodzą z otwartego API **zbiorkom.live** (projekt [wtrasie.online](https://wtrasie.online))
oraz **Transitous**; aplikacja nie wymaga żadnego konta i nie zbiera żadnych danych użytkownika.

---

## Funkcje

### Mapa
- Wektorowa mapa MapLibre (kafelki OpenFreeMap/OpenMapTiles) — działa szybko i płynnie
- **7 podkładów do wyboru**: Podstawowy + 4 jego warianty (**Pastelowy, Kontrastowy, Ciepły, Chłodny**
  — generowane lokalnie, bez dodatkowego pobierania), Standard (OSM) oraz Satelita (Esri)
- Pojazdy jako kolorowe plakietki z numerem linii — **w barwach linii z feedu**
  (albo jednolitych kolorach typów — do przełączenia w ustawieniach); po oddaleniu kolorowe kropki
- Przystanki **zawsze jako czytelne kolorowe ikony typów** (autobus, tram, kolej, metro, prom…),
  nigdy czarne kropki; dworce/stacje mają własną ikonę budynku
- **Widoczność znaczników sterowana suwakami**: od którego poziomu zoomu pojawiają się pojazdy,
  przystanki i pociągi (domyślnie 13 / 15 / 11) — rozwijany wiersz „Wyświetlanie znaczników”
  w sekcji „Zaawansowane”
- Obszar, na który patrzysz, pokazuje przystanki **wszystkich przewoźników** — stacje kolejowe z
  zestawu ogólnopolskiego PKP dokładają się na każdą wybraną miejscowość
- 59 polskich miast i sieci + zagraniczne feedy (Helsinki, Tampere, Sztokholm, FlixBus,
  Digitraffic, Islandia, Holandia, Szwajcaria); **miasto przełącza się automatycznie**
  podczas przesuwania mapy
- Animowane, płynne przeskoki pojazdów między kolejnymi pomiarami

### Pojazd
- Podgląd wybranego pojazdu: **trasa kursu na mapie** (kształt + kolejne przystanki),
  timeline z planowanymi i szacowanymi godzinami, opóźnienie („Planowo / +3 min”), brygada,
  numer taborowy, model, link do strony pojazdu
- **Trasa pojazdu ma absolutny priorytet** — ładuje się z rozgrzanego cache (GTFS każdej
  miejscowości dogrzewa się w tle), a gdy pojazd nie ma jeszcze pozycji, otwiera się zaplanowany
  kurs z rozkładu; gdy pojazd wyjedzie, panel sam przełącza się w tryb na żywo
- **Marker podglądanego pojazdu zostaje na mapie** nawet poza bieżącym oknem kamery (bbox
  zapytań jest rozszerzany o podglądany pojazd), a gdy według planu kurs powinien trwać,
  a feed nie podaje pozycji — panel pokazuje „Brak danych o lokalizacji pojazdu”
- Dotknięcie odjazdu na tablicy otwiera dokładnie ten kurs — również ten, który dopiero wyruszy

### Przystanek
- **Tablica odjazdów**: kierunek, godzina, opóźnienie/„Planowo”, odliczanie po prawej
  („&lt;1 min” miga), odwołane kursy przekreślone; chipsy linii filtrują listę
- **Rozkłady jazdy** (przycisk „Rozkłady” z ikoną kalendarza):
  1. **kafelki linii** odjeżdżających z przystanku,
  2. menu dnia — chipsy typów dnia (dni robocze / soboty / niedziele i święta / warianty
     sezonowe z zakresem dat) przewijane z delikatnym fadem + **przypięta ikona kalendarza**
     do wyboru konkretnej daty (podświetla pasujący typ dnia),
  3. lista kursów w stylu tablicy odjazdów: linia + kierunek po lewej, godzina po prawej
- Rozkład rozróżnia warianty świąteczne i wakacyjne — godziny nie dublują się

### Wyszukiwanie
- Przystanki i miejsca (geokoder Transitous) po nazwie — również w innych miastach;
  wynik z ikoną dworca kolejowego otwiera się z właściwego zestawu (poprawna dezambigualizacja typu)
- Ulubione przystanki, ostatnio otwierane i najbliższe (z lokalizacji)

### Ustawienia
- Częstotliwość odświeżania: 5 / 10 / 15 / 30 s (domyślnie **10 s**)
- **Rozmiar ikon: S / M / L** — realnie skaluje znaczniki na mapie
- **Rozmiar tekstu: A- / A / A+ / A++** — skala tekstu w całej aplikacji, także w polu
  wyszukiwania i na pasku na górze
- **Używaj mojej lokalizacji: wł/wył** — wł.: start wycentrowany na użytkowniku + niebieska
  ikona na mapie; wył.: aplikacja nie korzysta z lokalizacji (przycisk lokalizacji włącza ją z powrotem)
- Podkład mapy: 7 stylów (zob. wyżej)
- Filtr przejazdów technicznych (linie „PT”, „…”), automatyczna zmiana miasta — domyślnie włączone
- Sekcja „Zaawansowane”: rozwijany wiersz „Wyświetlanie znaczników” (suwaki progów zoomu),
  brygada / numer taborowy przy pojeździe, ukrycie ikony typu na plakietce,
  oryginalne kolory pojazdów
- Wyczyść pamięć podręczną; informacje o aplikacji
- Ustawienia zapisują się **trwale na dysku** (synchroniczny zapis — przetrwają zabicie procesu)

---

## Dane

- API: `api.zbiorkom.live` (tablice, pozycje, GTFS, GTFS-RT protobuf) + `api.transitous.org` (geokoder)
- Pełne rozkłady z paczek GTFS (24-godzinny cache na dysku, priorytetowa kolejka przetwarzania,
  automatyczne ponawianie pobierania przy słabej sieci)
- Aplikacja jest offline-friendly: mapa, ikony i style warianty liczą się lokalnie

## Technika

- Android 10+ (minSdk 29, targetSdk 34), Java 17, bez zależności od usług Google
- MapLibre GL 11 (mapa wektorowa), Material Design Icons (SVG)
- Jednoactivityowa architektura + system przeciąganych paneli (bottom sheets)
- Podpisany kluczem release (aktualizacje instalują się „na Starszą wersję” bez odinstalowywania)

## Budowanie

```bash
gradle assembleRelease   # APK: app/build/outputs/apk/release/app-release.apk
```

Wymagania: JDK 17, Android SDK 34. Klucz podpisu: `release.keystore` w katalogu projektu.

## Historia wersji

Zobacz [ver_log.md](ver_log.md) — pełny raport zmian dla wersji alpha-1.6.1 – alpha-1.6.4.
