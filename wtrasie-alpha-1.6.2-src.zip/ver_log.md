# Dziennik wersji (ver_log)

## alpha-1.6.2 (versionCode 12)

Kolejna tura napraw zgłoszonych po testach alpha-1.6.1 — w tym kilka wieloletnich „nieśmiertelnych".

### Trwałość ustawień („po 1–2 h wszystkie switche na off”)
- **Wszystkie zapisy ustawień przeszły z `apply()` na `commit()`** — synchroniczny zapis na dysk.
  `apply()` zrzucał zapis do wątku w tle; gdy OEM zabijał proces, oczekujący zapis ginął i aplikacja
  startowała z pustymi (wyłączonymi) przełącznikami. Teraz każdy przełącznik ląduje na dysku w
  momencie dotknięcia.

### Rozmiar ikon S / M / L — naprawiony
- Naprawiony znany bug: plakietki pojazdów były cache'owane pod nazwami **bez rozmiaru**, więc
  zmiana S/M/L nie tworzyła nowych markerów. Warstwa `iconSize` mapy mnoży się teraz o czynnik
  (0.8 / 1.0 / 1.25) — **natychmiastowy** efekt bez przebudowy; ikony przystanków są rysowane
  od nowa w nowym rozmiarze (nazwa obrazka zawiera indeks rozmiaru).

### Nowe: rozmiar tekstu A- / A / A+ / A++
- Globalny mnożnik rozmiaru tekstu (0.87 / 1.0 / 1.13 / 1.28) zastosowany w tablicy odjazdów,
  rozkładach (kafelki, chipsy dnia, lista kursów), wyszukiwaniu, liście miast, liście linii,
  timeline trasy pojazdu (razem z wysokością wierszy) i ustawieniach. Skalowanie jest idempotentne
  i odporne na recykling wierszy.

### Parsowanie GTFS z cudzysłowami („przystanek 'Dworzec”)
- Ekstraktor pól CSV (**fieldAt**) jest teraz **świadomy cudzysłowów**. Feedy typu Helsinki cytują
  pola zawierające przecinki (np. `"Länsiterm. 2, tulo 0240"`); stary splitter tniąc po przecinku
  zostawiał tekst z zaczynającym cudzysłowem, ucinał nazwę i **przesuwał wszystkie następne kolumny**
  (wprowadzało zrzucone współrzędne). Naprawia dziwne nazwy przystanków przy trasach
  i rozkładach (Helsinki/Tampere — m.in. prom do Suomenlinny).

### Tabliczka rozkładowa — trzecie podejście, tym razem z fundamentem
- **Brak ~10 pustych linii** między kafelkami linii a menu „DZIEŃ”: naprawiony pomiar `FlowLayout`
  (przejmował całą dostępną wysokość specyfikacji — stąd gigantyczna dziura).
- **Kafelki linii to ten sam layout (`chip_route`)** co chipsy na górze panelu i pigułki linii
  na liście odjazdów — identyczne tło i wygląd, bez ucięć.
- **Gigantyczna naprawa poprawności danych**: zbiorkom generuje feedy **calendar_dates-only**
  (bez wzorca tygodniowego). Stary kod wpuszczał wtedy WSZYSTKIE kalendarze do jednego worka
  „Inny wariant” i mieszał godziny dni roboczych-szkolnych, wakacyjnych, sobót, niedziel i serii
  zastępczych — stąd raportowane „14:46 14:46 14:48 14:56 mimo jazdy co 30 minut”. Teraz wzorzec
  dnia **wyliczany jest z realnych dat kursowania** (odporność na jednodniowe święta), a zakres dat
  trafia do nazwy wariantu: „Dni robocze · 09.11–22.12” vs „Dni robocze · 23.12–31.12” osobno.
- **Deduplikacja (godzina + kierunek + linia)** — równoważne warianty z tą samą godziną nie
  drukują się podwójnie.

### Trasa pojazdu: priorytet i niezawodność
- **Tłoowe dogrzewanie cache GTFS**: 2 s po załadowaniu przystanków miasta jego paczki GTFS
  ściągają się w tle na najniższym priorytecie (max 3 agencje + default, sekwencyjnie, cache 24 h).
  Kliknięty pojazd czyta trasę z ciepłego cache — koniec minuty czekania na prom w Helsinkach
  oglądany z Rzeszowa. Zgodnie z życzeniem: przy pojazdzie **tylko jego trasa**, pełne dane
  tylko dla pełnej mapy.
- **Ciche retrye**: pobranie trasy ponawia się automatycznie (×2 w warstwie zip + ×3 z backoffem
  w panelu), rozkład przystanku ×1 — „trasa w ogóle się nie wczytuje, klikam odśwież” znika.

### Mapa
- **4 warianty podkładu Podstawowego** (Pastelowy / Kontrastowy / Ciepły / Chłodny) generowane
  w locie z `style_basic.json` — spójne przekształcenie HSV wszystkich kolorów stylu, zero
  dodatkowych pobierania. Podkład „Podstawowa” → „Podstawowy”.
- Paski progów zoomu przeniesione do rozwijanego menu **„Wyświetlanie znaczników”** (jak FAQ):
  po prostu „pojazd”, „przystanek”, „pociąg”.

### Domyślne ustawienia (zgodnie ze specyfikacją użytkownika)
- Pojazdy na mapie **wł**, przystanki na mapie **wł**, odświeżanie **10 s**, filtruj przejazdy
  techniczne **wł**, automatyczna zmiana miasta **wł**, podkład **Podstawowy**, oryginalne
  kolory pojazdów **wł**; wszystko pozostałe **wył**.
- Suwaki: pojazdy **13**, przystanki **15** (było 11.5), pociągi **11**.

### Dokumentacja
- **README napisany od nowa** — opis aktualnych funkcji (z nowościami 1.6.2), danych i budowania.
- Plik `ver_log.md` — niniejszy raport.

---

## alpha-1.6.1 (versionCode 11)

### Pojazdy i mapa
- **Naprawa czarnych kropek pojazdów**: kolory właściwości GeoJSON muszą mieć prefiks `#` —
  bez niego MapLibre nie parsował koloru i warstwy kółek spadały do czerni. Kropki (niski zoom)
  mają odtąd realny kolor linii.
- **Przystanki nigdy nie są kropkami** — od progu widoczności każdy przystanek rysuje się jako
  kolorowa ikona typu rosnąca wraz z zoomem (koniec „kompletnie rozpierdalonej widoczności”).
- **Nakładka przystanków wszystkich przewoźników**: ogólnopolski feed PKP dokłada stacje kolejowe
  w oglądanym oknie NA wybrany obszar miasta — Rzeszów pokazuje też dworce, nie tylko autobusy.
- Animacja pozycji: krótki (250 ms) przeskok do świeżego pomiaru, bez sztucznych „duchów”.

### Wyszukiwanie i panele
- **Dezambigualizacja typu w wyszukiwaniu**: wynik z ikoną dworca kolejowego otwiera się z feedu
  kolejowego (nie z sąsiedniego przystanku autobusowego o tej samej nazwie).
- Menu wyboru miasta zgodne z wyszukiwarką: przycisk **X** do zamknięcia i minimalna wysokość
  panelu bez „wystającej kreski” na dole.

### Rozkłady i GTFS
- Tabliczka rozkładowa przebudowana: kafelki linii → menu dnia (chipsy typów dnia z fadem +
  przypięta ikona kalendarza) → lista kursów w stylu najbliższych odjazdów (linia + kierunek,
  godzina po prawej).
- GTFS na **priorytetowej kolejce** (własna pula wątków): trasa klikniętego pojazdu (priorytet 0)
  nigdy nie czeka za masowym parsowaniem rozkładu (priorytet 2); pobieranie zipów nie zagłodzi
  pozycji na żywo.
- Naprawa pustej listy tras do ręcznego odświeżenia: czekający na pobieranie zipa **krążą w pętli
  aż do końca pobierania** i reużywają rezultat (wcześniej: równoległy pobór tego samego pliku
  psuł archiwum).

### Naprawy z alpha-1.6.0 zachowane
- zapisane ustawienia widoczności respektowane przy starcie (bez resetu do wł.),
- awaryjny powrót stylu mapy po utracie natywnego renderera w tle,
- natychmiastowa zmiana miasta po zatrzymaniu kamery, czyszczenie nakładki po zmianie feedu.
