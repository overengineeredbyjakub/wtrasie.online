package online.wtrasie.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextPaint;

import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.maplibre.android.style.layers.CircleLayer;
import org.maplibre.android.style.layers.Layer;
import org.maplibre.android.style.layers.LineLayer;
import org.maplibre.android.style.layers.SymbolLayer;
import org.maplibre.android.style.sources.GeoJsonSource;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.FeatureCollection;
import org.maplibre.geojson.LineString;
import org.maplibre.geojson.Point;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.maplibre.android.style.expressions.Expression.exponential;
import static org.maplibre.android.style.expressions.Expression.get;
import static org.maplibre.android.style.expressions.Expression.interpolate;
import static org.maplibre.android.style.expressions.Expression.stop;
import static org.maplibre.android.style.expressions.Expression.zoom;

/**
 * All map rendering on top of a MapLibre vector map (the same style the
 * zbiorkom.live web app uses — OpenFreeMap/OpenMapTiles).
 *
 * alpha-1.6.1:
 *  - Color property strings must carry the "#" prefix — without it MapLibre
 *    cannot parse them and every circle layer fell back to BLACK. That was
 *    the long-standing "black vehicle dots" bug: the chips were colored
 *    bitmaps while the dots were unparsable color strings.
 *  - Stops are NEVER dots: every stop renders as its colored type icon from
 *    the stop zoom threshold up (growing with zoom). The dot phase ruined
 *    readability — you could not tell what a stop was until fully zoomed in.
 *  - Overlay stops: the nationwide pkp feed contributes viewport stops ON TOP
 *    of the selected city's stops, so the viewed area always shows every
 *    carrier (train stations included), not only the city's buses.
 * alpha-1.6.0:
 *  - NO route-shape snapping and no long glides: a vehicle simply takes a
 *    quick (250 ms) smooth hop from point A to point B on every data packet.
 *  - NO stale-vehicle grace period: the map shows exactly what the live feed
 *    returned — no ghost buses kept on screen.
 */
public class MapLayers {

    public interface Listener {
        void onMapReady();

        void onViewportSettled();

        void onVehicleTapped(Models.Vehicle v);

        void onStopTapped(Models.Stop s);

        void onRouteStopTapped(String stopId, String name, double lat, double lon);
    }

    private final Context ctx;
    private final Prefs prefs;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());

    MapView mapView;
    MapLibreMap map;
    Style style;
    private boolean ready = false;
    private int currentStyleIdx = -1;

    // ---- data ----
    private final List<Models.Stop> stops = new ArrayList<>();        // selected city
    private final List<Models.Stop> overlayStops = new ArrayList<>(); // nationwide pkp viewport stops
    private final List<Models.Vehicle> vehicles = new ArrayList<>();   // current city
    private final List<Models.Vehicle> pkpVehicles = new ArrayList<>(); // nationwide PKP overlay
    private final Map<String, VState> vstates = new HashMap<>();
    private String highlightKey;                 // vehicle preview ("type:id")
    private Gtfs.Trip previewTrip;
    private int previewColor = 0xFF1976D2;

    /** Per-vehicle display state: a single quick hop to the fresh fix. */
    private static class VState {
        double dispLat, dispLon;     // what is on screen right now
        double fromLat, fromLon;     // hop start
        double toLat, toLon;         // fresh fix
        long startMs, durMs = 250;
        boolean arrived = true;
    }

    private final Runnable animTick = new Runnable() {
        @Override
        public void run() {
            try {
                if (ready && stepAnimation()) rebuildVehicleSources();
            } catch (Throwable ignored) {
            }
            handler.postDelayed(this, 100);
        }
    };

    public MapLayers(Context ctx, Prefs prefs, Listener listener) {
        this.ctx = ctx;
        this.prefs = prefs;
        this.listener = listener;
        handler.post(animTick);
    }

    // ---------------------------------------------------------------- attach / style

    public void attach(MapView view) {
        this.mapView = view;
        view.getMapAsync(m -> {
            map = m;
            m.getUiSettings().setAttributionEnabled(false);
            m.getUiSettings().setLogoEnabled(false);
            m.setMinZoomPreference(4);
            m.setMaxZoomPreference(19);
            m.addOnMapClickListener(this::onMapClick);
            m.addOnCameraIdleListener(() -> {
                if (ready) listener.onViewportSettled();
                applyZoomThresholds(); // layer min/max zoom may follow the sliders
            });
            applyStyle(prefs.mapStyle());
        });
    }

    /**
     * 0 = basic vector (OpenFreeMap), 1 = OSM raster, 2 = Esri satellite.
     * alpha-1.6.2: 3..6 = runtime VARIANTS of the basic style (Pastelowy /
     * Kontrastowy / Ciepły / Chłodny) — every color of style_basic.json is
     * pushed through one coherent HSV transform and the style is loaded
     * fromJson (fully offline, no extra tiles).
     */
    public void applyStyle(int idx) {
        if (map == null || idx == currentStyleIdx) return;
        currentStyleIdx = idx;
        ready = false;
        if (StyleVariants.isVariant(idx)) {
            String json = StyleVariants.variantJson(ctx, idx);
            if (json != null) {
                map.setStyle(new Style.Builder().fromJson(json), s -> onStyleReady());
                return;
            }
            idx = 0; // graceful fallback: the plain basic style
        }
        String uri = idx == 1 ? "asset://style_osm.json"
                : idx == 2 ? "asset://style_sat.json"
                : "asset://style_basic.json";
        map.setStyle(new Style.Builder().fromUri(uri), s -> onStyleReady());
    }

    private void onStyleReady() {
        style = map.getStyle();
        ready = true;
        reapplying = false;
        try {
            buildLayers();
            registerStopIcons();
            pushAllData();
            applyZoomThresholds();
        } catch (Throwable t) {
            android.util.Log.e("MapLayers", "style ready", t);
        }
        listener.onMapReady();
    }

    private void buildLayers() {
        addSource("route-src");
        style.addLayer(new LineLayer("route-casing", "route-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.lineColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.lineWidth(10.5f),
                org.maplibre.android.style.layers.PropertyFactory.lineCap(
                        org.maplibre.android.style.layers.Property.LINE_CAP_ROUND),
                org.maplibre.android.style.layers.PropertyFactory.lineJoin(
                        org.maplibre.android.style.layers.Property.LINE_JOIN_ROUND)));
        style.addLayer(new LineLayer("route-line", "route-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.lineColor(0xFF1976D2),
                org.maplibre.android.style.layers.PropertyFactory.lineWidth(7f),
                org.maplibre.android.style.layers.PropertyFactory.lineCap(
                        org.maplibre.android.style.layers.Property.LINE_CAP_ROUND),
                org.maplibre.android.style.layers.PropertyFactory.lineJoin(
                        org.maplibre.android.style.layers.Property.LINE_JOIN_ROUND)));

        addSource("route-stops-src");
        style.addLayer(new CircleLayer("route-stops", "route-stops-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(4f),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(0xFF1976D2),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth(2.5f)));

        // alpha-1.6.1: ONE stop layer for every transport type and NO dot phase —
        // a stop always renders as its colored type icon (smaller when zoomed
        // out, growing with zoom). The dots were unreadable noise.
        addSource("stops-src");
        style.addLayer(new SymbolLayer("stops-icons", "stops-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.25), zoom(),
                                stop(11f, 0.55f), stop(14f, 0.85f), stop(17.5f, 1.05f)))));

        // vehicles: dots below the threshold, upright chips with the line number above
        addSource("veh-dot-src");
        style.addLayer(new CircleLayer("veh-dots", "veh-dot-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(get("color")),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(0xFFFFFFFF),
                org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth(1.1f),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(
                        interpolate(exponential(1.4), zoom(), stop(5f, 2.6f), stop(12f, 3.6f)))));

        addSource("veh-full-src");
        style.addLayer(new SymbolLayer("veh-badges", "veh-full-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.2), zoom(), stop(12f, 0.9f), stop(17f, 1.05f)))));

        // PKP trains: own sources, own dot threshold — always visible
        addSource("pkp-dot-src");
        style.addLayer(new CircleLayer("pkp-dots", "pkp-dot-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.circleColor(get("color")),
                org.maplibre.android.style.layers.PropertyFactory.circleRadius(
                        interpolate(exponential(1.4), zoom(), stop(5f, 2.8f), stop(12f, 3.6f)))));
        addSource("pkp-full-src");
        style.addLayer(new SymbolLayer("pkp-badges", "pkp-full-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.2), zoom(), stop(10f, 0.9f), stop(17f, 1.05f)))));

        // the previewed vehicle: a full chip at ANY zoom — never a plain dot
        addSource("veh-hl-src");
        style.addLayer(new SymbolLayer("veh-hl", "veh-hl-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage(get("icon")),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true),
                org.maplibre.android.style.layers.PropertyFactory.iconSize(
                        interpolate(exponential(1.2), zoom(), stop(5f, 0.85f), stop(17f, 1.05f)))));

        // user location dot
        addSource("loc-src");
        style.addLayer(new SymbolLayer("loc-marker", "loc-src").withProperties(
                org.maplibre.android.style.layers.PropertyFactory.iconImage("loc_dot"),
                org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap(true),
                org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement(true)));
        try {
            style.addImage("loc_dot", locationBitmap());
        } catch (Throwable ignored) {
        }
    }

    private void addSource(String id) {
        try {
            style.addSource(new GeoJsonSource(id, FeatureCollection.fromFeatures(new ArrayList<>())));
        } catch (Throwable ignored) {
        }
    }

    private void setSource(String id, FeatureCollection fc) {
        if (!ready) return;
        try {
            GeoJsonSource src = style.getSourceAs(id);
            if (src == null) {
                // v1.5.0: the GL surface was destroyed while the app was in the
                // background and the native style got recreated without our
                // layers — rebuild the whole style instead of silently no-opping
                // (this is what made the map "stop refreshing" after returning).
                reapplyStyle();
                src = ready ? style.getSourceAs(id) : null;
            }
            if (src != null) src.setGeoJson(fc);
        } catch (Throwable t) {
            android.util.Log.w("MapLayers", "setSource " + id + " " + t);
        }
    }

    /** Full style rebuild (layers, icons, sources, data) after a native style loss. */
    private void reapplyStyle() {
        if (reapplying) return;
        reapplying = true;
        currentStyleIdx = -1;
        ready = false;
        applyStyle(prefs.mapStyle());
        // reapplying is cleared in the style-ready callback
    }

    private boolean reapplying = false;

    private void setLayerVisible(String id, boolean visible) {
        if (!ready) return;
        try {
            Layer l = style.getLayer(id);
            if (l != null) l.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.visibility(
                            visible ? org.maplibre.android.style.layers.Property.VISIBLE
                                    : org.maplibre.android.style.layers.Property.NONE));
        } catch (Throwable ignored) {
        }
    }

    /** Layer zoom thresholds follow the visibility sliders. */
    private void applyZoomThresholds() {
        if (!ready) return;
        float vehDot = prefs.dotZoomVehicles() / 10f;
        float stopsMin = prefs.dotZoomStops() / 10f;
        float pkpDot = prefs.dotZoomPkp() / 10f;
        try {
            trySetZoom("veh-badges", vehDot, -1);
            trySetZoom("veh-dots", -1, vehDot);
            trySetZoom("pkp-badges", pkpDot, -1);
            trySetZoom("pkp-dots", -1, pkpDot);
            // alpha-1.6.1: stops are icons from their own threshold — never dots
            trySetZoom("stops-icons", stopsMin, -1);
        } catch (Throwable ignored) {
        }
        applyMarkerScale();
    }

    /**
     * alpha-1.6.2: the icon S/M/L setting ACTUALLY works now.
     * - vehicle / pkp / highlight chips: the symbol layers' iconSize gets
     *   multiplied by the scale factor — an instant, cache-free resize of
     *   everything already on the map (this was the "S/M/L does nothing" bug:
     *   the chip bitmaps were cached under names without the scale, so a
     *   changed setting never produced new markers);
     * - stop icons: freshly drawn bitmaps at the scaled size, registered
     *   under scale-suffixed names, features rebuilt.
     */
    private void applyMarkerScale() {
        if (!ready) return;
        float f = markerFactor();
        try {
            SymbolLayer stops = (SymbolLayer) style.getLayer("stops-icons");
            if (stops != null) stops.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.iconSize(
                            interpolate(exponential(1.25), zoom(),
                                    stop(11f, 0.55f), stop(14f, 0.85f), stop(17.5f, 1.05f))));
            SymbolLayer veh = (SymbolLayer) style.getLayer("veh-badges");
            if (veh != null) veh.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.iconSize(
                            interpolate(exponential(1.2), zoom(),
                                    stop(12f, 0.9f * f), stop(17f, 1.05f * f))));
            SymbolLayer pkp = (SymbolLayer) style.getLayer("pkp-badges");
            if (pkp != null) pkp.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.iconSize(
                            interpolate(exponential(1.2), zoom(),
                                    stop(10f, 0.9f * f), stop(17f, 1.05f * f))));
            SymbolLayer hl = (SymbolLayer) style.getLayer("veh-hl");
            if (hl != null) hl.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.iconSize(
                            interpolate(exponential(1.2), zoom(),
                                    stop(5f, 0.85f * f), stop(17f, 1.05f * f))));
        } catch (Throwable t) {
            android.util.Log.w("MapLayers", "marker scale", t);
        }
    }

    /** 0.8 = S, 1.0 = M, 1.25 = L. */
    private float markerFactor() {
        switch (prefs.vehicleScale()) {
            case 0: return 0.8f;
            case 2: return 1.25f;
            default: return 1f;
        }
    }

    private void trySetZoom(String layerId, float min, float max) {
        try {
            Layer l = style.getLayer(layerId);
            if (l == null) return;
            if (min >= 0) l.setMinZoom(min);
            if (max >= 0) l.setMaxZoom(max);
        } catch (Throwable ignored) {
        }
    }

    public void refreshThresholds() {
        applyZoomThresholds();
        // stop icon bitmaps carry the scale in their name — re-register the
        // scaled variants and redraw the stop features with the new names
        registerStopIcons();
        rebuildStopSources();
    }

    /** Rebuild stop + vehicle sources after settings/filters changed. */
    public void rebuildPublic() {
        rebuildStopSources();
        rebuildVehicleSources();
    }

    // ---------------------------------------------------------------- stop icons

    private final Map<String, Bitmap> stopIconCache = new HashMap<>();

    /** Colored disc + white type glyph, registered per type in the style. */
    private void registerStopIcons() {
        int[] types = {0, 1, 2, 3, 4, 11, 5, 6, 7, 12};
        String sfx = iconScaleSuffix();
        for (int t : types) {
            String name = "st_ic_" + t + sfx;
            if (style.getImage(name) == null) {
                try {
                    style.addImage(name, stopIconBitmap(t, false));
                } catch (Throwable ignored) {
                }
            }
        }
        // station variant (building glyph)
        String station = "st_ic_station" + sfx;
        if (style.getImage(station) == null) {
            try {
                style.addImage(station, stopIconBitmap(2, true));
            } catch (Throwable ignored) {
            }
        }
    }

    /** "" / "_s0" / "_s2" — part of the stop icon image NAME, so the scaled
     *  bitmap replaces the old one when the S/M/L setting changes. */
    private String iconScaleSuffix() {
        int s = prefs.vehicleScale();
        return s == 1 ? "" : "_s" + s;
    }

    private Bitmap stopIconBitmap(int type, boolean station) {
        // alpha-1.6.2: stop icons follow the S/M/L marker size too
        float marker = 0.8f + 0.225f * prefs.vehicleScale();
        String key = type + "_" + station + "_" + marker;
        Bitmap cached = stopIconCache.get(key);
        if (cached != null) return cached;
        int size = Math.round(Ui.dp(ctx, 26) * marker);
        int pad = Ui.dp(ctx, 2);
        Bitmap b = Bitmap.createBitmap(size + pad * 2, size + pad * 2, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        float cx = (size + pad * 2) / 2f, cy = cx;
        float r = size / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, r, p);
        p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Models.stopColor(type));
        c.drawCircle(cx, cy, r - Ui.dp(ctx, 1.5f), p);
        try {
            int res = station ? R.drawable.ic_station : Models.stopIcon(type);
            Drawable d = ctx.getDrawable(res);
            if (d != null) {
                d.setTint(0xFFFFFFFF);
                float inset = r * 0.52f;
                d.setBounds((int) (cx - inset), (int) (cy - inset), (int) (cx + inset), (int) (cy + inset));
                d.draw(c);
            }
        } catch (Throwable ignored) {
        }
        stopIconCache.put(key, b);
        return b;
    }

    private Bitmap locationBitmap() {
        int size = Ui.dp(ctx, 26);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = size / 2f;
        p.setColor(0x330B57D0);
        c.drawCircle(r, r, r, p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(r, r, r * 0.72f, p);
        p.setColor(0xFF1A73E8);
        c.drawCircle(r, r, r * 0.56f, p);
        return b;
    }

    // ---------------------------------------------------------------- vehicle badges

    private final Map<String, Bitmap> badgeCache = new LinkedHashMap<String, Bitmap>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Bitmap> eldest) {
            return size() > 260;
        }
    };

    /**
     * v1.4.0 vehicle marker: an upright rounded chip in the vehicle color
     * with the line number (PKP: "IC 5423") and — unless "Ukryj ikonę
     * pojazdu" is on — a small white type glyph beside the number.
     */
    private Bitmap vehicleChip(String label, int type, int color, boolean withIcon) {
        float scale = 0.85f + 0.15f * prefs.vehicleScale(); // S / M / L
        String key = label + "|" + type + "|" + color + "|" + withIcon + "|" + scale;
        Bitmap cached = badgeCache.get(key);
        if (cached != null) return cached;

        TextPaint tp = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFFFFFFFF);
        tp.setTextSize(Ui.dp(ctx, 11.5f) * scale);
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        float textW = tp.measureText(label);
        int h = (int) (Ui.dp(ctx, 20) * scale);
        float iconW = withIcon ? Ui.dp(ctx, 11) * scale + Ui.dp(ctx, 3) : 0;
        float w = iconW + textW + Ui.dp(ctx, 16) * scale; // side padding
        int pad = Ui.dp(ctx, 2); // room for the white ring
        int bw = (int) Math.ceil(w) + pad * 2;
        int bh = h + pad * 2;
        if (bw <= 0 || bh <= 0) bw = bh = 8;
        Bitmap b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);

        float r = h / 2f;
        RectF rect = new RectF(pad, pad, pad + w, pad + h);
        Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        body.setColor(Ui.ensureReadable(color));
        c.drawRoundRect(rect, r, r, body);
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Ui.dp(ctx, 1.4f));
        ring.setColor(0xFFFFFFFF);
        c.drawRoundRect(rect, r, r, ring);

        float cx = pad + Ui.dp(ctx, 8) * scale;
        if (withIcon) {
            try {
                Drawable d = ctx.getDrawable(Models.typeIcon(type));
                if (d != null) {
                    d.setTint(0xFFFFFFFF);
                    float is = Ui.dp(ctx, 11) * scale;
                    float icy = pad + h / 2f;
                    d.setBounds((int) cx, (int) (icy - is / 2f), (int) (cx + is), (int) (icy + is / 2f));
                    d.draw(c);
                    cx += is + Ui.dp(ctx, 3);
                }
            } catch (Throwable ignored) {
            }
        }
        Paint.FontMetrics fm = tp.getFontMetrics();
        float ty = pad + h / 2f - (fm.ascent + fm.descent) / 2f;
        c.drawText(label, cx, ty, tp);
        badgeCache.put(key, b);
        return b;
    }

    private void ensureChipIcon(String name, String label, int type, int color, boolean withIcon) {
        try {
            if (style.getImage(name) == null) {
                style.addImage(name, vehicleChip(label, type, color, withIcon));
            }
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- data push

    private void pushAllData() {
        rebuildStopSources();
        rebuildVehicleSources();
        pushRoute();
    }

    public void setStops(List<Models.Stop> s) {
        stops.clear();
        if (s != null) stops.addAll(s);
        rebuildStopSources();
    }

    /**
     * alpha-1.6.1: viewport stops of a NATIONWIDE feed (pkp) drawn ON TOP of
     * the city's own stops — the viewed area shows every carrier, train
     * stations included.
     */
    public void setOverlayStops(List<Models.Stop> s) {
        overlayStops.clear();
        if (s != null) overlayStops.addAll(s);
        rebuildStopSources();
    }

    public void clearOverlayStops() {
        overlayStops.clear();
        rebuildStopSources();
    }

    /** Every visible stop: city + nationwide overlay (deduped by id and location). */
    public List<Models.Stop> getStops() {
        List<Models.Stop> all = new ArrayList<>(stops.size() + overlayStops.size());
        java.util.Set<String> seenIds = new java.util.HashSet<>();
        java.util.Set<String> seenCells = new java.util.HashSet<>();
        for (Models.Stop s : stops) {
            if (seenIds.add(s.id)) {
                all.add(s);
                seenCells.add(cellKey(s.lat, s.lon));
            }
        }
        for (Models.Stop s : overlayStops) {
            if (!seenIds.add(s.id)) continue;              // same id in the city feed already
            if (seenCells.contains(cellKey(s.lat, s.lon))) continue; // same place already drawn
            all.add(s);
            seenCells.add(cellKey(s.lat, s.lon));
        }
        return all;
    }

    /** ~50 m geographic cell key used for stop dedup. */
    private static String cellKey(double lat, double lon) {
        return Math.round(lat / 0.0005) + "," + Math.round(lon / 0.0005);
    }

    /**
     * alpha-1.6.0: NO grace period — the map shows EXACTLY the vehicles the
     * live feed returned. Nothing is kept artificially on screen (that was
     * the source of the "ghost buses" that vanished on tap).
     */
    public void setVehicles(List<Models.Vehicle> v) {
        vehicles.clear();
        if (v != null) vehicles.addAll(v);
        ingestVehicles(vehicles);
        rebuildVehicleSources();
    }

    public void clearVehicles() {
        vehicles.clear();
        rebuildVehicleSources();
    }

    public void setPkpVehicles(List<Models.Vehicle> v) {
        pkpVehicles.clear();
        if (v != null) {
            for (Models.Vehicle x : v) x.pkp = true;
            pkpVehicles.addAll(v);
        }
        ingestVehicles(pkpVehicles);
        rebuildVehicleSources();
    }

    public List<Models.Vehicle> getVehicles() {
        List<Models.Vehicle> all = new ArrayList<>(vehicles);
        all.addAll(pkpVehicles);
        return all;
    }

    public Models.Vehicle highlightedVehicle() {
        if (highlightKey == null) return null;
        for (Models.Vehicle v : getVehicles()) {
            if (v.rtKey().equals(highlightKey)) return v;
        }
        return null;
    }

    /**
     * alpha-1.6.0 animation: one quick smooth hop (250 ms, constant speed)
     * from the currently drawn position to the fresh fix. No route shapes,
     * no snapping, no stretched glides.
     */
    private void ingestVehicles(List<Models.Vehicle> list) {
        long now = System.currentTimeMillis();
        java.util.HashSet<String> live = new java.util.HashSet<>();
        for (Models.Vehicle v : list) {
            live.add(v.rtKey());
            VState st = vstates.get(v.rtKey());
            if (st == null) {
                st = new VState();
                st.dispLat = v.lat;
                st.dispLon = v.lon;
                st.fromLat = v.lat;
                st.fromLon = v.lon;
                st.toLat = v.lat;
                st.toLon = v.lon;
                st.arrived = true;
                vstates.put(v.rtKey(), st);
            } else {
                boolean moved = Math.abs(st.toLat - v.lat) > 1e-7 || Math.abs(st.toLon - v.lon) > 1e-7;
                if (moved) {
                    st.fromLat = st.dispLat;
                    st.fromLon = st.dispLon;
                    st.toLat = v.lat;
                    st.toLon = v.lon;
                    st.startMs = now;
                    st.durMs = 250; // a quick hop — not a stretched glide
                    st.arrived = false;
                }
            }
        }
        // drop states of vehicles that are gone — no ghosts
        vstates.keySet().retainAll(live);
    }

    /** Advance every hop; true when something moved (source needs update). */
    private boolean stepAnimation() {
        long now = System.currentTimeMillis();
        boolean moved = false;
        for (Map.Entry<String, VState> e : vstates.entrySet()) {
            VState st = e.getValue();
            if (st.arrived) continue;
            float f = st.durMs <= 0 ? 1f : (now - st.startMs) / (float) st.durMs;
            if (f >= 1) f = 1;
            // linear ("płynne przesunięcie") — constant speed from A to B
            st.dispLat = st.fromLat + (st.toLat - st.fromLat) * f;
            st.dispLon = st.fromLon + (st.toLon - st.fromLon) * f;
            moved = true;
            if (f >= 1) st.arrived = true;
        }
        return moved;
    }

    // ---------------------------------------------------------------- sources rebuild

    private boolean vehicleVisible(Models.Vehicle v) {
        if (!prefs.showVehicles()) return false;
        if (Models.hiddenByTechnicalFilter(v.routeName, prefs.filterTechnical())) return false;
        if (highlightKey != null) return v.rtKey().equals(highlightKey);
        return prefs.typeFilter(v.typeInt());
    }

    private void rebuildStopSources() {
        if (!ready) return;
        boolean previewOpen = highlightKey != null;
        List<Feature> feats = new ArrayList<>();
        if (!previewOpen && prefs.showStops()) {
            java.util.Set<String> seenIds = new java.util.HashSet<>();
            java.util.Set<String> seenCells = new java.util.HashSet<>();
            for (Models.Stop s : stops) {
                if (!passesTypeFilter(s)) continue;
                seenIds.add(s.id);
                seenCells.add(cellKey(s.lat, s.lon));
                addStopFeature(feats, s);
            }
            for (Models.Stop s : overlayStops) {
                if (seenIds.contains(s.id) || seenCells.contains(cellKey(s.lat, s.lon))) continue;
                if (!passesTypeFilter(s)) continue;
                seenIds.add(s.id);
                seenCells.add(cellKey(s.lat, s.lon));
                addStopFeature(feats, s);
            }
        }
        setSource("stops-src", FeatureCollection.fromFeatures(feats));
    }

    private boolean passesTypeFilter(Models.Stop s) {
        for (int t : s.types) {
            if (prefs.typeFilter(t)) return true;
        }
        return false;
    }

    private void addStopFeature(List<Feature> feats, Models.Stop s) {
        Feature f = Feature.fromGeometry(Point.fromLngLat(s.lon, s.lat));
        int mt = s.mainType();
        f.addStringProperty("color", hex(Models.stopColor(mt)));
        f.addStringProperty("icon", (s.isStation() && (mt == 2 || mt == 1)
                ? "st_ic_station" : "st_ic_" + mt) + iconScaleSuffix());
        feats.add(f);
    }

    private void rebuildVehicleSources() {
        if (!ready) return;
        List<Feature> dots = new ArrayList<>();
        List<Feature> full = new ArrayList<>();
        List<Feature> pkpDots = new ArrayList<>();
        List<Feature> pkpFull = new ArrayList<>();
        List<Feature> hl = new ArrayList<>();
        for (Models.Vehicle v : vehicles) {
            if (!vehicleVisible(v)) continue;
            boolean isHl = highlightKey != null && v.rtKey().equals(highlightKey);
            addVehicleFeature(v, isHl ? null : dots, isHl ? null : full, isHl ? hl : null);
        }
        boolean hlKey = highlightKey != null;
        for (Models.Vehicle v : pkpVehicles) {
            if (Models.hiddenByTechnicalFilter(v.routeName, prefs.filterTechnical())) continue;
            if (hlKey && !v.rtKey().equals(highlightKey)) continue;
            if (!hlKey && !prefs.typeFilter(v.typeInt())) continue;
            boolean isHl = hlKey;
            addVehicleFeature(v, isHl ? null : pkpDots, isHl ? null : pkpFull, isHl ? hl : null);
        }
        setSource("veh-dot-src", FeatureCollection.fromFeatures(dots));
        setSource("veh-full-src", FeatureCollection.fromFeatures(full));
        setSource("pkp-dot-src", FeatureCollection.fromFeatures(pkpDots));
        setSource("pkp-full-src", FeatureCollection.fromFeatures(pkpFull));
        setSource("veh-hl-src", FeatureCollection.fromFeatures(hl));
    }

    /** Display color of a vehicle: unified per type unless the user keeps feed colors. */
    private int vehColor(Models.Vehicle v) {
        if (v == null) return 0xFFD32F2F;
        return prefs.keepOriginalColors() ? v.routeColor : Models.typeColor(v.typeInt());
    }

    private void addVehicleFeature(Models.Vehicle v, List<Feature> dots, List<Feature> full, List<Feature> hl) {
        VState st = vstates.get(v.rtKey());
        double lat = st == null ? v.lat : st.dispLat;
        double lon = st == null ? v.lon : st.dispLon;
        int color = vehColor(v);
        // chip: line number (PKP: carrier + brigade), optional type glyph beside
        String label = VehicleSheet.vehicleLabel(v);
        if (!v.pkp) {
            if (prefs.showBrigade() && v.brigade != null && !v.brigade.isEmpty()) label += "/" + v.brigade;
            if (prefs.showFleet() && v.id != null && !v.id.isEmpty() && !v.id.startsWith("_")) label += "/" + v.id;
        }
        boolean withIcon = !prefs.hideVehicleIcon();
        String iname = "vch_" + v.typeInt() + "_" + (color & 0xFFFFFF) + "_" + (withIcon ? 1 : 0) + "_" + label;
        ensureChipIcon(iname, label, v.typeInt(), color, withIcon);
        Feature f = Feature.fromGeometry(Point.fromLngLat(lon, lat));
        f.addStringProperty("icon", iname);
        if (hl != null) {
            // the previewed vehicle keeps its full badge at any zoom
            hl.add(f);
            return;
        }
        if (dots != null) {
            Feature dot = Feature.fromGeometry(Point.fromLngLat(lon, lat));
            // v1.5.0: the low-zoom dot keeps the REAL line color — you can tell
            // lines apart even after the badges collapse into dots
            dot.addStringProperty("color", hex(v.routeColor != 0 ? v.routeColor : color));
            dots.add(dot);
        }
        if (full != null) full.add(f);
    }

    private static String hex(int color) {
        // alpha-1.6.1: MapLibre's color parser needs the "#" — a bare
        // "RRGGBB" string is invalid and silently falls back to BLACK
        // (the "black vehicle dots" bug).
        return "#" + String.format("%06X", 0xFFFFFF & color);
    }

    // ---------------------------------------------------------------- route preview

    /** Vehicle preview mode: only this vehicle stays on the map. */
    public void setHighlight(String key) {
        highlightKey = key;
        rebuildStopSources();
        rebuildVehicleSources();
    }

    public String getHighlight() {
        return highlightKey;
    }

    public void setTrip(Gtfs.Trip trip, int color) {
        previewTrip = trip;
        previewColor = color;
        pushRoute();
        try {
            Layer l = style.getLayer("route-line");
            if (l != null) l.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.lineColor(color));
            Layer st = style.getLayer("route-stops");
            if (st != null) st.setProperties(
                    org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor(color));
        } catch (Throwable ignored) {
        }
    }

    public void clearTrip() {
        previewTrip = null;
        pushRoute();
    }

    private void pushRoute() {
        if (!ready) return;
        if (previewTrip == null || previewTrip.shape == null || previewTrip.shape.isEmpty()) {
            setSource("route-src", FeatureCollection.fromFeatures(new ArrayList<>()));
            setSource("route-stops-src", FeatureCollection.fromFeatures(new ArrayList<>()));
            return;
        }
        List<Point> pts = new ArrayList<>();
        for (double[] p : previewTrip.shape) pts.add(Point.fromLngLat(p[1], p[0]));
        Feature line = Feature.fromGeometry(LineString.fromLngLats(pts));
        List<Feature> stopFeats = new ArrayList<>();
        for (Gtfs.StopTime st : previewTrip.stops) {
            if (st.lat == 0 && st.lon == 0) continue;
            stopFeats.add(Feature.fromGeometry(Point.fromLngLat(st.lon, st.lat)));
        }
        setSource("route-src", FeatureCollection.fromFeatures(new ArrayList<>(java.util.Collections.singletonList(line))));
        setSource("route-stops-src", FeatureCollection.fromFeatures(stopFeats));
    }

    // ---------------------------------------------------------------- location

    public void setLocation(double lat, double lon) {
        if (!ready || lat == 0 && lon == 0) return;
        Feature f = Feature.fromGeometry(Point.fromLngLat(lon, lat));
        setSource("loc-src", FeatureCollection.fromFeatures(
                new ArrayList<>(java.util.Collections.singletonList(f))));
    }

    // ---------------------------------------------------------------- camera

    public void moveCamera(double lat, double lon, double zoom) {
        if (map == null) return;
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), zoom));
    }

    public void centerOn(double lat, double lon, double zoom) {
        if (map == null) return;
        try {
            map.easeCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), zoom), 700);
        } catch (Throwable t) {
            moveCamera(lat, lon, zoom);
        }
    }

    public void fitTrip(double[][] latlon, double padSouthRatio) {
        if (map == null || latlon == null || latlon.length < 2) return;
        try {
            double minLat = 90, maxLat = -90, minLon = 180, maxLon = -180;
            for (double[] p : latlon) {
                minLat = Math.min(minLat, p[0]);
                maxLat = Math.max(maxLat, p[0]);
                minLon = Math.min(minLon, p[1]);
                maxLon = Math.max(maxLon, p[1]);
            }
            double latSpan = maxLat - minLat;
            double lonSpan = maxLon - minLon;
            minLat -= latSpan * 0.62; // the sheet covers the bottom of the screen
            minLon -= lonSpan * 0.12;
            maxLat += latSpan * 0.12;
            maxLon += lonSpan * 0.12;
            map.easeCamera(CameraUpdateFactory.newLatLngBounds(
                    new LatLngBounds.Builder()
                            .include(new LatLng(maxLat, maxLon))
                            .include(new LatLng(minLat, minLon))
                            .build(), Ui.dp(ctx, 28)), 700);
            mapView.post(() -> {
                try {
                    if (map.getCameraPosition().zoom > 16.2)
                        map.easeCamera(CameraUpdateFactory.newLatLngZoom(
                                map.getCameraPosition().target, 16.2), 400);
                } catch (Throwable ignored) {
                }
            });
        } catch (Throwable ignored) {
        }
    }

    public double camZoom() {
        try {
            return map.getCameraPosition().zoom;
        } catch (Throwable t) {
            return 12;
        }
    }

    public LatLng center() {
        try {
            return map.getCameraPosition().target;
        } catch (Throwable t) {
            return new LatLng(50.04, 21.99);
        }
    }

    public String bboxString() {
        try {
            LatLngBounds b = map.getProjection().getVisibleRegion().latLngBounds;
            double minLon = clampLon(b.getLonWest()), maxLon = clampLon(b.getLonEast());
            double minLat = Math.max(-85, b.getLatSouth()), maxLat = Math.min(85, b.getLatNorth());
            LatLng c = center();
            minLon = Math.max(minLon, c.getLongitude() - 4);
            maxLon = Math.min(maxLon, c.getLongitude() + 4);
            minLat = Math.max(minLat, c.getLatitude() - 4);
            maxLat = Math.min(maxLat, c.getLatitude() + 4);
            if (maxLon <= minLon) maxLon = minLon + 0.02;
            if (maxLat <= minLat) maxLat = minLat + 0.02;
            return String.format(java.util.Locale.US, "%.5f,%.5f,%.5f,%.5f", minLon, minLat, maxLon, maxLat);
        } catch (Throwable t) {
            return "19.0,50.0,20.0,51.0";
        }
    }

    private double clampLon(double lon) {
        if (lon > 180) return 180;
        if (lon < -180) return -180;
        return lon;
    }

    public double spanKm() {
        try {
            LatLngBounds b = map.getProjection().getVisibleRegion().latLngBounds;
            return Ui.distM(b.getLatSouth(), b.getLonWest(), b.getLatNorth(), b.getLonEast()) / 1000.0;
        } catch (Throwable t) {
            return 20;
        }
    }

    public PointF toScreen(double lat, double lon) {
        try {
            return map.getProjection().toScreenLocation(new LatLng(lat, lon));
        } catch (Throwable t) {
            return new PointF(-9999, -9999);
        }
    }

    public void onStart() {
        try {
            if (mapView != null) mapView.onStart();
        } catch (Throwable ignored) {
        }
    }

    public void onStop() {
        try {
            if (mapView != null) mapView.onStop();
        } catch (Throwable ignored) {
        }
    }

    public void onResume() {
        try {
            if (mapView != null) mapView.onResume();
        } catch (Throwable ignored) {
        }
    }

    public void onPause() {
        try {
            if (mapView != null) mapView.onPause();
        } catch (Throwable ignored) {
        }
    }

    public void onDestroy() {
        try {
            handler.removeCallbacks(animTick);
        } catch (Throwable ignored) {
        }
        try {
            if (mapView != null) mapView.onDestroy();
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- clicks

    private boolean onMapClick(LatLng point) {
        try {
            PointF click = toScreen(point.getLatitude(), point.getLongitude());
            float cx = click.x, cy = click.y;
            float maxVeh = Ui.dp(ctx, 30);
            // vehicles first (they sit above stops)
            Models.Vehicle bestV = null;
            float bestVD = maxVeh;
            for (Models.Vehicle v : getVehicles()) {
                if (!vehicleVisible(v)) continue;
                PointF p = toScreen(v.lat, v.lon);
                double d = Math.hypot(p.x - cx, p.y - cy);
                if (d < bestVD) {
                    bestVD = (float) d;
                    bestV = v;
                }
            }
            if (bestV != null) {
                listener.onVehicleTapped(bestV);
                return true;
            }
            // preview route stops
            if (previewTrip != null) {
                float maxRs = Ui.dp(ctx, 22);
                Gtfs.StopTime bestRs = null;
                float bestRsD = maxRs;
                for (Gtfs.StopTime st : previewTrip.stops) {
                    if (st.lat == 0 && st.lon == 0) continue;
                    PointF p = toScreen(st.lat, st.lon);
                    double d = Math.hypot(p.x - cx, p.y - cy);
                    if (d < bestRsD) {
                        bestRsD = (float) d;
                        bestRs = st;
                    }
                }
                if (bestRs != null) {
                    listener.onRouteStopTapped(bestRs.stopId, bestRs.name, bestRs.lat, bestRs.lon);
                    return true;
                }
            }
            // normal stops — alpha-1.6.1: every stop type is clickable from the
            // zoom at which it is drawn; the nationwide overlay is included
            Models.Stop best = null;
            float bestD = Ui.dp(ctx, 26);
            double z = camZoom();
            float stopsMin = prefs.dotZoomStops() / 10f;
            for (Models.Stop s : getStops()) {
                boolean anyType = false;
                for (int t : s.types) {
                    if (prefs.typeFilter(t)) {
                        anyType = true;
                        break;
                    }
                }
                if (!anyType || highlightKey != null) continue;
                if (z < stopsMin) continue;
                PointF p = toScreen(s.lat, s.lon);
                double d = Math.hypot(p.x - cx, p.y - cy);
                if (d < bestD) {
                    bestD = (float) d;
                    best = s;
                }
            }
            if (best != null) {
                listener.onStopTapped(best);
                return true;
            }
        } catch (Throwable t) {
            android.util.Log.w("MapLayers", "click " + t);
        }
        return false;
    }
}
