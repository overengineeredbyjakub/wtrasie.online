package online.wtrasie.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * App settings persisted in SharedPreferences.
 *
 * alpha-1.6.2: every setter uses commit() (a SYNCHRONOUS disk write) instead
 * of apply(). apply() hands the write to a background thread — when the OEM
 * kills the process the pending write could be lost, which is exactly the
 * "all switches off after a few hours unused" bug. A tiny XML commit on the
 * main thread costs microseconds; losing the settings cost user trust.
 */
public class Prefs {
    private final SharedPreferences p;

    public Prefs(Context c) {
        p = c.getSharedPreferences("wtrasie", Context.MODE_PRIVATE);
    }

    private SharedPreferences.Editor edit() {
        return p.edit();
    }

    public int refreshInterval() {
        return p.getInt("refreshInterval", 10);
    }

    public void setRefreshInterval(int v) {
        edit().putInt("refreshInterval", v).commit();
    }

    public boolean showVehicles() {
        return p.getBoolean("showVehicles", true);
    }

    public void setShowVehicles(boolean v) {
        edit().putBoolean("showVehicles", v).commit();
    }

    public boolean showStops() {
        return p.getBoolean("showStops", true);
    }

    public void setShowStops(boolean v) {
        edit().putBoolean("showStops", v).commit();
    }

    /** 0 = small, 1 = medium, 2 = large */
    public int vehicleScale() {
        return p.getInt("vehicleScale", 1);
    }

    public void setVehicleScale(int v) {
        edit().putInt("vehicleScale", v).commit();
    }

    /** alpha-1.6.2: text size 0=A-, 1=A, 2=A+, 3=A++. */
    public int textScale() {
        return p.getInt("textScale", 1);
    }

    public void setTextScale(int v) {
        edit().putInt("textScale", v).commit();
    }

    public boolean showBrigade() {
        return p.getBoolean("showBrigade", false);
    }

    public void setShowBrigade(boolean v) {
        edit().putBoolean("showBrigade", v).commit();
    }

    public boolean showFleet() {
        return p.getBoolean("showFleet", false);
    }

    public void setShowFleet(boolean v) {
        edit().putBoolean("showFleet", v).commit();
    }

    public boolean autoCity() {
        return p.getBoolean("autoCity", true);
    }

    public void setAutoCity(boolean v) {
        edit().putBoolean("autoCity", v).commit();
    }

    /**
     * "Filtruj przejazdy techniczne" — hide vehicles/departures of technical
     * runs (route names like "PT", "..." etc.). On by default.
     */
    public boolean filterTechnical() {
        return p.getBoolean("filterTechnical", true);
    }

    public void setFilterTechnical(boolean v) {
        edit().putBoolean("filterTechnical", v).commit();
    }

    /** "Pozostaw oryginalne kolory pojazdów" — off = unified type colors everywhere.
     *  v1.4.1: ON by default, like on the zbiorkom.live website. */
    public boolean keepOriginalColors() {
        return p.getBoolean("keepOriginalColors", true);
    }

    public void setKeepOriginalColors(boolean v) {
        edit().putBoolean("keepOriginalColors", v).commit();
    }

    /** "Ukryj ikonę pojazdu" — on = only the line number chip, no type glyph.
     *  alpha-1.6.2: OFF by default (the default profile keeps only the
     *  switches from the release notes on). */
    public boolean hideVehicleIcon() {
        return p.getBoolean("hideVehicleIcon", false);
    }

    public void setHideVehicleIcon(boolean v) {
        edit().putBoolean("hideVehicleIcon", v).commit();
    }

    // ---------------------------------------------------------------- debug overlay

    /** "Nakładka debugu" profile: zoom thresholds shown as sliders in settings. */
    public boolean debugOverlay() {
        return p.getBoolean("debugOverlay", false);
    }

    public void setDebugOverlay(boolean v) {
        edit().putBoolean("debugOverlay", v).commit();
    }

    /** Vehicles become plain dots below this zoom (stored x10). */
    public int dotZoomVehicles() {
        return p.getInt("dotZoomVehicles", 130);
    }

    public void setDotZoomVehicles(int v) {
        edit().putInt("dotZoomVehicles", v).commit();
    }

    /** Stops are hidden below this zoom (stored x10).
     *  alpha-1.6.2: default 15.0 (was 11.5) — the whole map calms down and
     *  individual stops appear only when you actually zoom in. */
    public int dotZoomStops() {
        return p.getInt("dotZoomStops", 150);
    }

    public void setDotZoomStops(int v) {
        edit().putInt("dotZoomStops", v).commit();
    }

    /** PKP trains become plain dots below this zoom (stored x10). */
    public int dotZoomPkp() {
        return p.getInt("dotZoomPkp", 110);
    }

    public void setDotZoomPkp(int v) {
        edit().putInt("dotZoomPkp", v).commit();
    }

    // ---------------------------------------------------------------- map & city

    /** 0 = basic (vector, OpenFreeMap), 1 = OSM standard, 2 = satellite.
     *  alpha-1.6.2: 3..6 = VARIANTS of the basic vector style (Pastelowy,
     *  Kontrastowy, Ciepły, Chłodny) derived from style_basic.json at runtime. */
    public int mapStyle() {
        if (p.contains("satellite")) { // migrate from 1.1.x
            boolean sat = p.getBoolean("satellite", false);
            edit().remove("satellite").putInt("mapStyle", sat ? 2 : 0).commit();
        }
        return p.getInt("mapStyle", 0);
    }

    public void setMapStyle(int v) {
        edit().putInt("mapStyle", v).commit();
    }

    public String lastCity() {
        // alpha-1.6.0: the real slug is "warsaw" — the old "warszawa" default
        // resolved to null and crashed a fresh install on startup
        String saved = p.getString("lastCity", "warsaw");
        return "warszawa".equals(saved) ? "warsaw" : saved;
    }

    public void setLastCity(String slug) {
        edit().putString("lastCity", slug).commit();
    }

    public double lastLat() {
        return Double.longBitsToDouble(p.getLong("lastLat", Double.doubleToRawLongBits(52.2297)));
    }

    public double lastLon() {
        return Double.longBitsToDouble(p.getLong("lastLon", Double.doubleToRawLongBits(21.0122)));
    }

    public double lastZoom() {
        return p.getFloat("lastZoom", 11.5f);
    }

    public void setCamera(double lat, double lon, double zoom) {
        edit().putLong("lastLat", Double.doubleToRawLongBits(lat))
                .putLong("lastLon", Double.doubleToRawLongBits(lon))
                .putFloat("lastZoom", (float) zoom)
                .commit();
    }

    public boolean typeFilter(int gtfsType) {
        return p.getBoolean("filter_" + filterKey(gtfsType), true);
    }

    public void setTypeFilter(int gtfsType, boolean on) {
        edit().putBoolean("filter_" + filterKey(gtfsType), on).commit();
    }

    public static int filterKey(int gtfsType) {
        switch (gtfsType) {
            case 0: return 0;   // tram
            case 1: return 1;   // subway
            case 2: return 2;   // rail
            case 3: return 3;   // bus
            case 4: return 4;   // ferry
            case 11: return 11; // trolleybus
            default: return 99; // gondola / funicular / monorail / other
        }
    }

    /** v1.4.0: every city starts with all vehicle types visible. */
    public void resetTypeFilters() {
        android.content.SharedPreferences.Editor e = edit();
        for (String key : p.getAll().keySet()) {
            if (key != null && key.startsWith("filter_")) e.putBoolean(key, true);
        }
        e.commit();
    }
}
